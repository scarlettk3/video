"""
ConfigurableMLP — matches the ENAS checkpoint architecture from the notebook.

DO NOT change this class; the state-dict keys are fixed by the saved checkpoint.
"""

import torch
import torch.nn as nn

ACTIVATIONS = {
    "relu":       nn.ReLU,
    "leaky_relu": lambda: nn.LeakyReLU(0.01),
    "gelu":       nn.GELU,
}


class ConfigurableMLP(nn.Module):
    """
    Feed-forward binary classifier built from an architecture gene dict:
        {
            "n_layers":   int,
            "units":      [int, ...]   # length >= n_layers
            "activation": "relu" | "leaky_relu" | "gelu",
            "dropout":    float,
        }
    Output: single logit — apply sigmoid for probability.
    Net structure: Linear → BatchNorm1d → Activation → Dropout (× n_layers)
                   → Linear(1) output
    """

    def __init__(self, input_dim: int, arch: dict):
        super().__init__()
        self.arch = arch

        act_name = arch["activation"].lower()
        if act_name not in ACTIVATIONS:
            raise ValueError(f"Unknown activation '{act_name}'. Valid: {list(ACTIVATIONS)}")
        activation_factory = ACTIVATIONS[act_name]

        layers = []
        in_dim = input_dim
        dropout = float(arch.get("dropout", 0.0))

        for units in arch["units"][: arch["n_layers"]]:
            layers.append(nn.Linear(in_dim, units))
            layers.append(nn.BatchNorm1d(units))
            layers.append(activation_factory())
            if dropout > 0:
                layers.append(nn.Dropout(dropout))
            in_dim = units

        layers.append(nn.Linear(in_dim, 1))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x).squeeze(-1)   # (batch,) raw logits
