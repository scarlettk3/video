"""
Safe checkpoint loaders for all three frozen models.
"""

from pathlib import Path
from typing import Tuple

import numpy as np
import torch

from config.settings import DEVICE, DQN_HIDDEN_DIMS
from models.mlp import ConfigurableMLP
from models.generator import Generator
from models.dqn import QNetwork


def _load(path: Path, device=None):
    """Load a PyTorch checkpoint, compatible with older versions."""
    device = device or DEVICE
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Checkpoint not found: {path}")
    try:
        return torch.load(path, map_location=device, weights_only=False)
    except TypeError:
        return torch.load(path, map_location=device)


# ---------------------------------------------------------------------------
# ENAS + GAN classifier
# ---------------------------------------------------------------------------

def load_detector(path: Path, device=None) -> Tuple[ConfigurableMLP, int]:
    """
    Load the frozen ENAS detection checkpoint.
    Returns (model_in_eval_mode, input_dim).
    """
    device = device or DEVICE
    ckpt = _load(path, device)
    if not isinstance(ckpt, dict):
        raise TypeError("Detector checkpoint must be a dict.")
    input_dim  = int(ckpt["input_dim"])
    arch       = ckpt["architecture"]
    state_dict = ckpt["state_dict"]
    model = ConfigurableMLP(input_dim, arch).to(device)
    model.load_state_dict(state_dict, strict=True)
    model.eval()
    for p in model.parameters():
        p.requires_grad_(False)
    return model, input_dim


# ---------------------------------------------------------------------------
# GAN generator
# ---------------------------------------------------------------------------

def load_generator(path: Path, device=None) -> Tuple[Generator, int, np.ndarray, np.ndarray]:
    """
    Load the frozen tabular GAN generator checkpoint.
    Returns (generator, noise_dim, X_min, X_max).
    """
    device = device or DEVICE
    ckpt = _load(path, device)
    if not isinstance(ckpt, dict):
        raise TypeError("Generator checkpoint must be a dict.")
    noise_dim   = int(ckpt["noise_dim"])
    feature_dim = int(ckpt["feature_dim"])
    X_min = np.asarray(ckpt["X_min"], dtype=np.float32)
    X_max = np.asarray(ckpt["X_max"], dtype=np.float32)
    gen = Generator(noise_dim, feature_dim).to(device)
    gen.load_state_dict(ckpt["generator_state_dict"], strict=True)
    gen.eval()
    for p in gen.parameters():
        p.requires_grad_(False)
    return gen, noise_dim, X_min, X_max


# ---------------------------------------------------------------------------
# DQN mitigation policy
# ---------------------------------------------------------------------------

def load_dqn(path: Path, device=None) -> Tuple[QNetwork, int, int]:
    """
    Load the trained DQN policy checkpoint.
    Returns (q_network_in_eval_mode, state_dim, n_actions).
    """
    device = device or DEVICE
    ckpt = _load(path, device)
    if not isinstance(ckpt, dict):
        raise TypeError("DQN checkpoint must be a dict.")
    state_dim   = int(ckpt["state_dim"])
    n_actions   = int(ckpt["n_actions"])
    hidden_dims = ckpt.get("hidden_dims", DQN_HIDDEN_DIMS)
    net = QNetwork(state_dim, n_actions, hidden_dims).to(device)
    net.load_state_dict(ckpt["state_dict"], strict=True)
    net.eval()
    for p in net.parameters():
        p.requires_grad_(False)
    return net, state_dim, n_actions
