"""
GAN Generator — matches the checkpoint architecture from the notebook.

DO NOT change this class; the state-dict keys are fixed by the saved checkpoint.
"""

import torch
import torch.nn as nn


class Generator(nn.Module):
    """
    Tabular GAN generator with Tanh output (range ≈ [-1, 1]).
    Architecture: Linear→BN→ReLU → Linear→BN→ReLU → Linear→Tanh
    hidden_dim=128 matches the training defaults.
    """

    def __init__(self, noise_dim: int, output_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(noise_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim * 2),
            nn.BatchNorm1d(hidden_dim * 2),
            nn.ReLU(),
            nn.Linear(hidden_dim * 2, output_dim),
            nn.Tanh(),
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        return self.net(z)
