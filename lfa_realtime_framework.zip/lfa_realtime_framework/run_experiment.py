"""
Scenario runner — coordinates the full experiment lifecycle.

For each scenario the runner:
  1. Builds the Mininet network (or reuses an existing one).
  2. Injects agents into the Ryu controller via sdn.inject_agents().
  3. Steps through segment list (start_segment / traffic / sleep / end_segment).
  4. Collects results from ExperimentManager logs.
  5. Computes evaluation metrics and produces plots.

Run:
    sudo python3 run_experiment.py --scenario alternating
"""

import argparse
import json
import subprocess
import sys
import time
import uuid
from pathlib import Path
from typing import List, Optional

import numpy as np

from config.settings import (
    STATS_INTERVAL, RESULTS_DIR, PLOTS_DIR,
    ARTIFACTS_ROOT, BEST_MODEL_GAN_PATH, BEST_MODEL_NO_GAN_PATH,
    GAN_GENERATOR_PATH, DQN_MITIGATION_PATH,
    PREPROCESSOR_PATH, FEATURE_COLUMNS_PATH,
    TOPO_N_HOSTS, TOPO_BOTTLENECK_BW,
)
from agents.detection_agent import DetectionAgent
from agents.lfa_agent import LFAProfile, LFAGenerator, EvasionBandit, TrafficProfileTranslator
from agents.mitigation_agent import MitigationAgent
from experiment.manager import ExperimentManager
from experiment.scenarios import SCENARIOS
from experiment.timeline import RecoveryTimer
from evaluation.metrics import (
    detection_metrics, lfa_generation_metrics,
    mitigation_metrics, latency_metrics,
)
from evaluation.plotter import (
    plot_alternating_experiment, plot_bandit_convergence,
    plot_latency_breakdown, plot_congestion_comparison,
    plot_detection_metrics_table, plot_link_utilization,
)
from utils.common import get_logger, wall_ts, set_seed

log = get_logger(__name__)

try:
    from traffic.topology import build_network, DumbbellTopo, LinearTopo
    from traffic.traffic_generator import (
        LFATrafficGenerator, run_benign_flow,
        start_iperf_servers, stop_iperf_servers, conventional_lfa,
    )
    from sdn.ryu_controller import inject_agents
    _HAS_MININET = True
except ImportError:
    _HAS_MININET = False
    log.warning("Mininet not available — running in evaluation-only mode.")


# ---------------------------------------------------------------------------
# Agent initialisation
# ---------------------------------------------------------------------------

def init_agents(val_npz: Optional[Path] = None):
    """
    Load all three frozen agents and build the LFA profile.
    val_npz: path to validation split (used to build LFAProfile from real attacks).
    """
    log.info("Initialising agents ...")

    # Detection agent
    detector = DetectionAgent(model_path=BEST_MODEL_GAN_PATH)

    # Build LFA profile from validation attack distribution
    if val_npz and Path(val_npz).is_file():
        data = np.load(val_npz, allow_pickle=False)
        val_X, val_y = data["X"], data["y"]
        attack_X = val_X[val_y == 1]
    else:
        log.warning("val.npz not found; LFAProfile will use a synthetic fallback.")
        from config.settings import FEATURE_COLUMNS_PATH
        import json
        with open(FEATURE_COLUMNS_PATH) as fh:
            feat_names = json.load(fh)
        feat_names = feat_names if isinstance(feat_names, list) else feat_names["feature_columns"]
        # Fallback: random attack-like array
        attack_X = np.random.rand(100, len(feat_names)).astype(np.float32)
        feat_names_list = feat_names
        profile = LFAProfile(feat_names_list, attack_X)
        lfa_gen = LFAGenerator(profile, gen_path=GAN_GENERATOR_PATH)
        bandit  = EvasionBandit()
        translator = TrafficProfileTranslator(feat_names_list)
        mitigator  = MitigationAgent(model_path=DQN_MITIGATION_PATH)
        return detector, lfa_gen, bandit, translator, mitigator, feat_names_list

    import json
    with open(FEATURE_COLUMNS_PATH) as fh:
        raw = json.load(fh)
    feat_names = raw if isinstance(raw, list) else raw.get("feature_columns", raw)

    profile    = LFAProfile(feat_names, attack_X)
    lfa_gen    = LFAGenerator(profile, gen_path=GAN_GENERATOR_PATH)
    bandit     = EvasionBandit()
    translator = TrafficProfileTranslator(feat_names)
    mitigator  = MitigationAgent(model_path=DQN_MITIGATION_PATH)

    log.info("All agents ready.")
    return detector, lfa_gen, bandit, translator, mitigator, feat_names


# ---------------------------------------------------------------------------
# Main scenario runner
# ---------------------------------------------------------------------------

def run_scenario(
    scenario_name: str,
    detector,
    lfa_gen,
    bandit,
    translator,
    mitigator,
    exp_manager: ExperimentManager,
    net=None,
) -> dict:
    """Execute one scenario and return raw results dict."""
    segments   = SCENARIOS[scenario_name]
    session_id = uuid.uuid4().hex[:8]
    exp_manager.start_session(session_id, scenario_name)

    recovery_timer    = RecoveryTimer(threshold=0.2)
    recovery_times    = []
    congestion_hist   = []
    all_pred_probs    = []
    all_pred_labels   = []
    all_actions       = []
    all_timestamps    = []

    # Inject into Ryu controller (sets global references in ryu_controller.py)
    if _HAS_MININET:
        inject_agents(lfa_gen, bandit, exp_manager)

    src_hosts = dst_hosts = []
    if _HAS_MININET and net:
        hosts = list(net.hosts)
        mid   = len(hosts) // 2
        src_hosts = hosts[:mid]
        dst_hosts = hosts[mid:]
        start_iperf_servers(dst_hosts)
        lfa_traffic_gen = LFATrafficGenerator(translator, src_hosts, dst_hosts)

    for seg_idx, (seg_label, duration_s, kwargs) in enumerate(segments):
        attack_type     = kwargs.get("attack_type")
        target_link     = kwargs.get("target_link", "s1-s2")
        evasion_strength = kwargs.get("evasion_strength")

        exp_manager.start_segment(
            label=seg_label,
            segment_id=seg_idx,
            attack_type=attack_type,
            target_link=target_link,
            evasion_strength=evasion_strength,
        )
        ts_seg_start = wall_ts()
        log.info("Segment %d/%d: %s  (%.0fs)", seg_idx + 1, len(segments),
                 seg_label, duration_s)

        # Attack segments: launch traffic
        if seg_label != "benign" and _HAS_MININET and net:
            if seg_label == "conventional_lfa":
                dst_ip = dst_hosts[0].IP() if dst_hosts else "10.0.0.1"
                conventional_lfa(
                    src_hosts, dst_ip,
                    duration_s=duration_s,
                    n_flows_per_host=kwargs.get("n_flows_per_host", 10),
                    interval_us=kwargs.get("interval_us", 100),
                )
            elif seg_label in ("gan_lfa", "adaptive_lfa"):
                e = evasion_strength if evasion_strength is not None \
                    else bandit.best_strength()
                X_lfa = lfa_gen.generate_batch(16, e)
                exp_manager.log_bandit_update(
                    round_num=0, arm_index=0,
                    evasion_strength=e, reward=0.0,
                    mean_pred_prob=0.0, detection_rate=0.0,
                    ts=wall_ts(),
                )
                lfa_traffic_gen.generate_and_launch(X_lfa)
        elif seg_label == "benign" and _HAS_MININET and net:
            # Launch background benign flows
            for si, src in enumerate(src_hosts):
                dst_ip = dst_hosts[si % len(dst_hosts)].IP()
                run_benign_flow(src, dst_ip, duration_s=duration_s,
                                bandwidth_mbps=0.5)

        # Mark attack start for recovery timer
        if seg_label != "benign":
            recovery_timer.attack_started()

        # Wait for segment duration, periodically checking recovery
        elapsed = 0.0
        poll_interval = min(STATS_INTERVAL, 2.0)
        while elapsed < duration_s:
            time.sleep(poll_interval)
            elapsed += poll_interval

            # Check congestion recovery
            current_congestion = getattr(exp_manager, "_congestion_history", [0.0])
            cval = current_congestion[-1] if current_congestion else 0.0
            rec_t = recovery_timer.check_recovery(cval)
            if rec_t is not None:
                recovery_times.append(rec_t)
                exp_manager.log_recovery(rec_t, seg_idx)

        # Stop attack traffic
        if seg_label != "benign" and _HAS_MININET and net:
            lfa_traffic_gen.stop_all()

        exp_manager.end_segment(seg_idx)

    exp_manager.end_session()

    if _HAS_MININET and net:
        stop_iperf_servers(dst_hosts)

    # ---- Gather results from logs ----
    flow_events = exp_manager.load_flow_events()
    gt_segs     = exp_manager.load_ground_truth()
    lat_cycles  = exp_manager.load_latency_cycles()

    y_true = [1 if _is_attack_ts(ev["ts"], gt_segs) else 0 for ev in flow_events]
    y_pred = [ev["pred_label"] for ev in flow_events]
    y_prob = [ev["pred_prob"]  for ev in flow_events]

    det_m  = detection_metrics(np.array(y_true), np.array(y_pred), np.array(y_prob))
    lfa_m  = lfa_generation_metrics(
        bandit.history,
        [ev["pred_prob"] for ev in flow_events],
        exp_manager.congestion_history(),
    )
    lat_m  = latency_metrics(lat_cycles)

    congestion_hist = exp_manager.congestion_history()
    mit_m = mitigation_metrics(
        congestion_before=congestion_hist[:len(congestion_hist) // 2],
        congestion_after=congestion_hist[len(congestion_hist) // 2:],
        recovery_times_s=recovery_times,
        action_log=flow_events,
    )

    return {
        "scenario":          scenario_name,
        "session_id":        session_id,
        "detection_metrics": det_m,
        "lfa_metrics":       lfa_m,
        "mitigation_metrics": mit_m,
        "latency_metrics":   lat_m,
        "congestion_history": congestion_hist,
        "bandit_history":    bandit.history,
        "gt_segments":       [s for s in gt_segs if s.get("type") == "segment_start"],
    }


def _is_attack_ts(ts: float, gt_segs: List[dict]) -> bool:
    """Return True if wall timestamp ts falls inside a known attack segment."""
    for seg in gt_segs:
        if seg.get("type") != "segment_start":
            continue
        ts0 = seg.get("ts_start", 0)
        # Next segment start is the end of this one (approximate)
        if seg.get("label", "benign") != "benign" and ts >= ts0:
            return True
    return False


# ---------------------------------------------------------------------------
# Post-experiment plotting
# ---------------------------------------------------------------------------

def produce_plots(results: dict, exp_manager: ExperimentManager):
    flow_events = exp_manager.load_flow_events()
    lat_cycles  = exp_manager.load_latency_cycles()
    gt_segs     = [s for s in exp_manager.load_ground_truth()
                   if s.get("type") in ("segment_start", "segment_end")]

    timestamps   = [ev["ts"]         for ev in flow_events]
    congestion   = [ev["congestion"] for ev in flow_events]
    pred_probs   = [ev["pred_prob"]  for ev in flow_events]
    pred_labels  = [ev["pred_label"] for ev in flow_events]
    actions      = [ev["action"]     for ev in flow_events]
    bandit_hist  = results.get("bandit_history", [])
    port_util    = [r for r in exp_manager.load_ground_truth()
                    if r.get("type") == "port_util"]

    plot_alternating_experiment(timestamps, congestion, pred_probs,
                                pred_labels, actions, bandit_hist, gt_segs)
    plot_bandit_convergence(bandit_hist)
    plot_latency_breakdown(results.get("latency_metrics", {}))
    plot_link_utilization(port_util, gt_segs)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Run real-time LFA multi-agent framework experiment."
    )
    parser.add_argument("--scenario", default="alternating",
                        choices=list(SCENARIOS.keys()),
                        help="Experiment scenario to run.")
    parser.add_argument("--all-scenarios", action="store_true",
                        help="Run all scenarios sequentially.")
    parser.add_argument("--no-mininet", action="store_true",
                        help="Skip Mininet network launch (evaluation only).")
    parser.add_argument("--val-npz", default=None,
                        help="Path to validation split .npz (for LFAProfile).")
    args = parser.parse_args()

    set_seed(42)

    val_npz = Path(args.val_npz) if args.val_npz else (ARTIFACTS_ROOT / "processed" / "val.npz")

    detector, lfa_gen, bandit, translator, mitigator, feat_names = init_agents(val_npz)

    exp_manager = ExperimentManager()

    net = None
    if _HAS_MININET and not args.no_mininet:
        log.info("Building Mininet dumbbell topology ...")
        net = build_network(n_hosts=TOPO_N_HOSTS, bottleneck_bw=TOPO_BOTTLENECK_BW)
        net.start()

    try:
        scenarios_to_run = (list(SCENARIOS.keys()) if args.all_scenarios
                            else [args.scenario])

        all_det_metrics = {}
        for sname in scenarios_to_run:
            log.info("===== Running scenario: %s =====", sname)
            bandit.history.clear()   # reset bandit per scenario
            results = run_scenario(
                sname, detector, lfa_gen, bandit,
                translator, mitigator, exp_manager, net
            )

            all_det_metrics[sname] = results.get("detection_metrics", {})

            # Save per-scenario results
            out = RESULTS_DIR / f"{sname}_results.json"
            with open(out, "w") as fh:
                # Numpy types are not JSON-serialisable
                json.dump(results, fh, indent=2, default=lambda x: float(x)
                          if isinstance(x, (np.floating, np.integer)) else str(x))
            log.info("Saved → %s", out)

            produce_plots(results, exp_manager)

        # Cross-scenario detection comparison
        if len(all_det_metrics) > 1:
            plot_detection_metrics_table(all_det_metrics)

    finally:
        if net:
            net.stop()
            log.info("Mininet stopped.")


if __name__ == "__main__":
    main()
