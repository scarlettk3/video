"""
Central configuration for the real-time LFA multi-agent framework.

USAGE: Update every path marked  <<<  to match your environment before running.
"""

import os
from pathlib import Path
import torch

# ---------------------------------------------------------------------------
# Project root — one level up from this file
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# ---------------------------------------------------------------------------
# <<<  ARTIFACT PATHS — point these to the outputs of sdn-security-framework1-FIXED.ipynb  >>>
# ---------------------------------------------------------------------------
ARTIFACTS_ROOT = Path(os.environ.get("SDN_ARTIFACTS", PROJECT_ROOT.parent / "artifacts"))

PREPROCESSOR_PATH      = ARTIFACTS_ROOT / "processed"   / "preprocessor.pkl"
LABEL_ENCODER_PATH     = ARTIFACTS_ROOT / "processed"   / "label_encoder.pkl"
FEATURE_COLUMNS_PATH   = ARTIFACTS_ROOT / "processed"   / "feature_columns.json"
BEST_MODEL_GAN_PATH    = ARTIFACTS_ROOT / "enas"        / "best_model_gan.pt"
BEST_MODEL_NO_GAN_PATH = ARTIFACTS_ROOT / "enas"        / "best_model_no_gan.pt"
GAN_GENERATOR_PATH     = ARTIFACTS_ROOT / "gan"         / "generator.pt"
DQN_MITIGATION_PATH    = ARTIFACTS_ROOT / "dqn_mitigation" / "mitigation_policy.pt"

# Processed validation / test sets (used for offline fallback evaluation)
VAL_NPZ_PATH  = ARTIFACTS_ROOT / "processed" / "val.npz"
TEST_NPZ_PATH = ARTIFACTS_ROOT / "processed" / "test.npz"

# ---------------------------------------------------------------------------
# Results output directory
# ---------------------------------------------------------------------------
RESULTS_DIR = PROJECT_ROOT / "results"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

LOG_DIR = RESULTS_DIR / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

PLOTS_DIR = RESULTS_DIR / "plots"
PLOTS_DIR.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Device
# ---------------------------------------------------------------------------
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
RANDOM_SEED = 42

# ---------------------------------------------------------------------------
# SDN / OpenFlow
# ---------------------------------------------------------------------------
CONTROLLER_IP   = "127.0.0.1"
CONTROLLER_PORT = 6653              # OpenFlow 1.3 default
STATS_INTERVAL  = 5.0               # seconds between RequestStats polls
FLOW_WINDOW_SEC = STATS_INTERVAL    # feature extraction window width

# ---------------------------------------------------------------------------
# Feature schema (must match the training pipeline exactly)
# ---------------------------------------------------------------------------
LABEL_COLUMN = "label"

DROP_COLUMNS = [
    "flowInd", "srcIP", "dstIP", "srcMac", "dstMac",
    "srcIPCC", "dstIPCC", "srcIPOrg", "dstIPOrg",
    "timeFirst", "timeLast", "hdrDesc",
]

LOG_TRANSFORM_COLUMNS = [
    "duration", "pktsSnt", "pktsRcvd", "padBytesSnt", "l7BytesSnt",
    "l7BytesRcvd", "minL7PktSz", "maxL7PktSz", "avgL7PktSz", "stdL7PktSz",
    "minIAT", "maxIAT", "avgIAT", "stdIAT", "pktps", "bytps",
    "pktAsm", "bytAsm",
]

CATEGORICAL_COLUMNS = [
    "%dir", "flowStat", "ethType", "vlanID", "l4Proto",
    "srcPort_bucket", "dstPort_bucket",
]

PORT_COLUMNS = ["srcPort", "dstPort"]

SERVICE_PORTS = [
    20, 21, 22, 23, 25, 53, 67, 68, 69, 80, 110, 123, 135, 137, 138, 139,
    143, 161, 389, 443, 445, 993, 995, 1433, 3306, 3389, 5432, 5900, 8080,
]

OTHER_NUMERIC_COLUMNS = ["numHdrDesc", "numHdrs"]

# ---------------------------------------------------------------------------
# GAN / LFA agent
# ---------------------------------------------------------------------------
GAN_NOISE_DIM    = 32
GAN_HIDDEN_DIM   = 128

EVASION_STRENGTHS    = [0.0, 0.25, 0.5, 0.75, 1.0]
BANDIT_EPSILON       = 0.2
BANDIT_SEED          = RANDOM_SEED
LFA_BATCH_SIZE       = 256
LFA_GEN_INTERVAL_SEC = STATS_INTERVAL   # generate one batch per stats cycle

# ---------------------------------------------------------------------------
# DQN mitigation action space
# ---------------------------------------------------------------------------
ACTION_ALLOW    = 0
ACTION_MONITOR  = 1
ACTION_RATE_LIMIT = 2
ACTION_BLOCK    = 3
ACTION_REROUTE  = 4

ACTION_NAMES = [
    "allow",
    "monitor",
    "rate_limit",
    "install_blocking_rule",
    "reroute",
]

N_ACTIONS = len(ACTION_NAMES)

MITIGATION_ACTIONS = {ACTION_RATE_LIMIT, ACTION_BLOCK, ACTION_REROUTE}

MITIGATION_COST = {
    ACTION_RATE_LIMIT: 0.2,
    ACTION_BLOCK:      0.4,
    ACTION_REROUTE:    0.5,
}

DQN_HIDDEN_DIMS = [128, 64]

# ---------------------------------------------------------------------------
# Mininet topology defaults (<<<  adjust to match your testbed  >>>)
# ---------------------------------------------------------------------------
TOPO_N_HOSTS       = 8          # hosts per side of the dumbbell
TOPO_BOTTLENECK_BW = 10         # Mbps for the bottleneck link
TOPO_HOST_BW       = 100        # Mbps for host links
TOPO_DELAY         = "5ms"

# ---------------------------------------------------------------------------
# Traffic generation bounds (used by profile_translator)
# ---------------------------------------------------------------------------
MAX_RATE_MBPS        = 5.0      # per-flow cap so we don't saturate host links
MIN_FLOW_DURATION_S  = 1.0
MAX_FLOW_DURATION_S  = 30.0
MAX_CONCURRENT_FLOWS = 50       # hard cap for testbed safety

# ---------------------------------------------------------------------------
# Experiment scenarios
# ---------------------------------------------------------------------------
SCENARIO_NAMES = [
    "benign_only",
    "conventional_lfa",
    "gan_lfa",
    "adaptive_lfa",
    "unseen_topology",
]

SCENARIO_DURATION_SEC = {
    "benign_only":     60,
    "conventional_lfa": 60,
    "gan_lfa":         60,
    "adaptive_lfa":    60,
    "unseen_topology":  90,
}

# Continuous alternating experiment segments (label, duration_s)
ALTERNATING_EXPERIMENT = [
    ("benign",          30),
    ("conventional_lfa", 30),
    ("benign",          20),
    ("adaptive_lfa",    40),
    ("benign",          20),
    ("adaptive_lfa",    40),
]

# ---------------------------------------------------------------------------
# Latency / real-time thresholds
# ---------------------------------------------------------------------------
# System must complete feature-extraction + inference within one stats window
REALTIME_BUDGET_SEC = STATS_INTERVAL

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
LOG_LEVEL = "INFO"
GROUND_TRUTH_LOG  = LOG_DIR / "ground_truth.jsonl"
SYSTEM_EVENT_LOG  = LOG_DIR / "system_events.jsonl"
TIMESTAMP_LOG     = LOG_DIR / "timestamps.jsonl"
METRICS_LOG       = LOG_DIR / "metrics.jsonl"
