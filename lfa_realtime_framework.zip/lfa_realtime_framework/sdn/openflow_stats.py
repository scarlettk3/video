"""
OpenFlow statistics collector helpers.

Used by the Ryu controller to request and parse per-flow and per-port stats.
"""

import time
from typing import List, Optional

from utils.common import get_logger

log = get_logger(__name__)


def flow_stats_to_dict(fs) -> dict:
    """
    Convert a ryu.ofproto.ofproto_v1_3_parser.OFPFlowStats object into a
    plain dict understood by FlowFeatureExtractor.update().
    """
    match_dict = {}
    for field, value in fs.match.items():
        match_dict[str(field)] = value

    return {
        "cookie":       int(fs.cookie),
        "match":        match_dict,
        "byte_count":   int(fs.byte_count),
        "packet_count": int(fs.packet_count),
        "duration_sec":  int(fs.duration_sec),
        "duration_nsec": int(fs.duration_nsec),
        "priority":     int(fs.priority),
    }


def port_stats_to_dict(ps) -> dict:
    """
    Convert OFPPortStats to a plain dict for latency / utilisation tracking.
    """
    return {
        "port_no":       int(ps.port_no),
        "rx_packets":    int(ps.rx_packets),
        "tx_packets":    int(ps.tx_packets),
        "rx_bytes":      int(ps.rx_bytes),
        "tx_bytes":      int(ps.tx_bytes),
        "rx_errors":     int(ps.rx_errors),
        "tx_errors":     int(ps.tx_errors),
        "rx_dropped":    int(ps.rx_dropped),
        "tx_dropped":    int(ps.tx_dropped),
        "ts":            time.time(),
    }


class PortUtilizationTracker:
    """
    Compute per-port utilization (%) from consecutive OFPPortStats.
    link_capacity_bps: nominal link capacity in bits-per-second.
    """

    def __init__(self, link_capacity_bps: float = 10e6):
        self.link_bps  = link_capacity_bps
        self._prev: dict = {}   # port_no → prev stats dict

    def update(self, port_stats_list: List[dict]) -> dict:
        """
        Returns {port_no: utilization_fraction} for all ports.
        """
        util = {}
        ts_now = time.time()
        for ps in port_stats_list:
            p = ps["port_no"]
            if p in self._prev:
                prev = self._prev[p]
                dt   = max(1e-6, ts_now - prev["ts"])
                rx_bps = (ps["rx_bytes"] - prev["rx_bytes"]) * 8 / dt
                tx_bps = (ps["tx_bytes"] - prev["tx_bytes"]) * 8 / dt
                util[p] = max(rx_bps, tx_bps) / self.link_bps
            self._prev[p] = {**ps, "ts": ts_now}
        return util
