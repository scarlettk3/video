"""
Mitigation actions applied as OpenFlow rules through the Ryu controller.

Action mapping from DQN outputs:
  0 allow                 — remove any matching drop/rate rules
  1 monitor               — install a low-priority flow that just mirrors traffic
  2 rate_limit            — install a metered rule limiting the matched src
  3 install_blocking_rule — install a high-priority DROP rule for the matched src
  4 reroute               — output to an alternate port (requires topology info)
"""

from utils.common import get_logger

log = get_logger(__name__)

# Priorities
PRIORITY_BLOCK   = 200
PRIORITY_RATE    = 150
PRIORITY_MONITOR = 100
PRIORITY_NORMAL  = 10

# Meter IDs
METER_RATE_LIMIT = 1


def install_blocking_rule(datapath, src_ip: str, idle_timeout: int = 60):
    """Drop all packets from src_ip for idle_timeout seconds."""
    ofproto = datapath.ofproto
    parser  = datapath.ofproto_parser
    match   = parser.OFPMatch(eth_type=0x0800, ipv4_src=src_ip)
    actions = []   # empty → DROP
    instructions = [
        parser.OFPInstructionActions(ofproto.OFPIT_CLEAR_ACTIONS, actions)
    ]
    mod = parser.OFPFlowMod(
        datapath=datapath,
        priority=PRIORITY_BLOCK,
        idle_timeout=idle_timeout,
        match=match,
        instructions=instructions,
    )
    datapath.send_msg(mod)
    log.info("Blocking rule installed for src=%s (timeout=%ds)", src_ip, idle_timeout)


def install_rate_limit_rule(datapath, src_ip: str, rate_kbps: int = 1000,
                             idle_timeout: int = 60):
    """Rate-limit traffic from src_ip using an OpenFlow meter."""
    ofproto = datapath.ofproto
    parser  = datapath.ofproto_parser

    # Add / update meter
    bands = [
        parser.OFPMeterBandDrop(rate=rate_kbps, burst_size=64)
    ]
    meter_mod = parser.OFPMeterMod(
        datapath=datapath,
        command=ofproto.OFPMC_ADD,
        flags=ofproto.OFPMF_KBPS,
        meter_id=METER_RATE_LIMIT,
        bands=bands,
    )
    datapath.send_msg(meter_mod)

    match = parser.OFPMatch(eth_type=0x0800, ipv4_src=src_ip)
    instructions = [
        parser.OFPInstructionMeter(METER_RATE_LIMIT),
        parser.OFPInstructionActions(
            ofproto.OFPIT_APPLY_ACTIONS,
            [parser.OFPActionOutput(ofproto.OFPP_NORMAL)],
        ),
    ]
    mod = parser.OFPFlowMod(
        datapath=datapath,
        priority=PRIORITY_RATE,
        idle_timeout=idle_timeout,
        match=match,
        instructions=instructions,
    )
    datapath.send_msg(mod)
    log.info("Rate-limit rule installed for src=%s at %d kbps", src_ip, rate_kbps)


def install_monitor_rule(datapath, src_ip: str):
    """Install a low-priority flow that forwards traffic normally (monitoring hook)."""
    ofproto = datapath.ofproto
    parser  = datapath.ofproto_parser
    match   = parser.OFPMatch(eth_type=0x0800, ipv4_src=src_ip)
    actions = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
    instructions = [
        parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)
    ]
    mod = parser.OFPFlowMod(
        datapath=datapath,
        priority=PRIORITY_MONITOR,
        match=match,
        instructions=instructions,
    )
    datapath.send_msg(mod)
    log.info("Monitor rule installed for src=%s", src_ip)


def reroute_flow(datapath, src_ip: str, alt_port: int, idle_timeout: int = 60):
    """Redirect traffic from src_ip to an alternate port."""
    ofproto = datapath.ofproto
    parser  = datapath.ofproto_parser
    match   = parser.OFPMatch(eth_type=0x0800, ipv4_src=src_ip)
    actions = [parser.OFPActionOutput(alt_port)]
    instructions = [
        parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)
    ]
    mod = parser.OFPFlowMod(
        datapath=datapath,
        priority=PRIORITY_RATE,
        idle_timeout=idle_timeout,
        match=match,
        instructions=instructions,
    )
    datapath.send_msg(mod)
    log.info("Reroute rule: src=%s → port %d", src_ip, alt_port)


def remove_mitigation_rules(datapath, src_ip: str):
    """Delete any mitigation rules previously installed for src_ip."""
    ofproto = datapath.ofproto
    parser  = datapath.ofproto_parser
    match   = parser.OFPMatch(eth_type=0x0800, ipv4_src=src_ip)
    mod = parser.OFPFlowMod(
        datapath=datapath,
        command=ofproto.OFPFC_DELETE,
        out_port=ofproto.OFPP_ANY,
        out_group=ofproto.OFPG_ANY,
        match=match,
    )
    datapath.send_msg(mod)
    log.info("Removed mitigation rules for src=%s", src_ip)
