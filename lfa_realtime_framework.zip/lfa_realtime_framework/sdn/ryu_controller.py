"""
Ryu SDN Controller — the integration hub of the multi-agent framework.

Pipeline per stats cycle:
  1. Request OFPFlowStatsRequest from every connected switch.
  2. Parse replies with FlowFeatureExtractor (preprocessing/feature_extraction.py).
  3. Apply PreprocessingPipeline to produce a (n_flows, feature_dim) array.
  4. Send array to frozen DetectionAgent → attack probabilities.
  5. Feed mean_pred_prob back to EvasionBandit → reward → arm update.
  6. For every flow predicted as ATTACK, query MitigationAgent → action.
  7. Apply the OpenFlow rule via mitigation_actions.py.
  8. Log all timestamps to ExperimentManager.

Usage (from shell on the Mininet host):
    ryu-manager sdn/ryu_controller.py --ofp-tcp-listen-port 6653
"""

import os
import time
import threading
from pathlib import Path

import numpy as np

# Ryu imports — only available when running under ryu-manager
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import CONFIG_DISPATCHER, MAIN_DISPATCHER, set_ev_cls
from ryu.lib import hub
from ryu.ofproto import ofproto_v1_3

from config.settings import (
    DEVICE, STATS_INTERVAL, ACTION_ALLOW, ACTION_MONITOR,
    ACTION_RATE_LIMIT, ACTION_BLOCK, ACTION_REROUTE,
    BEST_MODEL_GAN_PATH, DQN_MITIGATION_PATH,
    PREPROCESSOR_PATH, FEATURE_COLUMNS_PATH, GAN_GENERATOR_PATH,
)
from preprocessing.pipeline import PreprocessingPipeline
from preprocessing.feature_extraction import FlowFeatureExtractor
from sdn.openflow_stats import flow_stats_to_dict, port_stats_to_dict, PortUtilizationTracker
from sdn.mitigation_actions import (
    install_blocking_rule, install_rate_limit_rule,
    install_monitor_rule, reroute_flow, remove_mitigation_rules,
)
from agents.detection_agent import DetectionAgent
from agents.mitigation_agent import MitigationAgent
from experiment.manager import ExperimentManager
from experiment.timeline import TimestampTracker
from utils.common import get_logger, wall_ts

log = get_logger(__name__)

# ---------------------------------------------------------------------------
# Global shared state (set by scenario runner before experiment starts)
# ---------------------------------------------------------------------------
_lfa_agent      = None   # LFAGenerator injected by scenario runner
_evasion_bandit = None   # EvasionBandit injected by scenario runner
_exp_manager    = None   # ExperimentManager injected by scenario runner
_congestion     = 0.0    # shared link-congestion signal
_lock           = threading.Lock()

CONGESTION_LFA_INC     = 0.08
CONGESTION_MIT_DECAY   = 0.85
CONGESTION_NORM_DECAY  = 0.98


def inject_agents(lfa_agent, evasion_bandit, exp_manager):
    """Called by scenario runner before Ryu starts its event loop."""
    global _lfa_agent, _evasion_bandit, _exp_manager
    _lfa_agent      = lfa_agent
    _evasion_bandit = evasion_bandit
    _exp_manager    = exp_manager


# ---------------------------------------------------------------------------
# Ryu Application
# ---------------------------------------------------------------------------

class LFAMultiAgentController(app_manager.RyuApp):
    """
    Ryu application implementing the closed-loop multi-agent LFA framework.
    """

    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._datapaths  = {}
        self._extractor  = FlowFeatureExtractor(idle_timeout_sec=30.0)
        self._port_util  = PortUtilizationTracker()
        self._timestamps = TimestampTracker()
        self._round_num  = 0

        log.info("Loading preprocessing pipeline...")
        self._pipeline = PreprocessingPipeline(
            preprocessor_path=PREPROCESSOR_PATH,
            feature_columns_path=FEATURE_COLUMNS_PATH,
        )
        log.info("Loading frozen Detection Agent...")
        self._detector = DetectionAgent(model_path=BEST_MODEL_GAN_PATH, device=DEVICE)
        log.info("Loading DQN Mitigation Agent...")
        self._mitigator = MitigationAgent(model_path=DQN_MITIGATION_PATH, device=DEVICE)

        # Set alternate-port default for reroute action (topology-dependent)
        self._alt_port = int(os.environ.get("SDN_ALT_PORT", "2"))

        # Start periodic stats loop
        self._stats_thread = hub.spawn(self._stats_loop)

    # ------------------------------------------------------------------
    # OpenFlow handshake
    # ------------------------------------------------------------------

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def _switch_features(self, ev):
        dp = ev.msg.datapath
        self._datapaths[dp.id] = dp
        self._install_table_miss(dp)
        log.info("Switch connected: dpid=%016x", dp.id)

    def _install_table_miss(self, dp):
        ofproto = dp.ofproto
        parser  = dp.ofproto_parser
        match   = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER,
                                           ofproto.OFPCML_NO_BUFFER)]
        instructions = [parser.OFPInstructionActions(
            ofproto.OFPIT_APPLY_ACTIONS, actions
        )]
        mod = parser.OFPFlowMod(
            datapath=dp, priority=0, match=match, instructions=instructions
        )
        dp.send_msg(mod)

    # ------------------------------------------------------------------
    # Periodic stats requests
    # ------------------------------------------------------------------

    def _stats_loop(self):
        while True:
            hub.sleep(STATS_INTERVAL)
            for dp in list(self._datapaths.values()):
                self._request_flow_stats(dp)
                self._request_port_stats(dp)

    def _request_flow_stats(self, dp):
        ofproto = dp.ofproto
        parser  = dp.ofproto_parser
        req = parser.OFPFlowStatsRequest(dp, 0, ofproto.OFPTT_ALL,
                                          ofproto.OFPP_ANY, ofproto.OFPG_ANY)
        dp.send_msg(req)
        self._timestamps.record("stats_request_sent", extra={"dpid": dp.id})

    def _request_port_stats(self, dp):
        parser = dp.ofproto_parser
        req    = parser.OFPPortStatsRequest(dp, 0, dp.ofproto.OFPP_ANY)
        dp.send_msg(req)

    # ------------------------------------------------------------------
    # Stats reply handlers
    # ------------------------------------------------------------------

    @set_ev_cls(ofp_event.EventOFPFlowStatsReply, MAIN_DISPATCHER)
    def _flow_stats_reply(self, ev):
        ts_stats_arrived = wall_ts()
        self._timestamps.record("stats_arrived", extra={"ts": ts_stats_arrived})

        dpid     = ev.msg.datapath.id
        raw_list = [flow_stats_to_dict(fs) for fs in ev.msg.body]
        self._extractor.update(dpid, raw_list, ts=ts_stats_arrived)

        self._timestamps.record("feature_extraction_start")
        feat_dicts = self._extractor.get_feature_dicts()
        if not feat_dicts:
            return

        import pandas as pd
        df      = pd.DataFrame(feat_dicts)
        X_batch = self._pipeline.transform(df)
        self._timestamps.record("feature_extraction_end",
                                extra={"n_flows": len(feat_dicts)})

        self._run_detection_and_mitigation(
            X_batch, feat_dicts, ev.msg.datapath, ts_stats_arrived
        )

    @set_ev_cls(ofp_event.EventOFPPortStatsReply, MAIN_DISPATCHER)
    def _port_stats_reply(self, ev):
        port_stats = [port_stats_to_dict(ps) for ps in ev.msg.body]
        util = self._port_util.update(port_stats)
        if _exp_manager:
            _exp_manager.log_port_utilization(util, wall_ts())

    # ------------------------------------------------------------------
    # Core inference + mitigation
    # ------------------------------------------------------------------

    def _run_detection_and_mitigation(self, X_batch, feat_dicts, dp, ts_stats):
        global _congestion

        self._timestamps.record("inference_start")
        probs, labels, det_latency = self._detector.predict(X_batch)
        self._timestamps.record("inference_end",
                                extra={"latency_ms": det_latency,
                                       "n_flows": len(X_batch)})

        mean_prob = float(np.asarray(probs).mean())

        # ---- Bandit feedback (Agent 1 ← Agent 2 confidence) ----
        if _evasion_bandit is not None and _lfa_agent is not None:
            self._round_num += 1
            arm_idx, e_str = _evasion_bandit.select()
            reward = 1.0 - mean_prob
            det_rate = float(np.asarray(labels).mean())
            _evasion_bandit.update(arm_idx, reward, mean_prob, det_rate,
                                   self._round_num)
            if _exp_manager:
                _exp_manager.log_bandit_update(
                    round_num=self._round_num,
                    arm_index=arm_idx,
                    evasion_strength=e_str,
                    reward=reward,
                    mean_pred_prob=mean_prob,
                    detection_rate=det_rate,
                    ts=wall_ts(),
                )

        # ---- Per-flow mitigation ----
        with _lock:
            for i, (feat, prob, label) in enumerate(zip(feat_dicts, probs, labels)):
                src_ip = feat.get("srcIP", "0.0.0.0")
                self._timestamps.record("mitigation_decision_start",
                                        extra={"flow_idx": i})
                action_idx, action_name, mit_latency = self._mitigator.act(
                    float(prob), X_batch[i], _congestion
                )
                self._timestamps.record("mitigation_decision_end",
                                        extra={"action": action_name,
                                               "latency_ms": mit_latency})

                # Apply the rule
                rule_ts = wall_ts()
                self._apply_mitigation(dp, action_idx, src_ip)
                self._timestamps.record("rule_installed",
                                        extra={"action": action_name,
                                               "src_ip": src_ip,
                                               "ts": wall_ts()})

                # Update congestion signal
                malicious = (int(label) == 1)
                _congestion = _update_congestion(
                    _congestion, action_idx, malicious
                )

                # Log to experiment manager (no ground-truth label passed here)
                if _exp_manager:
                    _exp_manager.log_flow_event(
                        ts=wall_ts(),
                        src_ip=src_ip,
                        pred_prob=float(prob),
                        pred_label=int(label),
                        action=action_name,
                        congestion=_congestion,
                        det_latency_ms=det_latency,
                        mit_latency_ms=mit_latency,
                    )

        # Flush timestamps once per stats cycle
        ts_summary = self._timestamps.summarize_cycle()
        if _exp_manager:
            _exp_manager.log_latency_cycle(ts_summary)
        self._timestamps.reset_cycle()

    def _apply_mitigation(self, dp, action_idx: int, src_ip: str):
        if action_idx == ACTION_BLOCK:
            install_blocking_rule(dp, src_ip)
        elif action_idx == ACTION_RATE_LIMIT:
            install_rate_limit_rule(dp, src_ip)
        elif action_idx == ACTION_MONITOR:
            install_monitor_rule(dp, src_ip)
        elif action_idx == ACTION_REROUTE:
            reroute_flow(dp, src_ip, self._alt_port)
        # ACTION_ALLOW → no rule; existing rules removed to restore normal forwarding
        elif action_idx == ACTION_ALLOW:
            remove_mitigation_rules(dp, src_ip)


def _update_congestion(congestion: float, action: int, is_malicious: bool) -> float:
    from config.settings import MITIGATION_ACTIONS
    mitigated = action in MITIGATION_ACTIONS
    if is_malicious:
        congestion = congestion * CONGESTION_MIT_DECAY if mitigated \
            else min(1.0, congestion + CONGESTION_LFA_INC)
    else:
        congestion *= CONGESTION_NORM_DECAY
    return congestion
