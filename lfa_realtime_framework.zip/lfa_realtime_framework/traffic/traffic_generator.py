"""
Controlled traffic generator.

Runs inside the Mininet network (requires root and Mininet).
Translates LFAGenerator output (via TrafficProfileTranslator) into
bounded iperf3 / hping3 invocations against testbed hosts.

All traffic stays within the isolated Mininet/OVS namespace — no
external network traffic is generated.
"""

import subprocess
import threading
import time
from typing import List, Optional

import numpy as np

from config.settings import (
    MAX_CONCURRENT_FLOWS, MAX_RATE_MBPS, STATS_INTERVAL,
)
from agents.lfa_agent import TrafficProfileTranslator
from utils.common import get_logger, wall_ts

log = get_logger(__name__)

try:
    from mininet.node import Host
    _HAS_MININET = True
except ImportError:
    _HAS_MININET = False


# ---------------------------------------------------------------------------
# Benign traffic generator
# ---------------------------------------------------------------------------

def run_benign_flow(src_host, dst_ip: str, duration_s: float = 10.0,
                    bandwidth_mbps: float = 1.0, protocol: str = "UDP",
                    dst_port: int = 5201):
    """Start one iperf3 flow from src_host → dst_ip (benign background)."""
    proto_flag = "-u" if protocol == "UDP" else ""
    cmd = (f"iperf3 -c {dst_ip} -t {int(duration_s)} "
           f"-b {bandwidth_mbps}M {proto_flag} -p {dst_port} &")
    src_host.cmd(cmd)
    log.debug("Benign flow: %s → %s  %g Mbps %s %gs",
              src_host.name, dst_ip, bandwidth_mbps, protocol, duration_s)


# ---------------------------------------------------------------------------
# LFA traffic generator (uses Agent 1 output)
# ---------------------------------------------------------------------------

class LFATrafficGenerator:
    """
    Converts GAN-generated feature profiles into controlled Mininet traffic.

    Security note: all flows target Mininet virtual hosts inside the OVS
    sandbox; no traffic leaves the isolated testbed.
    """

    def __init__(self, translator: TrafficProfileTranslator,
                 src_hosts: list, dst_hosts: list):
        self.translator      = translator
        self.src_hosts       = src_hosts
        self.dst_hosts       = dst_hosts
        self._active_procs   = []
        self._lock           = threading.Lock()

    def generate_and_launch(self, generated_X: np.ndarray,
                             n_flows_per_sample: int = 5) -> float:
        """
        For each row in generated_X translate to traffic params and start flows.
        Returns wall timestamp of generation start.
        """
        ts = wall_ts()
        for i, x in enumerate(generated_X[:MAX_CONCURRENT_FLOWS]):
            params_list = self.translator.translate(x, n_flows=n_flows_per_sample)
            src = self.src_hosts[i % len(self.src_hosts)]
            dst = self.dst_hosts[i % len(self.dst_hosts)]
            dst_ip = dst.IP() if _HAS_MININET and hasattr(dst, "IP") else str(dst)

            for p in params_list:
                self._launch_flow(src, dst_ip, p)
        return ts

    def _launch_flow(self, src_host, dst_ip: str, params: dict):
        bw   = min(params["bandwidth_mbps"], MAX_RATE_MBPS)
        dur  = params["duration_s"]
        port = params["dst_port"]
        proto = params.get("protocol", "UDP")
        proto_flag = "-u" if proto == "UDP" else ""
        cmd  = (f"iperf3 -c {dst_ip} -t {int(dur)} "
                f"-b {bw}M {proto_flag} -p {port} &")
        if _HAS_MININET and hasattr(src_host, "cmd"):
            src_host.cmd(cmd)
        else:
            log.debug("[stub] Would run: %s → %s : %s", src_host, dst_ip, cmd)

    def stop_all(self):
        """Kill all iperf3 processes on all source hosts."""
        for src in self.src_hosts:
            if _HAS_MININET and hasattr(src, "cmd"):
                src.cmd("killall -q iperf3")


# ---------------------------------------------------------------------------
# Iperf3 server (receiver side)
# ---------------------------------------------------------------------------

def start_iperf_servers(dst_hosts: list, port: int = 5201):
    for h in dst_hosts:
        if _HAS_MININET and hasattr(h, "cmd"):
            h.cmd(f"iperf3 -s -p {port} -D")
            log.debug("iperf3 server started on %s", h.name)


def stop_iperf_servers(dst_hosts: list):
    for h in dst_hosts:
        if _HAS_MININET and hasattr(h, "cmd"):
            h.cmd("killall -q iperf3")


# ---------------------------------------------------------------------------
# Conventional LFA (hping3 micro-flow flood) for comparison scenario
# ---------------------------------------------------------------------------

def conventional_lfa(src_hosts: list, dst_ip: str,
                     duration_s: float = 30.0,
                     n_flows_per_host: int = 10,
                     interval_us: int = 100):
    """
    Classic LFA: each src host sends n_flows_per_host hping3 UDP streams
    toward dst_ip.  Confined to Mininet namespace.
    """
    for src in src_hosts:
        for _ in range(n_flows_per_host):
            port = np.random.randint(1024, 49152)
            cmd  = (f"hping3 --udp -p {port} -i u{interval_us} "
                    f"--count {int(duration_s * 1e6 / interval_us)} {dst_ip} &")
            if _HAS_MININET and hasattr(src, "cmd"):
                src.cmd(cmd)
