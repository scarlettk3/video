"""
Mininet dumbbell topology for LFA experiments.

          h1 ─┐                   ┌─ h5
          h2 ─┤                   ├─ h6
          h3 ─┼─ s1 ══ s2 (bottleneck) ──┼─ s3 ─┤─ h7
          h4 ─┘                   └─ h8

The bottleneck link s1–s2 is where LFA congestion is measured.
All switches connect to the Ryu controller at CONTROLLER_IP:CONTROLLER_PORT.

Usage (run as root inside Mininet host):
    sudo python3 -m traffic.topology
"""

import os
import sys

from config.settings import (
    CONTROLLER_IP, CONTROLLER_PORT,
    TOPO_N_HOSTS, TOPO_BOTTLENECK_BW, TOPO_HOST_BW, TOPO_DELAY,
)
from utils.common import get_logger

log = get_logger(__name__)

try:
    from mininet.topo import Topo
    from mininet.net import Mininet
    from mininet.node import RemoteController, OVSKernelSwitch
    from mininet.link import TCLink
    from mininet.log import setLogLevel
    _HAS_MININET = True
except ImportError:
    _HAS_MININET = False
    log.warning("Mininet not installed — topology module is in stub mode.")


class DumbbellTopo(Topo if _HAS_MININET else object):
    """
    Dumbbell topology:
      - n_hosts hosts on each side
      - bottleneck_bw (Mbps) on the s1–s2 link
      - host_bw (Mbps) on all host links
    """

    def build(self, n_hosts: int = TOPO_N_HOSTS,
              bottleneck_bw: float = TOPO_BOTTLENECK_BW,
              host_bw: float = TOPO_HOST_BW,
              delay: str = TOPO_DELAY):

        # Core switches
        s1 = self.addSwitch("s1", cls=OVSKernelSwitch if _HAS_MININET else None,
                             protocols="OpenFlow13")
        s2 = self.addSwitch("s2", cls=OVSKernelSwitch if _HAS_MININET else None,
                             protocols="OpenFlow13")
        s3 = self.addSwitch("s3", cls=OVSKernelSwitch if _HAS_MININET else None,
                             protocols="OpenFlow13")

        # Bottleneck link
        self.addLink(s1, s2,
                     bw=bottleneck_bw, delay=delay, use_htb=True)
        self.addLink(s2, s3,
                     bw=bottleneck_bw, delay=delay, use_htb=True)

        # Left hosts (attackers / benign senders)
        for i in range(1, n_hosts + 1):
            h = self.addHost(f"h{i}", ip=f"10.0.0.{i}/24")
            self.addLink(h, s1, bw=host_bw, use_htb=True)

        # Right hosts (receivers)
        for i in range(n_hosts + 1, 2 * n_hosts + 1):
            h = self.addHost(f"h{i}", ip=f"10.0.0.{i}/24")
            self.addLink(h, s3, bw=host_bw, use_htb=True)


# ---------------------------------------------------------------------------
# Helper to build and return a Mininet object
# ---------------------------------------------------------------------------

def build_network(topo: "DumbbellTopo" = None,
                  n_hosts: int = TOPO_N_HOSTS,
                  bottleneck_bw: float = TOPO_BOTTLENECK_BW) -> "Mininet":
    if not _HAS_MININET:
        raise RuntimeError("Mininet is not installed.")
    setLogLevel("warning")
    topo = topo or DumbbellTopo(
        n_hosts=n_hosts,
        bottleneck_bw=bottleneck_bw,
    )
    controller = RemoteController("c0", ip=CONTROLLER_IP, port=CONTROLLER_PORT)
    net = Mininet(
        topo=topo,
        controller=controller,
        switch=OVSKernelSwitch,
        link=TCLink,
        autoSetMacs=True,
        autoStaticArp=True,
    )
    return net


# ---------------------------------------------------------------------------
# Unseen / generalization topologies
# ---------------------------------------------------------------------------

class LinearTopo(Topo if _HAS_MININET else object):
    """
    Linear chain: h1–s1–s2–…–sN–h(N+1)
    Used for generalization evaluation with a different topology.
    """

    def build(self, n_switches: int = 4, n_hosts_per_switch: int = 2,
              link_bw: float = TOPO_HOST_BW, delay: str = TOPO_DELAY):
        switches = [
            self.addSwitch(f"s{i+1}", protocols="OpenFlow13")
            for i in range(n_switches)
        ]
        for i in range(len(switches) - 1):
            self.addLink(switches[i], switches[i + 1],
                         bw=link_bw, delay=delay, use_htb=True)

        host_idx = 1
        for sw in switches:
            for _ in range(n_hosts_per_switch):
                h = self.addHost(f"h{host_idx}", ip=f"10.0.{host_idx // 256}.{host_idx % 256}/16")
                self.addLink(h, sw, bw=link_bw, use_htb=True)
                host_idx += 1


if __name__ == "__main__" and _HAS_MININET:
    from mininet.cli import CLI
    net = build_network()
    net.start()
    CLI(net)
    net.stop()
