"""
Closed-loop feedback orchestrator.

Runs as a separate thread alongside the Ryu controller:
  1. On each stats cycle, reads the latest mean_pred_prob from the controller.
  2. Calls EvasionBandit.select() → arm → evasion_strength.
  3. Calls LFAGenerator.generate_batch() → synthetic LFA feature vectors.
  4. Translates features → traffic params → launches Mininet flows.
  5. After the controller sends back updated pred_probs, calls EvasionBandit.update().
"""

import time
import threading
from typing import Callable, Optional

import numpy as np

from agents.lfa_agent import LFAGenerator, EvasionBandit, TrafficProfileTranslator
from experiment.timeline import RecoveryTimer, E_GEN_DECISION, E_TRAFFIC_START
from utils.common import get_logger, wall_ts

log = get_logger(__name__)


class FeedbackLoop:
    """
    Orchestrates the Agent 1 ← Agent 2 confidence feedback loop.

    Parameters
    ----------
    lfa_generator    : frozen LFAGenerator instance.
    evasion_bandit   : EvasionBandit instance.
    translator       : TrafficProfileTranslator.
    launch_traffic   : callable(params_list) that starts Mininet flows.
    get_mean_prob    : callable() → float — reads current detector mean_pred_prob.
    exp_manager      : ExperimentManager for logging (optional).
    interval_s       : seconds between generate-and-launch cycles (≈ STATS_INTERVAL).
    batch_size       : number of flows to generate per cycle.
    """

    def __init__(
        self,
        lfa_generator:  LFAGenerator,
        evasion_bandit: EvasionBandit,
        translator:     TrafficProfileTranslator,
        launch_traffic: Callable,
        get_mean_prob:  Callable[[], float],
        exp_manager=None,
        interval_s:     float = 5.0,
        batch_size:     int   = 16,
    ):
        self.gen      = lfa_generator
        self.bandit   = evasion_bandit
        self.trans    = translator
        self.launch   = launch_traffic
        self.get_prob = get_mean_prob
        self.mgr      = exp_manager
        self.interval = interval_s
        self.batch_sz = batch_size
        self._active  = False
        self._thread: Optional[threading.Thread] = None
        self._round   = 0

    def start(self):
        self._active = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        log.info("FeedbackLoop started (interval=%.1fs)", self.interval)

    def stop(self):
        self._active = False
        if self._thread:
            self._thread.join(timeout=self.interval * 2)
        log.info("FeedbackLoop stopped after %d rounds.", self._round)

    def _loop(self):
        while self._active:
            self._round += 1
            ts_gen = wall_ts()

            # 1. Select arm
            arm_idx, e_str = self.bandit.select()

            # 2. Generate LFA batch
            X_lfa = self.gen.generate_batch(self.batch_sz, e_str)

            # 3. Translate → launch traffic
            ts_traffic = wall_ts()
            params = []
            for x in X_lfa:
                params.extend(self.trans.translate(x, n_flows=3))
            self.launch(params)

            # 4. Wait one cycle for controller to observe and classify the traffic
            time.sleep(self.interval)

            # 5. Read detection confidence back from controller
            mean_prob = self.get_prob()
            det_rate  = 1.0 if mean_prob >= 0.5 else 0.0
            reward    = 1.0 - mean_prob

            # 6. Update bandit
            self.bandit.update(arm_idx, reward, mean_prob, det_rate, self._round)

            if self.mgr:
                self.mgr.log_bandit_update(
                    round_num=self._round,
                    arm_index=arm_idx,
                    evasion_strength=e_str,
                    reward=reward,
                    mean_pred_prob=mean_prob,
                    detection_rate=det_rate,
                    ts=wall_ts(),
                )

            log.debug("FeedbackLoop round=%d  e=%.2f  prob=%.3f  reward=%.3f",
                      self._round, e_str, mean_prob, reward)
