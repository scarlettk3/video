"""
Preprocessing pipeline — loads the fitted sklearn artifacts from the notebook
and applies the identical transformations to live OpenFlow feature dicts.

IMPORTANT: Only transform() is ever called here; fit() was done offline on the
training split. This prevents any data leakage.
"""

import json
from pathlib import Path
from typing import List, Optional

import joblib
import numpy as np
import pandas as pd

from config.settings import (
    PREPROCESSOR_PATH, LABEL_ENCODER_PATH, FEATURE_COLUMNS_PATH,
    LOG_TRANSFORM_COLUMNS, CATEGORICAL_COLUMNS, PORT_COLUMNS,
    SERVICE_PORTS, OTHER_NUMERIC_COLUMNS, DROP_COLUMNS, LABEL_COLUMN,
)
from utils.common import get_logger

log = get_logger(__name__)


def _bucket_port(port) -> str:
    if pd.isna(port):
        return "missing"
    try:
        p = int(float(port))
    except (ValueError, TypeError):
        return "missing"
    if 0 <= p <= 1023:
        return "well_known"
    elif 1024 <= p <= 49151:
        return "registered"
    elif 49152 <= p <= 65535:
        return "ephemeral"
    return "other"


class PreprocessingPipeline:
    """
    Wraps the saved ColumnTransformer from the notebook.
    transform(df) → float32 numpy array with the same column order used
    during training.
    """

    def __init__(
        self,
        preprocessor_path: Path = PREPROCESSOR_PATH,
        feature_columns_path: Path = FEATURE_COLUMNS_PATH,
        label_encoder_path: Optional[Path] = LABEL_ENCODER_PATH,
    ):
        preprocessor_path    = Path(preprocessor_path)
        feature_columns_path = Path(feature_columns_path)

        if not preprocessor_path.is_file():
            raise FileNotFoundError(f"Preprocessor not found: {preprocessor_path}")
        if not feature_columns_path.is_file():
            raise FileNotFoundError(f"Feature columns not found: {feature_columns_path}")

        self.preprocessor = joblib.load(preprocessor_path)
        with open(feature_columns_path) as fh:
            raw = json.load(fh)
        self.feature_names: List[str] = raw if isinstance(raw, list) else raw.get("feature_columns", raw)
        self.feature_dim = len(self.feature_names)

        self.label_encoder = None
        if label_encoder_path and Path(label_encoder_path).is_file():
            self.label_encoder = joblib.load(label_encoder_path)

        # Determine which raw column names the ColumnTransformer expects as input
        # (same order as build_and_fit_preprocessor in the notebook).
        ct = self.preprocessor
        cat_cols = list(ct.transformers_[0][2])
        num_cols = list(ct.transformers_[1][2])
        # remainder="passthrough" → all other columns not in cat or num
        used = set(cat_cols) | set(num_cols)
        # We can't know the passthrough names from the transformer alone;
        # we recover them from the fitted output feature names.
        ohe = ct.named_transformers_["cat"]
        n_cat_out = len(ohe.get_feature_names_out(cat_cols))
        n_num_out = len(num_cols)
        # Passthrough feature names are the tail of self.feature_names
        passthrough_names = self.feature_names[n_cat_out + n_num_out:]
        self._input_cols = cat_cols + num_cols + passthrough_names

        log.info("Pipeline ready — input_cols=%d, output_features=%d",
                 len(self._input_cols), self.feature_dim)

    # ------------------------------------------------------------------
    # Feature engineering helpers (replicate notebook exactly)
    # ------------------------------------------------------------------

    @staticmethod
    def _engineer(df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()

        # Port bucketing
        for col in PORT_COLUMNS:
            if col in df.columns:
                df[f"{col}_bucket"] = df[col].apply(_bucket_port)

        # Service-port binary flags
        for col in PORT_COLUMNS:
            if col not in df.columns:
                continue
            numeric = pd.to_numeric(df[col], errors="coerce")
            for svc in SERVICE_PORTS:
                df[f"{col}_svc_{svc}"] = (numeric == svc).astype(int)

        # log1p transform on skewed columns
        for col in LOG_TRANSFORM_COLUMNS:
            if col in df.columns:
                numeric = pd.to_numeric(df[col], errors="coerce").fillna(0)
                df[col] = np.log1p(numeric.clip(lower=0))

        # Drop raw port columns (replaced by bucket + service flags)
        df = df.drop(columns=[c for c in PORT_COLUMNS if c in df.columns])

        return df

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def transform(self, df: pd.DataFrame) -> np.ndarray:
        """
        Apply identical engineering + scaling as the notebook training pipeline.
        Input df may have extra columns (e.g. label); they are ignored.
        Returns float32 array of shape (n_rows, feature_dim).
        """
        df = self._engineer(df)

        # Fill any columns the live extractor couldn't populate
        for col in self._input_cols:
            if col not in df.columns:
                df[col] = 0

        X = self.preprocessor.transform(df[self._input_cols])
        return np.asarray(X, dtype=np.float32)

    def transform_single(self, feature_dict: dict) -> np.ndarray:
        """Convenience wrapper for a single flow dict → (1, feature_dim) array."""
        df = pd.DataFrame([feature_dict])
        return self.transform(df)
