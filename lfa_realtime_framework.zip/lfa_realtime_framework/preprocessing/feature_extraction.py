"""
Extract flow-level features from OpenFlow statistics collected by the Ryu controller.

The extractor maps per-flow OFPFlowStats / OFPPortStats counters to the
exact column schema used during offline training:
  duration, pktsSnt, pktsRcvd, pktps, bytps, pktAsm, bytAsm,
  minIAT, maxIAT, avgIAT, stdIAT, minL7PktSz, maxL7PktSz, avgL7PktSz, stdL7PktSz,
  l7BytesSnt, l7BytesRcvd, padBytesSnt, numHdrs, numHdrDesc,
  srcPort, dstPort, l4Proto, ethType, vlanID, %dir, flowStat

Ground-truth fields (attack_label, session_id, etc.) are NEVER added here;
they stay in the ExperimentManager only.
"""

import time
from collections import defaultdict, deque
from typing import Dict, List, Optional

import numpy as np

from utils.common import get_logger

log = get_logger(__name__)

# Match the OF match field names Ryu uses
PROTO_MAP = {1: "ICMP", 6: "TCP", 17: "UDP"}


class FlowRecord:
    """Running accumulators for a single (datapath, cookie, match) flow entry."""

    __slots__ = (
        "dpid", "cookie", "src_ip", "dst_ip", "src_port", "dst_port",
        "proto", "eth_type", "vlan_id", "direction",
        "byte_count", "packet_count", "duration_sec", "duration_nsec",
        "prev_bytes", "prev_pkts", "prev_ts",
        "iat_samples", "pkt_size_samples",
        "first_seen_ts", "last_seen_ts",
    )

    def __init__(self, dpid, cookie, match: dict, ts: float):
        self.dpid     = dpid
        self.cookie   = cookie
        self.src_ip   = match.get("ipv4_src", "0.0.0.0")
        self.dst_ip   = match.get("ipv4_dst", "0.0.0.0")
        self.src_port = int(match.get("tcp_src", match.get("udp_src", 0)))
        self.dst_port = int(match.get("tcp_dst", match.get("udp_dst", 0)))
        self.proto    = int(match.get("ip_proto", 0))
        self.eth_type = int(match.get("eth_type", 0x0800))
        self.vlan_id  = int(match.get("vlan_vid", 0)) & 0x0FFF
        self.direction = "fwd"

        self.byte_count   = 0
        self.packet_count = 0
        self.duration_sec  = 0
        self.duration_nsec = 0

        self.prev_bytes = 0
        self.prev_pkts  = 0
        self.prev_ts    = ts

        self.iat_samples      = deque(maxlen=200)
        self.pkt_size_samples = deque(maxlen=200)

        self.first_seen_ts = ts
        self.last_seen_ts  = ts

    def update(self, byte_count: int, packet_count: int,
               duration_sec: int, duration_nsec: int, ts: float):
        delta_pkts  = max(0, packet_count - self.prev_pkts)
        delta_bytes = max(0, byte_count   - self.prev_bytes)
        dt = max(1e-6, ts - self.prev_ts)

        if delta_pkts > 0:
            avg_pkt = delta_bytes / delta_pkts
            self.pkt_size_samples.append(avg_pkt)
            self.iat_samples.append(dt / delta_pkts)

        self.byte_count    = byte_count
        self.packet_count  = packet_count
        self.duration_sec  = duration_sec
        self.duration_nsec = duration_nsec
        self.prev_bytes    = byte_count
        self.prev_pkts     = packet_count
        self.prev_ts       = ts
        self.last_seen_ts  = ts

    def to_feature_dict(self) -> dict:
        """Convert accumulators into the training-schema column dict."""
        dur = max(1e-6, self.duration_sec + self.duration_nsec * 1e-9)

        pkts_snt  = self.packet_count
        pkts_rcvd = 0          # symmetric flow stats require opposite direction flow
        bytes_snt = self.byte_count

        pktps = pkts_snt / dur
        bytps = bytes_snt / dur

        iat = np.asarray(self.iat_samples, dtype=np.float32)
        psz = np.asarray(self.pkt_size_samples, dtype=np.float32)

        min_iat = float(iat.min())   if len(iat) else 0.0
        max_iat = float(iat.max())   if len(iat) else 0.0
        avg_iat = float(iat.mean())  if len(iat) else 0.0
        std_iat = float(iat.std())   if len(iat) else 0.0

        min_psz = float(psz.min())   if len(psz) else 0.0
        max_psz = float(psz.max())   if len(psz) else 0.0
        avg_psz = float(psz.mean())  if len(psz) else 0.0
        std_psz = float(psz.std())   if len(psz) else 0.0

        total_bytes = self.byte_count
        l7_bytes_snt  = max(0, total_bytes - pkts_snt * 40)
        l7_bytes_rcvd = 0

        # pktAsm = (snt - rcvd) / (snt + rcvd)
        pkt_total = pkts_snt + pkts_rcvd
        pkt_asm   = (pkts_snt - pkts_rcvd) / pkt_total if pkt_total > 0 else 0.0
        byt_total = total_bytes
        byt_asm   = 1.0   # only sending direction available

        proto_str = PROTO_MAP.get(self.proto, str(self.proto))
        eth_str   = hex(self.eth_type)

        return {
            "duration":      dur,
            "pktsSnt":       pkts_snt,
            "pktsRcvd":      pkts_rcvd,
            "padBytesSnt":   max(0, pkts_snt * 14 - total_bytes),
            "l7BytesSnt":    l7_bytes_snt,
            "l7BytesRcvd":   l7_bytes_rcvd,
            "minL7PktSz":    min_psz,
            "maxL7PktSz":    max_psz,
            "avgL7PktSz":    avg_psz,
            "stdL7PktSz":    std_psz,
            "minIAT":        min_iat,
            "maxIAT":        max_iat,
            "avgIAT":        avg_iat,
            "stdIAT":        std_iat,
            "pktps":         pktps,
            "bytps":         bytps,
            "pktAsm":        pkt_asm,
            "bytAsm":        byt_asm,
            "numHdrs":       1,
            "numHdrDesc":    1,
            "srcPort":       self.src_port,
            "dstPort":       self.dst_port,
            "l4Proto":       proto_str,
            "ethType":       eth_str,
            "vlanID":        self.vlan_id,
            "%dir":          self.direction,
            "flowStat":      "active",
        }


class FlowFeatureExtractor:
    """
    Maintains a dict of FlowRecord keyed by (dpid, cookie).
    Called by the Ryu stats reply handler.
    """

    def __init__(self, idle_timeout_sec: float = 30.0):
        self._flows: Dict[tuple, FlowRecord] = {}
        self._idle_timeout = idle_timeout_sec

    def update(self, dpid: int, flow_stats_list: list, ts: Optional[float] = None):
        """
        Process a list of OFPFlowStats-like dicts received from the switch.
        Each item must have: cookie, match, byte_count, packet_count,
                             duration_sec, duration_nsec.
        """
        ts = ts or time.time()
        for fs in flow_stats_list:
            cookie = int(fs.get("cookie", 0))
            key    = (dpid, cookie)
            match  = fs.get("match", {})

            if key not in self._flows:
                self._flows[key] = FlowRecord(dpid, cookie, match, ts)

            self._flows[key].update(
                int(fs.get("byte_count", 0)),
                int(fs.get("packet_count", 0)),
                int(fs.get("duration_sec", 0)),
                int(fs.get("duration_nsec", 0)),
                ts,
            )

        # Expire stale flows
        stale = [k for k, v in self._flows.items()
                 if ts - v.last_seen_ts > self._idle_timeout]
        for k in stale:
            del self._flows[k]

    def get_feature_dicts(self) -> List[dict]:
        """Return one feature dict per active flow."""
        return [fr.to_feature_dict() for fr in self._flows.values()]

    def flow_count(self) -> int:
        return len(self._flows)
