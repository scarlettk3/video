"""
Agent 1 — LFA Traffic Generation Agent.

Components:
  1. LFAProfile  — data-driven attack sub-cluster statistics computed once
                   from the training/validation distribution.
  2. LFAGenerator — frozen GAN + blended LFA-profile projection.
  3. EvasionBandit — epsilon-greedy controller over evasion-strength arms
                     whose reward is: 1 − DetectionAgent.mean_pred_prob.
  4. TrafficProfileTranslator — maps generated feature vectors to bounded
                                Mininet iperf/hping parameters.

The GAN Generator is NEVER retrained here.
"""

import time
from collections import deque
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch

from config.settings import (
    DEVICE, GAN_GENERATOR_PATH, GAN_NOISE_DIM,
    EVASION_STRENGTHS, BANDIT_EPSILON, BANDIT_SEED,
    LFA_BATCH_SIZE, MAX_RATE_MBPS, MIN_FLOW_DURATION_S,
    MAX_FLOW_DURATION_S, MAX_CONCURRENT_FLOWS,
)
from models.model_loader import load_generator
from utils.common import get_logger, wall_ts

log = get_logger(__name__)


# ---------------------------------------------------------------------------
# Inverse scaling helper (matches GAN training exactly)
# ---------------------------------------------------------------------------

def _from_unit_range(X_unit: np.ndarray, X_min: np.ndarray, X_max: np.ndarray) -> np.ndarray:
    return ((X_unit + 1.0) / 2.0) * (X_max - X_min) + X_min


# ---------------------------------------------------------------------------
# LFA Feature Profile
# ---------------------------------------------------------------------------

class LFAProfile:
    """
    Per-feature target statistics derived from a real attack sub-cluster.
    feature_index maps feature name → column index in the feature matrix.
    """

    def __init__(self, feature_names: List[str], attack_X: np.ndarray,
                 cluster_fraction: float = 0.30):
        self.feature_names  = feature_names
        self.feature_index  = {n: i for i, n in enumerate(feature_names)}
        self.feature_dim    = len(feature_names)

        # Select the top-30% attack rows by high-pktps / short-duration score
        if len(attack_X) == 0:
            raise ValueError("No attack rows provided for LFAProfile.")

        def _zscore(col):
            return (col - col.mean()) / (col.std() + 1e-8)

        score = np.zeros(len(attack_X), dtype=np.float32)
        for name in ("pktps", "bytps"):
            if name in self.feature_index:
                score += _zscore(attack_X[:, self.feature_index[name]])
        if "duration" in self.feature_index:
            score -= _zscore(attack_X[:, self.feature_index["duration"]])

        k = max(50, int(cluster_fraction * len(attack_X)))
        k = min(k, len(attack_X))
        idx = np.argsort(score)[-k:]
        cluster = attack_X[idx]

        # LFA-relevant feature names
        lfa_names = [n for n in ("pktps", "bytps", "pktAsm", "bytAsm", "duration")
                     if n in self.feature_index]
        # Add most ATTACK-correlated categorical / port feature
        labels = np.concatenate([np.zeros(len(attack_X)), np.ones(len(attack_X))])
        cat_prefixes = ("l4Proto", "srcPort_bucket", "dstPort_bucket",
                        "%dir", "flowStat", "ethType", "vlanID")
        best_feat, best_corr = None, 0.0
        all_X = attack_X  # for correlation, use full attack set against mock labels
        for name in feature_names:
            if not (name.startswith(cat_prefixes) or "_svc_" in name):
                continue
            col = all_X[:, self.feature_index[name]].astype(float)
            if col.std() < 1e-8:
                continue
            c = float(np.corrcoef(col, np.ones(len(col)))[0, 1])
            if np.isfinite(c) and abs(c) > abs(best_corr):
                best_corr, best_feat = c, name
        if best_feat and best_feat not in lfa_names:
            lfa_names.append(best_feat)

        self.lfa_feature_names   = lfa_names
        self.lfa_feature_indices = [self.feature_index[n] for n in lfa_names]
        self.target_means = {
            n: float(cluster[:, self.feature_index[n]].mean())
            for n in lfa_names
        }
        self.cluster_size = len(cluster)
        log.info("LFAProfile: %d-row sub-cluster, projected features=%s",
                 self.cluster_size, lfa_names)


# ---------------------------------------------------------------------------
# LFA Generator
# ---------------------------------------------------------------------------

class LFAGenerator:
    """
    Frozen GAN + LFA-profile projection.
    generate_batch(n, e) returns (n, feature_dim) float32 array.
    e=0 → pure GAN; e=1 → fully projected to LFA-cluster means.
    """

    def __init__(self, profile: LFAProfile, gen_path: Path = GAN_GENERATOR_PATH,
                 device=None):
        self.device  = device or DEVICE
        self.profile = profile

        gen_path = Path(gen_path)
        log.info("Loading frozen GAN generator from %s", gen_path.name)
        self.generator, self.noise_dim, self.X_min, self.X_max = \
            load_generator(gen_path, self.device)

        if self.generator.net[-2].out_features != profile.feature_dim:
            log.warning("GAN output dim mismatch — generator may be incompatible.")

        self._profile_indices  = np.asarray(profile.lfa_feature_indices, dtype=np.int64)
        self._profile_means    = np.asarray(
            [profile.target_means[n] for n in profile.lfa_feature_names],
            dtype=np.float32,
        )

    def _project(self, X: np.ndarray) -> np.ndarray:
        X_p = X.copy()
        for pos, idx in enumerate(self._profile_indices):
            X_p[:, idx] = self._profile_means[pos]
        return X_p

    @torch.no_grad()
    def generate_batch(self, batch_size: int, evasion_strength: float) -> np.ndarray:
        evasion_strength = float(np.clip(evasion_strength, 0.0, 1.0))
        z = torch.randn(batch_size, self.noise_dim, device=self.device)
        X_unit = self.generator(z).cpu().numpy().astype(np.float32)
        X_raw  = _from_unit_range(X_unit, self.X_min, self.X_max).astype(np.float32)
        X_proj = self._project(X_raw)
        X_lfa  = (1.0 - evasion_strength) * X_raw + evasion_strength * X_proj
        return X_lfa.astype(np.float32)


# ---------------------------------------------------------------------------
# Epsilon-greedy evasion bandit
# ---------------------------------------------------------------------------

class EvasionBandit:
    """
    Epsilon-greedy multi-armed bandit over discrete evasion-strength arms.

    Reward signal: r = 1 − mean_pred_prob  (fed back by the closed loop).
    Higher reward → generated samples evade the detector more.
    """

    def __init__(self, arms: List[float] = EVASION_STRENGTHS,
                 epsilon: float = BANDIT_EPSILON, seed: int = BANDIT_SEED):
        self.arms    = [float(a) for a in arms]
        self.epsilon = float(epsilon)
        self.values  = np.zeros(len(arms), dtype=np.float64)
        self.counts  = np.zeros(len(arms), dtype=np.int64)
        self._rng    = np.random.RandomState(seed)
        self.history: List[dict] = []

    def select(self) -> Tuple[int, float]:
        """Returns (arm_index, evasion_strength)."""
        if self._rng.random_sample() < self.epsilon:
            idx = int(self._rng.randint(0, len(self.arms)))
        else:
            best = self.values.max()
            ties = np.flatnonzero(np.isclose(self.values, best))
            idx  = int(self._rng.choice(ties))
        return idx, self.arms[idx]

    def update(self, arm_index: int, reward: float, mean_pred_prob: float,
               detection_rate: float, round_num: int):
        self.counts[arm_index] += 1
        n = self.counts[arm_index]
        self.values[arm_index] += (reward - self.values[arm_index]) / n
        self.history.append({
            "round":          round_num,
            "arm_index":      arm_index,
            "evasion_strength": self.arms[arm_index],
            "reward":         reward,
            "mean_pred_prob": mean_pred_prob,
            "detection_rate": detection_rate,
            "ts":             wall_ts(),
        })

    def best_strength(self) -> float:
        return self.arms[int(np.argmax(self.values))]

    def arm_summary(self) -> dict:
        return {str(a): {"value": float(v), "count": int(c)}
                for a, v, c in zip(self.arms, self.values, self.counts)}


# ---------------------------------------------------------------------------
# Traffic profile → Mininet parameters
# ---------------------------------------------------------------------------

class TrafficProfileTranslator:
    """
    Maps a (1, feature_dim) GAN-generated feature vector to bounded iperf/hping
    parameters safe to use in a Mininet/OVS testbed.

    The generated features are in the preprocessed (log1p-scaled, RobustScaled)
    space. We invert the log1p transform to get approximate raw values, then
    clip to testbed-safe bounds.
    """

    def __init__(self, feature_names: List[str],
                 max_rate_mbps: float = MAX_RATE_MBPS,
                 min_dur_s: float = MIN_FLOW_DURATION_S,
                 max_dur_s: float = MAX_FLOW_DURATION_S,
                 max_concurrent: int = MAX_CONCURRENT_FLOWS):
        self.fi           = {n: i for i, n in enumerate(feature_names)}
        self.max_rate     = max_rate_mbps
        self.min_dur      = min_dur_s
        self.max_dur      = max_dur_s
        self.max_flows    = max_concurrent

    def _get(self, x: np.ndarray, name: str, default: float = 0.0) -> float:
        if name in self.fi:
            val = float(x[self.fi[name]])
            return float(np.expm1(max(0.0, val)))   # invert log1p
        return default

    def translate(self, x: np.ndarray, n_flows: int = 10) -> List[dict]:
        """
        Parameters
        ----------
        x        : (feature_dim,) array for a single generated sample.
        n_flows  : number of parallel micro-flows to represent this profile.
        Returns
        -------
        List of dicts, each describing one iperf3 invocation:
            {bandwidth_mbps, duration_s, protocol, dst_port}
        """
        x = np.asarray(x, dtype=np.float32).ravel()
        n_flows = min(n_flows, self.max_flows)

        raw_bytps  = self._get(x, "bytps", 1e4)
        raw_dur    = self._get(x, "duration", 5.0)

        # Per-flow bandwidth: distribute total across micro-flows, then cap
        per_flow_bw = min(self.max_rate, (raw_bytps * 8 / 1e6) / max(1, n_flows))
        per_flow_bw = max(0.001, per_flow_bw)
        duration    = float(np.clip(raw_dur, self.min_dur, self.max_dur))

        proto = "UDP"  # LFA typically uses UDP micro-flows
        params = []
        for _ in range(n_flows):
            params.append({
                "bandwidth_mbps": round(per_flow_bw, 4),
                "duration_s":     round(duration, 2),
                "protocol":       proto,
                "dst_port":       random_unprivileged_port(),
            })
        return params


def random_unprivileged_port() -> int:
    """Random unprivileged port (1024-49151) for generated micro-flows."""
    import random
    return random.randint(1024, 49151)
