"""
Agent 3 — DQN Mitigation Agent (frozen inference only).

Loads the trained QNetwork policy checkpoint and selects actions using
argmax (no exploration at evaluation time).
"""

import time
from pathlib import Path
from typing import Tuple

import numpy as np
import torch

from config.settings import (
    DEVICE, DQN_MITIGATION_PATH, ACTION_NAMES, N_ACTIONS, MITIGATION_ACTIONS,
)
from models.model_loader import load_dqn
from utils.common import get_logger

log = get_logger(__name__)


class MitigationAgent:
    """
    Wraps the trained DQN policy.
    act(pred_prob, flow_features, congestion) → action_index.
    State = [pred_prob] + flow_features + [congestion]  (matches offline training).
    """

    def __init__(self, model_path: Path = DQN_MITIGATION_PATH, device=None):
        self.device     = device or DEVICE
        self.model_path = Path(model_path)
        log.info("Loading DQN mitigation policy from %s", self.model_path.name)
        self.net, self.state_dim, self.n_actions = load_dqn(self.model_path, self.device)
        self._latency_buf = []

    @torch.no_grad()
    def act(self, pred_prob: float, flow_features: np.ndarray,
            congestion: float) -> Tuple[int, str, float]:
        """
        Parameters
        ----------
        pred_prob    : float — detector attack confidence for this flow.
        flow_features: (feature_dim,) float32.
        congestion   : float in [0, 1] — current link congestion signal.
        Returns
        -------
        (action_index, action_name, latency_ms)
        """
        state = np.concatenate(
            [[float(pred_prob)],
             np.asarray(flow_features, dtype=np.float32).ravel(),
             [float(congestion)]],
        ).astype(np.float32)

        if len(state) != self.state_dim:
            raise ValueError(
                f"State dim mismatch: got {len(state)}, expected {self.state_dim}"
            )

        t0 = time.perf_counter()
        s  = torch.as_tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        action_idx = int(self.net(s).argmax(dim=1).item())
        latency_ms = (time.perf_counter() - t0) * 1000.0

        self._latency_buf.append(latency_ms)
        if len(self._latency_buf) > 500:
            self._latency_buf.pop(0)

        return action_idx, ACTION_NAMES[action_idx], latency_ms

    def latency_stats(self) -> dict:
        buf = np.asarray(self._latency_buf)
        if len(buf) == 0:
            return {}
        return {
            "mean_ms":   float(buf.mean()),
            "median_ms": float(np.median(buf)),
            "p95_ms":    float(np.percentile(buf, 95)),
            "n_calls":   len(buf),
        }
