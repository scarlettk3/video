"""
Agent 2 — frozen ENAS + GAN detection agent.

Wraps the saved ConfigurableMLP checkpoint. All parameters are frozen.
Provides batch inference and single-flow inference with latency tracking.
"""

import time
from pathlib import Path
from typing import Tuple

import numpy as np
import torch

from config.settings import DEVICE, BEST_MODEL_GAN_PATH, BEST_MODEL_NO_GAN_PATH
from models.model_loader import load_detector
from utils.common import get_logger

log = get_logger(__name__)


class DetectionAgent:
    """
    Frozen ENAS + GAN binary classifier for real-time LFA detection.

    predict() never accesses ground-truth labels, attack session IDs,
    or any information that would not be available from live SDN telemetry.
    """

    def __init__(self, model_path: Path = None, device=None):
        if model_path is None:
            # Prefer the GAN-augmented model; fall back to no-GAN
            model_path = (
                BEST_MODEL_GAN_PATH if Path(BEST_MODEL_GAN_PATH).is_file()
                else BEST_MODEL_NO_GAN_PATH
            )
        self.model_path = Path(model_path)
        self.device     = device or DEVICE

        log.info("Loading frozen detector from %s", self.model_path.name)
        self.model, self.input_dim = load_detector(self.model_path, self.device)

        # Inference latency ring buffer (last 500 calls, ms)
        self._latency_buf = []

    # ------------------------------------------------------------------

    @torch.no_grad()
    def predict(
        self,
        X: np.ndarray,
        batch_size: int = 8192,
    ) -> Tuple[np.ndarray, np.ndarray, float]:
        """
        Parameters
        ----------
        X : (n, feature_dim) float32 array — preprocessed flows.
        Returns
        -------
        probs  : (n,) float32 — attack probability per flow.
        labels : (n,) int64  — binary prediction at 0.5 threshold.
        latency_ms : wall-clock inference duration in milliseconds.
        """
        X = np.asarray(X, dtype=np.float32)
        single = X.ndim == 1
        if single:
            X = X[None, :]

        if X.shape[1] != self.input_dim:
            raise ValueError(
                f"Feature dim mismatch: got {X.shape[1]}, expected {self.input_dim}"
            )

        t0 = time.perf_counter()
        all_probs = []
        for start in range(0, len(X), batch_size):
            xb = torch.as_tensor(X[start:start + batch_size],
                                 dtype=torch.float32, device=self.device)
            logits = self.model(xb)
            all_probs.append(torch.sigmoid(logits).cpu().numpy().reshape(-1))
        t1 = time.perf_counter()

        latency_ms = (t1 - t0) * 1000.0
        self._latency_buf.append(latency_ms)
        if len(self._latency_buf) > 500:
            self._latency_buf.pop(0)

        probs  = np.concatenate(all_probs).astype(np.float32)
        labels = (probs >= 0.5).astype(np.int64)

        if single:
            return probs[0], labels[0], latency_ms
        return probs, labels, latency_ms

    def mean_pred_prob(self, X: np.ndarray) -> float:
        """Return average attack probability over a batch (used for bandit reward)."""
        probs, _, _ = self.predict(X)
        return float(np.asarray(probs).mean())

    def latency_stats(self) -> dict:
        buf = np.asarray(self._latency_buf)
        if len(buf) == 0:
            return {}
        return {
            "mean_ms":   float(buf.mean()),
            "median_ms": float(np.median(buf)),
            "p95_ms":    float(np.percentile(buf, 95)),
            "p99_ms":    float(np.percentile(buf, 99)),
            "n_calls":   len(buf),
        }
