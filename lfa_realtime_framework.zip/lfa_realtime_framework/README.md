# Real-Time LFA Multi-Agent Framework

A closed-loop, real-time multi-agent system for detecting and mitigating
**Link Flooding Attacks (LFA)** in an SDN environment using Ryu and Mininet/OVS.

## Architecture

```
Frozen GAN + Bandit
      ↓  (generate LFA traffic, translate → Mininet iperf flows)
SDN Network  (Mininet dumbbell topology, OVS switches)
      ↓  (OpenFlow stats via Ryu)
Feature Extraction → PreprocessingPipeline (same scaler as training)
      ↓
Frozen ENAS+GAN Detector (Agent 2) → pred_prob, label
      ↓                         ↑ confidence fed back to bandit
DQN Mitigation Agent (Agent 3) → action
      ↓
Ryu OpenFlow rule install (block / rate-limit / reroute / monitor / allow)
      ↓
ExperimentManager — ground-truth log (isolated), flow-event log, timestamp log
```

## Directory Structure

```
lfa_realtime_framework/
├── config/
│   └── settings.py           # ← INSERT YOUR ARTIFACT PATHS HERE
├── models/
│   ├── mlp.py                # ConfigurableMLP (matches notebook checkpoint)
│   ├── generator.py          # GAN Generator   (matches notebook checkpoint)
│   ├── dqn.py                # QNetwork + ReplayBuffer
│   └── model_loader.py       # Checkpoint loaders (detector / generator / DQN)
├── preprocessing/
│   ├── pipeline.py           # Loads sklearn preprocessor, applies offline pipeline
│   └── feature_extraction.py # OpenFlow stats → feature dict per flow
├── agents/
│   ├── detection_agent.py    # Agent 2: frozen ENAS+GAN wrapper
│   ├── lfa_agent.py          # Agent 1: LFAProfile + LFAGenerator + EvasionBandit
│   └── mitigation_agent.py   # Agent 3: frozen DQN policy wrapper
├── sdn/
│   ├── ryu_controller.py     # Main Ryu application (the integration hub)
│   ├── openflow_stats.py     # OFP stats parsers + port utilization tracker
│   └── mitigation_actions.py # OpenFlow rule helpers (block/rate/reroute/monitor)
├── traffic/
│   ├── topology.py           # Mininet dumbbell + linear topologies
│   └── traffic_generator.py  # iperf3/hping3 traffic gen (testbed-confined)
├── experiment/
│   ├── manager.py            # Ground-truth logger + flow-event logger
│   ├── timeline.py           # Per-cycle timestamp tracker + recovery timer
│   └── scenarios.py          # Scenario definitions (benign/conv/GAN/adaptive/alternating)
├── evaluation/
│   ├── metrics.py            # Detection / generation / mitigation metrics
│   └── plotter.py            # Synchronized multi-panel plots (7 figures)
├── runtime/
│   └── feedback_loop.py      # Agent 1 ← Agent 2 confidence feedback thread
├── run_experiment.py         # Main entry point (sudo python3 run_experiment.py)
└── requirements.txt
```

## Quick Start

### 1 — Patch the artifact paths

Open `config/settings.py` and update `ARTIFACTS_ROOT` to point to the
`artifacts/` directory produced by `sdn-security-framework1-FIXED.ipynb`:

```python
ARTIFACTS_ROOT = Path("/path/to/your/notebook/artifacts")
```

The following checkpoint files must exist:
| Variable | Default path |
|---|---|
| `PREPROCESSOR_PATH` | `artifacts/processed/preprocessor.pkl` |
| `FEATURE_COLUMNS_PATH` | `artifacts/processed/feature_columns.json` |
| `BEST_MODEL_GAN_PATH` | `artifacts/enas/best_model_gan.pt` |
| `GAN_GENERATOR_PATH` | `artifacts/gan/generator.pt` |
| `DQN_MITIGATION_PATH` | `artifacts/dqn_mitigation/mitigation_policy.pt` |

### 2 — Install dependencies (Ubuntu/Debian, Python 3.8+)

```bash
pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
pip install ryu scikit-learn joblib pandas matplotlib seaborn

# Mininet (required to run live experiments; skip for evaluation-only mode)
git clone https://github.com/mininet/mininet
mininet/util/install.sh -a
```

### 3 — Start the Ryu controller

```bash
ryu-manager sdn/ryu_controller.py --ofp-tcp-listen-port 6653
```

### 4 — Run an experiment (new terminal, requires root for Mininet)

```bash
# Single scenario
sudo python3 run_experiment.py --scenario alternating

# All four scenarios
sudo python3 run_experiment.py --all-scenarios

# Evaluation-only (no Mininet, uses logged data)
python3 run_experiment.py --scenario benign_only --no-mininet
```

### 5 — View results

Plots are written to `results/plots/`.  
Metrics JSON files are written to `results/`.  
Ground-truth log (never used by the detector): `results/logs/ground_truth.jsonl`.

---

## Experimental Scenarios

| Scenario | Description |
|---|---|
| `benign_only` | Baseline — no attack; measures FPR and normal latency |
| `conventional_lfa` | hping3 UDP micro-flow flood from left hosts |
| `gan_lfa` | Frozen GAN generates LFA profiles at fixed evasion_strength=0.5 |
| `adaptive_lfa` | Bandit dynamically selects evasion strength based on detector confidence |
| `unseen_topology` | Linear chain topology — tests generalisation |
| `alternating` | Benign→conv LFA→Benign→adaptive LFA→Benign (live transitions) |

---

## Metrics Collected

### Detection Agent (Agent 2)
Accuracy · Precision · Recall · F1 · ROC-AUC · FPR · FNR · Detection Latency

### LFA Generation Agent (Agent 1)
Attack Effectiveness · Link Congestion · Evasion Success Rate ·
Detector Confidence over Time · Bandit Arm Selection Distribution

### DQN Mitigation Agent (Agent 3)
Congestion Reduction · Network Recovery Time · Legitimate Throughput Retained ·
Unnecessary Mitigation Rate · Action Distribution ·
Link Utilization Before/After

### System Latency (per stats cycle)
Observation · Feature Extraction · Model Inference · End-to-End Detection ·
Mitigation Decision · Rule Installation · Total Response

---

## Real-Time Operation Definition

The system operates in real time when **feature extraction + model inference
complete within one statistics monitoring window** (`STATS_INTERVAL = 5s`).
Both steps complete in < 50 ms on CPU (measured in the notebook), leaving
> 4.95 s of margin per cycle.  The `TimestampTracker` records every component
latency so this claim is independently verifiable from `results/logs/timestamps.jsonl`.

---

## Security Note

All LFA traffic is generated exclusively within the isolated Mininet/OVS
virtual network. No traffic is directed at external hosts or public networks.
The `MAX_RATE_MBPS` and `MAX_CONCURRENT_FLOWS` caps in `config/settings.py`
enforce safe testbed bounds.

---

## Frozen Model Guarantee

`DetectionAgent`, `LFAGenerator`, and `MitigationAgent` all call
`parameter.requires_grad_(False)` and never call `model.train()` or run an
optimiser step. Architectures are loaded from checkpoints and not re-defined.
