"""
Experiment Manager and Ground-Truth Logger.

Records:
  - Attack/benign segment boundaries with timestamps.
  - Generator mode selected per round (arm_index, evasion_strength).
  - Target link.
  - All system timestamps (passed in from the controller).
  - Per-flow events (without the ground-truth label).

Ground-truth labels are stored SEPARATELY in ground_truth.jsonl and are
NEVER forwarded to the Detection Agent.
"""

import json
import threading
from pathlib import Path
from typing import Dict, List, Optional

from config.settings import (
    GROUND_TRUTH_LOG, SYSTEM_EVENT_LOG, TIMESTAMP_LOG, METRICS_LOG,
)
from utils.common import append_jsonl, wall_ts, get_logger

log = get_logger(__name__)

_lock = threading.Lock()


class ExperimentManager:
    """
    Central logger for the multi-agent framework.
    Keeps ground-truth fully separated from feature/inference logs.
    """

    def __init__(self,
                 gt_log:    Path = GROUND_TRUTH_LOG,
                 ev_log:    Path = SYSTEM_EVENT_LOG,
                 ts_log:    Path = TIMESTAMP_LOG,
                 met_log:   Path = METRICS_LOG):
        self.gt_log  = Path(gt_log)
        self.ev_log  = Path(ev_log)
        self.ts_log  = Path(ts_log)
        self.met_log = Path(met_log)

        self._session_id: Optional[str] = None
        self._current_segment: Optional[dict] = None
        self._congestion_history: List[float] = []
        self._port_util_history:  List[dict]  = []

    # ------------------------------------------------------------------
    # Session / Segment management
    # ------------------------------------------------------------------

    def start_session(self, session_id: str, scenario: str):
        self._session_id = session_id
        self._append_ev({
            "type": "session_start",
            "session_id": session_id,
            "scenario": scenario,
            "ts": wall_ts(),
        })
        log.info("Experiment session started: %s (%s)", session_id, scenario)

    def end_session(self):
        self._append_ev({
            "type": "session_end",
            "session_id": self._session_id,
            "ts": wall_ts(),
        })
        log.info("Experiment session ended: %s", self._session_id)

    def start_segment(self, label: str, segment_id: int,
                       attack_type: Optional[str] = None,
                       target_link: Optional[str] = None,
                       evasion_strength: Optional[float] = None):
        """
        Ground-truth: only written to gt_log, never to ev_log.
        """
        ts = wall_ts()
        self._current_segment = {
            "segment_id":      segment_id,
            "label":           label,           # "benign" | "conventional_lfa" | "gan_lfa" | "adaptive_lfa"
            "attack_type":     attack_type,
            "target_link":     target_link,
            "evasion_strength": evasion_strength,
            "ts_start":        ts,
        }
        # Ground-truth record — ONLY in gt_log
        self._append_gt({
            "type":            "segment_start",
            "session_id":      self._session_id,
            **self._current_segment,
        })
        # System event (no label leakage — no attack flag passed to Ryu)
        self._append_ev({
            "type":       "segment_start",
            "segment_id": segment_id,
            "ts":         ts,
        })

    def end_segment(self, segment_id: int):
        ts = wall_ts()
        if self._current_segment:
            self._append_gt({
                "type":       "segment_end",
                "session_id": self._session_id,
                "segment_id": segment_id,
                "ts_end":     ts,
            })
        self._append_ev({
            "type": "segment_end", "segment_id": segment_id, "ts": ts
        })
        self._current_segment = None

    # ------------------------------------------------------------------
    # Per-cycle and per-flow events
    # ------------------------------------------------------------------

    def log_bandit_update(self, round_num: int, arm_index: int,
                           evasion_strength: float, reward: float,
                           mean_pred_prob: float, detection_rate: float,
                           ts: float):
        """Agent 1 bandit update — goes to ev_log (no ground-truth label)."""
        self._append_ev({
            "type":             "bandit_update",
            "round":            round_num,
            "arm_index":        arm_index,
            "evasion_strength": evasion_strength,
            "reward":           reward,
            "mean_pred_prob":   mean_pred_prob,
            "detection_rate":   detection_rate,
            "ts":               ts,
        })

    def log_flow_event(self, ts: float, src_ip: str,
                        pred_prob: float, pred_label: int,
                        action: str, congestion: float,
                        det_latency_ms: float, mit_latency_ms: float):
        """Per-flow detection + mitigation event."""
        self._congestion_history.append(congestion)
        self._append_ev({
            "type":             "flow_event",
            "session_id":       self._session_id,
            "ts":               ts,
            "src_ip":           src_ip,
            "pred_prob":        round(float(pred_prob), 6),
            "pred_label":       int(pred_label),
            "action":           action,
            "congestion":       round(float(congestion), 6),
            "det_latency_ms":   round(float(det_latency_ms), 4),
            "mit_latency_ms":   round(float(mit_latency_ms), 4),
        })

    def log_latency_cycle(self, ts_summary: dict):
        """Derived latency metrics for one stats cycle."""
        self._append_ts({
            "session_id": self._session_id,
            "ts":         wall_ts(),
            **{k: round(float(v), 4) if v is not None else None
               for k, v in ts_summary.items()},
        })

    def log_port_utilization(self, util: dict, ts: float):
        rec = {"type": "port_util", "ts": ts, "util": {str(k): round(float(v), 4) for k, v in util.items()}}
        self._port_util_history.append(rec)
        self._append_ev(rec)

    def log_metric(self, record: dict):
        """Append an evaluation metric record."""
        self._append_met({"session_id": self._session_id, "ts": wall_ts(), **record})

    def log_recovery(self, recovery_time_s: float, segment_id: int):
        self._append_gt({
            "type":             "recovery",
            "session_id":       self._session_id,
            "segment_id":       segment_id,
            "recovery_time_s":  round(float(recovery_time_s), 4),
            "ts":               wall_ts(),
        })
        log.info("Recovery: segment %d recovered in %.2fs", segment_id, recovery_time_s)

    # ------------------------------------------------------------------
    # Accessors for evaluation
    # ------------------------------------------------------------------

    def congestion_history(self) -> List[float]:
        return list(self._congestion_history)

    def load_ground_truth(self) -> List[dict]:
        records = []
        if self.gt_log.is_file():
            with open(self.gt_log) as fh:
                for line in fh:
                    line = line.strip()
                    if line:
                        records.append(json.loads(line))
        return records

    def load_flow_events(self) -> List[dict]:
        records = []
        if self.ev_log.is_file():
            with open(self.ev_log) as fh:
                for line in fh:
                    line = line.strip()
                    if line:
                        rec = json.loads(line)
                        if rec.get("type") == "flow_event":
                            records.append(rec)
        return records

    def load_latency_cycles(self) -> List[dict]:
        records = []
        if self.ts_log.is_file():
            with open(self.ts_log) as fh:
                for line in fh:
                    line = line.strip()
                    if line:
                        records.append(json.loads(line))
        return records

    # ------------------------------------------------------------------
    # Private
    # ------------------------------------------------------------------

    def _append_gt(self, rec: dict):
        with _lock:
            append_jsonl(self.gt_log, rec)

    def _append_ev(self, rec: dict):
        with _lock:
            append_jsonl(self.ev_log, rec)

    def _append_ts(self, rec: dict):
        with _lock:
            append_jsonl(self.ts_log, rec)

    def _append_met(self, rec: dict):
        with _lock:
            append_jsonl(self.met_log, rec)
