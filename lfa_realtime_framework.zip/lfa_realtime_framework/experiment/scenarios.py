"""
Scenario definitions.

Each scenario is a sequence of (segment_label, duration_seconds, attack_kwargs) tuples.
The scenario runner iterates through the list, calling ExperimentManager.start_segment /
end_segment around each segment and launching/stopping traffic accordingly.
"""

from config.settings import (
    SCENARIO_DURATION_SEC, ALTERNATING_EXPERIMENT, TOPO_N_HOSTS,
)

# ---------------------------------------------------------------------------
# Single-scenario definitions
# ---------------------------------------------------------------------------

BENIGN_ONLY = [
    ("benign", SCENARIO_DURATION_SEC["benign_only"], {}),
]

CONVENTIONAL_LFA = [
    ("benign",          20, {}),
    ("conventional_lfa", SCENARIO_DURATION_SEC["conventional_lfa"],
     {"attack_type": "conventional_lfa", "target_link": "s1-s2",
      "n_flows_per_host": 10, "interval_us": 100}),
    ("benign",          20, {}),
]

GAN_LFA = [
    ("benign",  20, {}),
    ("gan_lfa", SCENARIO_DURATION_SEC["gan_lfa"],
     {"attack_type": "gan_lfa", "target_link": "s1-s2", "evasion_strength": 0.5}),
    ("benign",  20, {}),
]

ADAPTIVE_LFA = [
    ("benign",       20, {}),
    ("adaptive_lfa", SCENARIO_DURATION_SEC["adaptive_lfa"],
     {"attack_type": "adaptive_lfa", "target_link": "s1-s2",
      "evasion_strength": None}),   # None → bandit-controlled
    ("benign",       20, {}),
]

UNSEEN_TOPOLOGY = [
    ("benign",       30, {"topology": "linear"}),
    ("adaptive_lfa", SCENARIO_DURATION_SEC["unseen_topology"],
     {"topology": "linear", "attack_type": "adaptive_lfa",
      "target_link": "s2-s3", "evasion_strength": None}),
    ("benign",       30, {"topology": "linear"}),
]

# ---------------------------------------------------------------------------
# Alternating experiment (live transitions)
# ---------------------------------------------------------------------------

ALTERNATING = [
    (label, duration_s, {} if label == "benign"
     else {"attack_type": label, "target_link": "s1-s2", "evasion_strength": None})
    for label, duration_s in ALTERNATING_EXPERIMENT
]

# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

SCENARIOS = {
    "benign_only":      BENIGN_ONLY,
    "conventional_lfa": CONVENTIONAL_LFA,
    "gan_lfa":          GAN_LFA,
    "adaptive_lfa":     ADAPTIVE_LFA,
    "unseen_topology":  UNSEEN_TOPOLOGY,
    "alternating":      ALTERNATING,
}
