"""
High-resolution timestamp tracker.

Records named events within a single stats cycle and computes derived latencies:
  - generation_latency
  - observation_latency    (stats_request → stats_arrived)
  - feature_extraction_latency
  - model_inference_latency
  - end_to_end_detection_latency   (stats_arrived → inference_end)
  - mitigation_decision_latency
  - rule_installation_latency
  - total_response_latency         (stats_arrived → rule_installed)

Also tracks network recovery time: congestion_fell_below_threshold − attack_started.
"""

import time
from collections import defaultdict
from typing import Dict, List, Optional

from utils.common import wall_ts


# Canonical event names (used as keys)
E_GEN_DECISION        = "generator_decision"
E_TRAFFIC_START       = "traffic_start"
E_STATS_REQUEST       = "stats_request_sent"
E_STATS_ARRIVED       = "stats_arrived"
E_FEAT_START          = "feature_extraction_start"
E_FEAT_END            = "feature_extraction_end"
E_INF_START           = "inference_start"
E_INF_END             = "inference_end"
E_DET_DECISION        = "detection_decision"
E_MIT_START           = "mitigation_decision_start"
E_MIT_END             = "mitigation_decision_end"
E_RULE_INSTALLED      = "rule_installed"
E_RECOVERY            = "network_recovery"


class TimestampTracker:
    """
    Stores events for the current stats cycle and computes latency summaries.
    """

    def __init__(self):
        self._events: Dict[str, List[dict]] = defaultdict(list)

    def record(self, event: str, extra: Optional[dict] = None):
        entry = {"ts": wall_ts()}
        if extra:
            entry.update(extra)
        self._events[event].append(entry)

    def latest(self, event: str) -> Optional[float]:
        entries = self._events.get(event)
        return entries[-1]["ts"] if entries else None

    def earliest(self, event: str) -> Optional[float]:
        entries = self._events.get(event)
        return entries[0]["ts"] if entries else None

    def _diff(self, start_event: str, end_event: str) -> Optional[float]:
        t0 = self.earliest(start_event)
        t1 = self.latest(end_event)
        if t0 is not None and t1 is not None and t1 >= t0:
            return (t1 - t0) * 1000.0   # ms
        return None

    def summarize_cycle(self) -> dict:
        return {
            "observation_latency_ms":           self._diff(E_STATS_REQUEST, E_STATS_ARRIVED),
            "feature_extraction_latency_ms":    self._diff(E_FEAT_START, E_FEAT_END),
            "model_inference_latency_ms":       self._diff(E_INF_START, E_INF_END),
            "end_to_end_detection_latency_ms":  self._diff(E_STATS_ARRIVED, E_INF_END),
            "mitigation_decision_latency_ms":   self._diff(E_MIT_START, E_MIT_END),
            "rule_installation_latency_ms":     self._diff(E_MIT_END, E_RULE_INSTALLED),
            "total_response_latency_ms":        self._diff(E_STATS_ARRIVED, E_RULE_INSTALLED),
            "ts_cycle_start":                   self.earliest(E_STATS_ARRIVED),
        }

    def reset_cycle(self):
        self._events.clear()


class RecoveryTimer:
    """
    Measures network recovery time:
    from attack_started to congestion falling below threshold.
    """

    def __init__(self, threshold: float = 0.2):
        self.threshold  = threshold
        self._started   = None
        self._recovered = None

    def attack_started(self):
        self._started   = wall_ts()
        self._recovered = None

    def check_recovery(self, congestion: float) -> Optional[float]:
        """
        Call after each stats cycle.
        Returns recovery_time_s once congestion drops below threshold, else None.
        """
        if self._started is None or congestion >= self.threshold:
            return None
        if self._recovered is None:
            self._recovered = wall_ts()
            return self._recovered - self._started
        return None
