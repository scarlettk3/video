"""
Synchronized multi-panel plots for the LFA experiment.

Figures produced:
  Fig 1  — Alternating experiment overview (ground-truth / congestion /
            detector confidence / pred class / evasion mode / actions)
  Fig 2  — ROC curve (offline evaluation vs. live)
  Fig 3  — Bandit arm values over rounds
  Fig 4  — Latency breakdown (bar chart, per-component)
  Fig 5  — Congestion trajectory: DQN vs. static baseline
  Fig 6  — Detection metrics table (heatmap)
  Fig 7  — Link utilization before / after mitigation
"""

import json
from pathlib import Path
from typing import List, Optional

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns

from config.settings import PLOTS_DIR
from utils.common import get_logger

log = get_logger(__name__)

sns.set_theme(style="whitegrid")
plt.rcParams.update({
    "font.size": 10, "axes.titlesize": 12,
    "axes.labelsize": 10, "legend.fontsize": 9,
})

SAVE_DPI = 150


def _savefig(fig, filename: str, out_dir: Path = PLOTS_DIR):
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / filename
    fig.savefig(path, dpi=SAVE_DPI, bbox_inches="tight")
    plt.close(fig)
    log.info("Saved → %s", path)
    return path


# ---------------------------------------------------------------------------
# Fig 1 — Alternating experiment synchronized view
# ---------------------------------------------------------------------------

def plot_alternating_experiment(
    timestamps: List[float],
    congestion: List[float],
    pred_probs: List[float],
    pred_labels: List[int],
    actions: List[str],
    bandit_rounds: List[dict],
    gt_segments: List[dict],
    out_dir: Path = PLOTS_DIR,
) -> Path:
    """
    Six-row synchronized plot:
      Row 1: ground-truth attack/benign shading
      Row 2: link congestion signal
      Row 3: detector confidence
      Row 4: predicted class (0/1)
      Row 5: evasion mode (bandit arm selection over time)
      Row 6: mitigation actions
    """
    n = min(len(timestamps), len(congestion), len(pred_probs), len(pred_labels))
    if n == 0:
        log.warning("No data for alternating experiment plot.")
        return None

    t  = np.asarray(timestamps[:n]) - timestamps[0]   # relative seconds
    cg = np.asarray(congestion[:n])
    pp = np.asarray(pred_probs[:n])
    pl = np.asarray(pred_labels[:n])

    from config.settings import ACTION_NAMES
    action_idx = [ACTION_NAMES.index(a) if a in ACTION_NAMES else 0 for a in actions[:n]]
    action_arr = np.asarray(action_idx)

    fig, axes = plt.subplots(6, 1, figsize=(12, 14), sharex=True)
    fig.suptitle("Alternating LFA Experiment — Synchronized View",
                 fontsize=13, fontweight="bold")

    # Row 1: ground-truth shading
    ax = axes[0]
    ax.set_ylabel("Ground\nTruth", fontsize=9)
    ax.set_yticks([])
    colors = {"benign": "#55A868", "conventional_lfa": "#C44E52",
              "gan_lfa": "#4C72B0", "adaptive_lfa": "#8172B2"}
    for seg in gt_segments:
        ts0 = seg.get("ts_start", 0) - (timestamps[0] if timestamps else 0)
        ts1 = seg.get("ts_end",   ts0 + 1) - (timestamps[0] if timestamps else 0)
        label = seg.get("label", "benign")
        ax.axvspan(ts0, ts1, alpha=0.4, color=colors.get(label, "gray"),
                   label=label if ts0 == 0 else "_nolegend_")
    handles = [mpatches.Patch(color=c, alpha=0.5, label=l)
               for l, c in colors.items()]
    ax.legend(handles=handles, ncol=4, fontsize=8, loc="upper right")

    # Row 2: congestion
    axes[1].plot(t, cg, color="#C44E52", linewidth=1.4)
    axes[1].set_ylabel("Link\nCongestion", fontsize=9)
    axes[1].set_ylim(-0.05, 1.05)
    axes[1].axhline(0.2, linestyle="--", color="gray", linewidth=0.8, label="recovery threshold")
    axes[1].legend(fontsize=8)

    # Row 3: detector confidence
    axes[2].plot(t, pp, color="#4C72B0", linewidth=1.0, alpha=0.8)
    axes[2].axhline(0.5, linestyle="--", color="gray", linewidth=0.8)
    axes[2].set_ylabel("Detector\nConfidence", fontsize=9)
    axes[2].set_ylim(-0.05, 1.05)

    # Row 4: predicted class
    axes[3].step(t, pl, color="#937860", linewidth=1.2)
    axes[3].set_ylabel("Predicted\nClass", fontsize=9)
    axes[3].set_yticks([0, 1])
    axes[3].set_yticklabels(["NORMAL", "ATTACK"], fontsize=8)

    # Row 5: evasion mode (bandit arm over rounds)
    if bandit_rounds:
        br_ts  = [r["ts"] - (timestamps[0] if timestamps else 0) for r in bandit_rounds]
        br_arm = [r["evasion_strength"] for r in bandit_rounds]
        axes[4].step(br_ts, br_arm, color="#8172B2", linewidth=1.5)
    axes[4].set_ylabel("Evasion\nStrength", fontsize=9)
    axes[4].set_ylim(-0.1, 1.1)

    # Row 6: mitigation actions (scatter)
    cmap_actions = plt.cm.get_cmap("tab10", 5)
    for ai in range(5):
        mask = action_arr == ai
        if mask.any():
            axes[5].scatter(t[mask], np.full(mask.sum(), ai),
                            s=6, color=cmap_actions(ai),
                            label=ACTION_NAMES[ai] if ai < len(ACTION_NAMES) else str(ai))
    axes[5].set_ylabel("Mitigation\nAction", fontsize=9)
    axes[5].set_yticks(range(5))
    axes[5].set_yticklabels(ACTION_NAMES, fontsize=8)
    axes[5].legend(fontsize=7, ncol=5, loc="upper right")

    axes[5].set_xlabel("Experiment time (s)")
    plt.tight_layout()
    return _savefig(fig, "fig1_alternating_experiment.png", out_dir)


# ---------------------------------------------------------------------------
# Fig 3 — Bandit arm values over rounds
# ---------------------------------------------------------------------------

def plot_bandit_convergence(bandit_history: List[dict],
                             out_dir: Path = PLOTS_DIR) -> Optional[Path]:
    if not bandit_history:
        return None
    from config.settings import EVASION_STRENGTHS
    rounds = [r["round"] for r in bandit_history]
    arm_vals = {str(a): [r["arm_values"].get(str(a), 0.0) for r in bandit_history]
                for a in EVASION_STRENGTHS}

    fig, ax = plt.subplots(figsize=(8, 4))
    for arm_key, vals in arm_vals.items():
        ax.plot(rounds, vals, linewidth=1.8, label=f"e={arm_key}")
    ax.set_xlabel("Bandit round")
    ax.set_ylabel("Arm value  (1 − detector confidence)")
    ax.set_title("Evasion Bandit — Per-Arm Value Estimates", fontweight="bold")
    ax.legend(title="evasion_strength")
    ax.grid(alpha=0.3)
    plt.tight_layout()
    return _savefig(fig, "fig3_bandit_convergence.png", out_dir)


# ---------------------------------------------------------------------------
# Fig 4 — Latency breakdown
# ---------------------------------------------------------------------------

def plot_latency_breakdown(latency_summary: dict,
                            out_dir: Path = PLOTS_DIR) -> Optional[Path]:
    if not latency_summary:
        return None
    labels, means, p95s = [], [], []
    short_names = {
        "observation_latency_ms":           "Observation",
        "feature_extraction_latency_ms":    "Feat. Extract.",
        "model_inference_latency_ms":       "Inference",
        "mitigation_decision_latency_ms":   "Mit. Decision",
        "rule_installation_latency_ms":     "Rule Install",
        "end_to_end_detection_latency_ms":  "E2E Detection",
        "total_response_latency_ms":        "Total Response",
    }
    for k, short in short_names.items():
        if k in latency_summary:
            labels.append(short)
            means.append(latency_summary[k]["mean"])
            p95s.append(latency_summary[k]["p95"])

    x = np.arange(len(labels))
    fig, ax = plt.subplots(figsize=(9, 4.5))
    width = 0.35
    ax.bar(x - width / 2, means, width, label="Mean", color="#4C72B0")
    ax.bar(x + width / 2, p95s,  width, label="P95",  color="#C44E52", alpha=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=20, ha="right")
    ax.set_ylabel("Latency (ms)")
    ax.set_title("Per-Component Latency Breakdown", fontweight="bold")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    return _savefig(fig, "fig4_latency_breakdown.png", out_dir)


# ---------------------------------------------------------------------------
# Fig 5 — Congestion trajectory comparison
# ---------------------------------------------------------------------------

def plot_congestion_comparison(dqn_traj: List[float],
                                static_traj: List[float],
                                out_dir: Path = PLOTS_DIR) -> Optional[Path]:
    if not dqn_traj and not static_traj:
        return None
    fig, ax = plt.subplots(figsize=(9, 4))
    if static_traj:
        ax.plot(static_traj, color="#937860", linewidth=1.4, alpha=0.9, label="Static threshold")
    if dqn_traj:
        ax.plot(dqn_traj, color="#C44E52", linewidth=1.4, alpha=0.9, label="DQN Mitigation")
    ax.axhline(0.2, linestyle="--", color="gray", linewidth=0.8, label="recovery threshold=0.2")
    ax.set_xlabel("Flow step")
    ax.set_ylabel("Link congestion signal")
    ax.set_title("Congestion Trajectory — DQN vs. Static Baseline", fontweight="bold")
    ax.legend()
    ax.grid(alpha=0.3)
    plt.tight_layout()
    return _savefig(fig, "fig5_congestion_comparison.png", out_dir)


# ---------------------------------------------------------------------------
# Fig 6 — Detection metrics heat-map table
# ---------------------------------------------------------------------------

def plot_detection_metrics_table(metrics_by_scenario: dict,
                                  out_dir: Path = PLOTS_DIR) -> Optional[Path]:
    if not metrics_by_scenario:
        return None
    cols = ["accuracy", "precision", "recall", "f1_score", "roc_auc",
            "false_positive_rate", "false_negative_rate"]
    rows = list(metrics_by_scenario.keys())
    data = np.array([[metrics_by_scenario[r].get(c, float("nan")) for c in cols]
                     for r in rows])

    fig, ax = plt.subplots(figsize=(max(10, len(cols) * 1.5), max(4, len(rows) * 0.8)))
    im = ax.imshow(data, aspect="auto", cmap="RdYlGn", vmin=0, vmax=1)
    ax.set_xticks(range(len(cols)))
    ax.set_xticklabels([c.replace("_", "\n") for c in cols], fontsize=8)
    ax.set_yticks(range(len(rows)))
    ax.set_yticklabels(rows, fontsize=9)
    for i in range(len(rows)):
        for j in range(len(cols)):
            v = data[i, j]
            txt = f"{v:.3f}" if np.isfinite(v) else "—"
            ax.text(j, i, txt, ha="center", va="center", fontsize=8,
                    color="black" if 0.3 < v < 0.8 else "white")
    plt.colorbar(im, ax=ax, fraction=0.02, pad=0.04)
    ax.set_title("Detection Agent Metrics by Scenario", fontweight="bold")
    plt.tight_layout()
    return _savefig(fig, "fig6_detection_metrics_table.png", out_dir)


# ---------------------------------------------------------------------------
# Fig 7 — Link utilization
# ---------------------------------------------------------------------------

def plot_link_utilization(util_history: List[dict],
                           gt_segments: List[dict],
                           out_dir: Path = PLOTS_DIR) -> Optional[Path]:
    if not util_history:
        return None
    all_ports = sorted({str(p) for rec in util_history for p in rec.get("util", {})})
    timestamps = [rec["ts"] for rec in util_history]
    t0 = min(timestamps)
    t  = [ts - t0 for ts in timestamps]

    fig, ax = plt.subplots(figsize=(10, 4))
    colors = plt.cm.tab10(np.linspace(0, 1, len(all_ports)))
    for port, color in zip(all_ports, colors):
        vals = [rec["util"].get(port, 0.0) for rec in util_history]
        ax.plot(t, vals, linewidth=1.5, label=f"port {port}", color=color)

    # Attack shading
    seg_colors = {"conventional_lfa": "#C44E52", "gan_lfa": "#4C72B0",
                  "adaptive_lfa": "#8172B2"}
    for seg in gt_segments:
        label = seg.get("label", "benign")
        if label != "benign":
            ts0 = seg.get("ts_start", 0) - t0
            ts1 = seg.get("ts_end",   ts0 + 1) - t0
            ax.axvspan(ts0, ts1, alpha=0.15,
                       color=seg_colors.get(label, "gray"))

    ax.set_xlabel("Experiment time (s)")
    ax.set_ylabel("Link utilization")
    ax.set_ylim(0, 1.1)
    ax.set_title("Link Utilization During Experiment", fontweight="bold")
    ax.legend(fontsize=8, ncol=4)
    ax.grid(alpha=0.3)
    plt.tight_layout()
    return _savefig(fig, "fig7_link_utilization.png", out_dir)
