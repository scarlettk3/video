"""
Evaluation metrics for all three agents.

Detection Agent  : accuracy, precision, recall, F1, ROC-AUC, FPR, FNR, latency.
LFA Agent        : attack effectiveness, link congestion, evasion rate,
                   detector confidence over time, mode selection.
Mitigation Agent : congestion reduction, recovery time, throughput retained,
                   packet loss, FCT, link utilisation, unnecessary-mitigation rate.
"""

from typing import Dict, List, Optional

import numpy as np
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix,
)

from utils.common import get_logger

log = get_logger(__name__)


# ---------------------------------------------------------------------------
# Detection Agent metrics
# ---------------------------------------------------------------------------

def detection_metrics(y_true: np.ndarray, y_pred: np.ndarray,
                       y_prob: Optional[np.ndarray] = None,
                       latencies_ms: Optional[np.ndarray] = None) -> dict:
    """
    Compute the full detection metric suite.
    y_true/y_pred: binary int arrays (0=NORMAL, 1=ATTACK).
    """
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)

    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    fnr = fn / (fn + tp) if (fn + tp) > 0 else 0.0

    roc_auc = float("nan")
    if y_prob is not None:
        try:
            roc_auc = float(roc_auc_score(y_true, np.asarray(y_prob)))
        except ValueError:
            pass

    result = {
        "accuracy":            float(accuracy_score(y_true, y_pred)),
        "precision":           float(precision_score(y_true, y_pred, zero_division=0)),
        "recall":              float(recall_score(y_true, y_pred, zero_division=0)),
        "f1_score":            float(f1_score(y_true, y_pred, zero_division=0)),
        "roc_auc":             roc_auc,
        "false_positive_rate": float(fpr),
        "false_negative_rate": float(fnr),
        "confusion_matrix":    cm.tolist(),
        "TP": int(tp), "TN": int(tn), "FP": int(fp), "FN": int(fn),
    }

    if latencies_ms is not None:
        lat = np.asarray(latencies_ms, dtype=float)
        result["latency_mean_ms"]   = float(lat.mean())
        result["latency_median_ms"] = float(np.median(lat))
        result["latency_p95_ms"]    = float(np.percentile(lat, 95))
        result["latency_p99_ms"]    = float(np.percentile(lat, 99))

    return result


# ---------------------------------------------------------------------------
# LFA / Generation Agent metrics
# ---------------------------------------------------------------------------

def lfa_generation_metrics(bandit_history: List[dict],
                             pred_probs_per_round: List[float],
                             congestion_trajectory: List[float]) -> dict:
    """
    Compute LFA agent metrics from bandit history and congestion trajectory.
    """
    if not bandit_history:
        return {}

    rounds          = [r["round"] for r in bandit_history]
    evasion_strs    = [r["evasion_strength"] for r in bandit_history]
    det_rates       = [r["detection_rate"] for r in bandit_history]
    mean_probs      = [r["mean_pred_prob"] for r in bandit_history]
    rewards         = [r["reward"] for r in bandit_history]

    evasion_success_rate = 1.0 - float(np.mean(det_rates)) if det_rates else 0.0
    max_congestion       = float(max(congestion_trajectory)) if congestion_trajectory else 0.0
    mean_congestion      = float(np.mean(congestion_trajectory)) if congestion_trajectory else 0.0

    # Final converged arm
    arm_values = bandit_history[-1].get("arm_values", {}) if bandit_history else {}
    converged_arm = max(arm_values, key=lambda k: arm_values[k], default=None)

    return {
        "n_rounds":                     len(rounds),
        "mean_detector_confidence":     float(np.mean(mean_probs)),
        "final_detector_confidence":    float(mean_probs[-1]) if mean_probs else None,
        "evasion_success_rate":         evasion_success_rate,
        "max_link_congestion":          max_congestion,
        "mean_link_congestion":         mean_congestion,
        "mean_reward":                  float(np.mean(rewards)),
        "converged_evasion_strength":   converged_arm,
        "arm_values_final":             arm_values,
        "mode_distribution":            _arm_distribution(evasion_strs),
    }


def _arm_distribution(evasion_strs: List[float]) -> dict:
    from collections import Counter
    counts = Counter(evasion_strs)
    total  = sum(counts.values())
    return {str(k): round(v / total, 4) for k, v in counts.items()}


# ---------------------------------------------------------------------------
# Mitigation Agent metrics
# ---------------------------------------------------------------------------

def mitigation_metrics(
    congestion_before: List[float],
    congestion_after:  List[float],
    recovery_times_s:  List[float],
    action_log:        List[dict],   # list of flow_event records
    port_util_before:  Optional[Dict[str, float]] = None,
    port_util_after:   Optional[Dict[str, float]] = None,
) -> dict:
    """
    Compute mitigation evaluation metrics.

    Parameters
    ----------
    congestion_before : congestion trajectory during attack (pre-mitigation phase).
    congestion_after  : congestion trajectory after mitigation rules applied.
    recovery_times_s  : list of measured recovery times (one per attack segment).
    action_log        : list of flow_event dicts from ExperimentManager.
    """
    cong_red = 0.0
    if congestion_before and congestion_after:
        cong_red = max(0.0, float(np.mean(congestion_before)) -
                            float(np.mean(congestion_after)))

    mean_recovery = float(np.mean(recovery_times_s)) if recovery_times_s else float("nan")

    # Unnecessary mitigation = NORMAL flow that received a mitigation action
    from config.settings import ACTION_NAMES, MITIGATION_ACTIONS
    n_normal_mit = sum(
        1 for ev in action_log
        if ev.get("pred_label", 0) == 0 and
           ACTION_NAMES.index(ev.get("action", "allow")) in MITIGATION_ACTIONS
    )
    n_normal_total = sum(1 for ev in action_log if ev.get("pred_label", 0) == 0)
    unnecessary_rate = n_normal_mit / max(1, n_normal_total)

    # Action distribution
    from collections import Counter
    act_counts = Counter(ev.get("action", "allow") for ev in action_log)
    total_acts = sum(act_counts.values())
    act_dist   = {k: round(v / max(1, total_acts), 4) for k, v in act_counts.items()}

    result = {
        "congestion_reduction":       round(cong_red, 4),
        "mean_recovery_time_s":       round(mean_recovery, 4) if not np.isnan(mean_recovery) else None,
        "unnecessary_mitigation_rate": round(unnecessary_rate, 4),
        "action_distribution":        act_dist,
        "n_flows_evaluated":          len(action_log),
    }

    if port_util_before and port_util_after:
        result["link_util_before"] = {k: round(float(v), 4) for k, v in port_util_before.items()}
        result["link_util_after"]  = {k: round(float(v), 4) for k, v in port_util_after.items()}

    return result


# ---------------------------------------------------------------------------
# Latency metrics (from ExperimentManager.load_latency_cycles())
# ---------------------------------------------------------------------------

def latency_metrics(latency_cycles: List[dict]) -> dict:
    """Aggregate cycle-level latency measurements into mean/p95/p99 summary."""
    if not latency_cycles:
        return {}

    keys = [
        "observation_latency_ms",
        "feature_extraction_latency_ms",
        "model_inference_latency_ms",
        "end_to_end_detection_latency_ms",
        "mitigation_decision_latency_ms",
        "rule_installation_latency_ms",
        "total_response_latency_ms",
    ]

    result = {}
    for k in keys:
        vals = [c[k] for c in latency_cycles if c.get(k) is not None]
        if not vals:
            continue
        arr = np.asarray(vals, dtype=float)
        result[k] = {
            "mean":   round(float(arr.mean()), 4),
            "median": round(float(np.median(arr)), 4),
            "p95":    round(float(np.percentile(arr, 95)), 4),
            "p99":    round(float(np.percentile(arr, 99)), 4),
            "n":      len(arr),
        }
    return result
