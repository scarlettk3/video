"""
model_builder.py
----------------
Rebuilds a generator or discriminator from an ENAS-found architecture
(best_arch.json) so the SAME structure can be used for offline training and
online inference. Keep the op set small and fixed.

Architecture JSON shape (produced by enas_search.py):
{
  "generator":     {"input_dim": 32, "cond_dim": 2, "cells": ["gru_128", "fc_relu", ...], "out_dim": 7},
  "discriminator": {"input_dim": 7,  "cond_dim": 2, "cells": ["conv1d_k3", "fc_leakyrelu", ...]}
}
"""
from __future__ import annotations

import torch
import torch.nn as nn

OPERATIONS = [
    "gru_64", "gru_128", "conv1d_k3", "conv1d_k5",
    "fc_relu", "fc_leakyrelu", "identity",
]


def _make_op(name: str, in_dim: int) -> tuple[nn.Module, int]:
    """Return (module, out_dim) for a single op. 1-D feature vectors are treated
    as length-1 sequences for the recurrent/conv ops."""
    if name == "gru_64":
        return _GRUOp(in_dim, 64), 64
    if name == "gru_128":
        return _GRUOp(in_dim, 128), 128
    if name == "conv1d_k3":
        return _Conv1dOp(in_dim, 64, k=3), 64
    if name == "conv1d_k5":
        return _Conv1dOp(in_dim, 64, k=5), 64
    if name == "fc_relu":
        return nn.Sequential(nn.Linear(in_dim, 64), nn.ReLU()), 64
    if name == "fc_leakyrelu":
        return nn.Sequential(nn.Linear(in_dim, 64), nn.LeakyReLU(0.2)), 64
    if name == "identity":
        return nn.Identity(), in_dim
    raise ValueError(f"Unknown op: {name!r} (expected one of {OPERATIONS})")


class _GRUOp(nn.Module):
    def __init__(self, in_dim: int, hidden: int):
        super().__init__()
        self.gru = nn.GRU(in_dim, hidden, batch_first=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # x: (B, in_dim)
        out, _ = self.gru(x.unsqueeze(1))                # (B, 1, hidden)
        return out.squeeze(1)


class _Conv1dOp(nn.Module):
    def __init__(self, in_dim: int, ch: int, k: int):
        super().__init__()
        self.conv = nn.Conv1d(1, ch, kernel_size=k, padding=k // 2)
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.act = nn.ReLU()
        self.in_dim = in_dim

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # x: (B, in_dim)
        z = self.conv(x.unsqueeze(1))                    # (B, ch, in_dim)
        z = self.pool(self.act(z)).squeeze(-1)           # (B, ch)
        return z


class _CellStack(nn.Module):
    """Sequentially applies the ENAS-chosen ops, optionally conditioned on a
    label embedding concatenated to the input."""

    def __init__(self, input_dim: int, cells: list[str], cond_dim: int = 0):
        super().__init__()
        self.cond_dim = cond_dim
        dim = input_dim + cond_dim
        mods: list[nn.Module] = []
        for name in cells:
            op, dim = _make_op(name, dim)
            mods.append(op)
        self.ops = nn.ModuleList(mods)
        self.out_dim = dim

    def forward(self, x: torch.Tensor, cond: torch.Tensor | None = None) -> torch.Tensor:
        if self.cond_dim and cond is not None:
            x = torch.cat([x, cond], dim=-1)
        for op in self.ops:
            x = op(x)
        return x


class Generator(nn.Module):
    def __init__(self, arch: dict):
        super().__init__()
        self.body = _CellStack(arch["input_dim"], arch["cells"], arch.get("cond_dim", 0))
        self.head = nn.Linear(self.body.out_dim, arch["out_dim"])

    def forward(self, z: torch.Tensor, cond: torch.Tensor | None = None) -> torch.Tensor:
        return self.head(self.body(z, cond))


class Discriminator(nn.Module):
    def __init__(self, arch: dict):
        super().__init__()
        self.body = _CellStack(arch["input_dim"], arch["cells"], arch.get("cond_dim", 0))
        self.head = nn.Sequential(nn.Linear(self.body.out_dim, 1), nn.Sigmoid())

    def forward(self, x: torch.Tensor, cond: torch.Tensor | None = None) -> torch.Tensor:
        return self.head(self.body(x, cond)).squeeze(-1)


def build_model_from_arch(arch: dict, kind: str) -> nn.Module:
    """kind in {'generator', 'discriminator'}."""
    if kind == "generator":
        return Generator(arch)
    if kind == "discriminator":
        return Discriminator(arch)
    raise ValueError("kind must be 'generator' or 'discriminator'")
