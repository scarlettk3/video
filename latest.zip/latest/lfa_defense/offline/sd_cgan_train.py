"""
sd_cgan_train.py
----------------
Trains the SD-CGAN (Sinkhorn Conditional GAN) using the ENAS-found architecture
in best_arch.json, then exports everything the Ryu controller needs:

    discriminator.pt   - trained discriminator weights (torch.save)
    scaler.pkl         - fitted sklearn StandardScaler
    threshold.pkl      - decision threshold (float)
    best_arch.json     - (already produced by enas_search.py; copied/kept alongside)

Runnable SKELETON: wire load_dataset() to your monitor CSV and (optionally)
swap the placeholder generator loss for a real geomloss Sinkhorn divergence.
"""
from __future__ import annotations

import argparse
import json
import pickle

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from model_builder import build_model_from_arch

try:
    from geomloss import SamplesLoss
    _SINKHORN = SamplesLoss("sinkhorn", p=2, blur=0.05)
except Exception:  # geomloss optional at skeleton stage
    _SINKHORN = None

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def load_dataset(csv_path: str):
    """Return (X, y). Replace with your real monitor-log loader.

    Expected columns: 7 feature columns + a 'label' column (0=normal, 1=LFA).
    """
    import pandas as pd
    df = pd.read_csv(csv_path)
    y = df["label"].to_numpy().astype(np.int64)
    X = df.drop(columns=["label"]).to_numpy().astype(np.float32)
    return X, y


def one_hot(y: np.ndarray, n: int) -> torch.Tensor:
    t = torch.zeros(len(y), n, dtype=torch.float32)
    t[torch.arange(len(y)), torch.as_tensor(y)] = 1.0
    return t


def generator_loss(real: torch.Tensor, fake: torch.Tensor) -> torch.Tensor:
    """Sinkhorn divergence between real and generated feature batches."""
    if _SINKHORN is not None:
        return _SINKHORN(fake, real)
    # Fallback so the skeleton runs without geomloss installed:
    return ((fake.mean(0) - real.mean(0)) ** 2).mean()


def tune_threshold(disc: nn.Module, Xv: torch.Tensor, yv: np.ndarray,
                   condv: torch.Tensor) -> float:
    disc.eval()
    with torch.no_grad():
        scores = disc(Xv, condv).cpu().numpy()
    best_t, best_f1 = 0.5, -1.0
    for t in np.linspace(0.05, 0.95, 19):
        f1 = f1_score(yv, (scores > t).astype(int), zero_division=0)
        if f1 > best_f1:
            best_f1, best_t = f1, float(t)
    print(f"[threshold] best F1={best_f1:.4f} at t={best_t:.2f}")
    return best_t


def train_sd_cgan(gen, disc, X, y, n_labels, epochs=400, noise_dim=32, batch=128):
    gen, disc = gen.to(DEVICE), disc.to(DEVICE)
    opt_g = torch.optim.Adam(gen.parameters(), lr=2e-4, betas=(0.5, 0.999))
    opt_d = torch.optim.Adam(disc.parameters(), lr=2e-4, betas=(0.5, 0.999))
    bce = nn.BCELoss()

    Xt = torch.as_tensor(X, device=DEVICE)
    cond = one_hot(y, n_labels).to(DEVICE)
    n = len(Xt)

    for ep in range(epochs):
        idx = torch.randperm(n, device=DEVICE)[:batch]
        xb, cb = Xt[idx], cond[idx]

        # --- Discriminator: real=1, fake=0 ---
        z = torch.randn(len(xb), noise_dim, device=DEVICE)
        fake = gen(z, cb).detach()
        opt_d.zero_grad()
        d_real = disc(xb, cb)
        d_fake = disc(fake, cb)
        loss_d = bce(d_real, torch.ones_like(d_real)) + bce(d_fake, torch.zeros_like(d_fake))
        loss_d.backward()
        opt_d.step()

        # --- Generator: Sinkhorn(real, fake) ---
        z = torch.randn(len(xb), noise_dim, device=DEVICE)
        opt_g.zero_grad()
        gen_samples = gen(z, cb)
        loss_g = generator_loss(xb, gen_samples)
        loss_g.backward()
        opt_g.step()

        if (ep + 1) % 50 == 0:
            print(f"[epoch {ep + 1}/{epochs}] D={loss_d.item():.4f} G={loss_g.item():.4f}")
    return gen, disc


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="../mininet/traffic_log.csv")
    ap.add_argument("--arch", default="best_arch.json")
    ap.add_argument("--epochs", type=int, default=400)
    ap.add_argument("--noise-dim", type=int, default=32)
    ap.add_argument("--labels", type=int, default=2)
    args = ap.parse_args()

    X, y = load_dataset(args.data)
    scaler = StandardScaler().fit(X)
    Xs = scaler.transform(X).astype(np.float32)
    Xtr, Xval, ytr, yval = train_test_split(Xs, y, test_size=0.25, stratify=y, random_state=42)

    arch = json.load(open(args.arch))
    gen = build_model_from_arch(arch["generator"], "generator")
    disc = build_model_from_arch(arch["discriminator"], "discriminator")

    gen, disc = train_sd_cgan(gen, disc, Xtr, ytr, args.labels,
                              epochs=args.epochs, noise_dim=args.noise_dim)

    Xval_t = torch.as_tensor(Xval, device=DEVICE)
    condv = one_hot(yval, args.labels).to(DEVICE)
    threshold = tune_threshold(disc, Xval_t, yval, condv)

    torch.save(disc.state_dict(), "discriminator.pt")
    with open("scaler.pkl", "wb") as f:
        pickle.dump(scaler, f)
    with open("threshold.pkl", "wb") as f:
        pickle.dump(threshold, f)
    print("Exported: discriminator.pt, scaler.pkl, threshold.pkl (+ best_arch.json)")


if __name__ == "__main__":
    main()
