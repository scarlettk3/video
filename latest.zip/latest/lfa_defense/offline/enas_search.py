"""
enas_search.py
--------------
Evolutionary/efficient Neural Architecture Search for the SD-CGAN cells.

Two ways to run:
  1. This lightweight built-in search (random/evolutionary sampling with a
     shared-weight proxy score) -- good enough for a B.Tech prototype and has
     no heavy dependencies.
  2. Microsoft NNI's ENAS trainer (recommended if you want a true RL controller
     with weight sharing). See the `use_nni` note at the bottom.

Output: best_arch.json  (consumed by sd_cgan_train.py and the Ryu detector).

NOTE: This is a runnable SKELETON. The proxy-fitness here trains each candidate
briefly; replace `evaluate_candidate` with your real validation-F1 reward.
"""
from __future__ import annotations

import argparse
import json
import random

from model_builder import OPERATIONS

# A candidate architecture = a short list of ops per network.
GEN_CELLS = (2, 4)   # min/max cells for the generator
DIS_CELLS = (2, 4)   # min/max cells for the discriminator


def sample_arch(feature_dim: int, noise_dim: int, n_labels: int) -> dict:
    g_cells = [random.choice(OPERATIONS) for _ in range(random.randint(*GEN_CELLS))]
    d_cells = [random.choice(OPERATIONS) for _ in range(random.randint(*DIS_CELLS))]
    return {
        "generator": {
            "input_dim": noise_dim, "cond_dim": n_labels,
            "cells": g_cells, "out_dim": feature_dim,
        },
        "discriminator": {
            "input_dim": feature_dim, "cond_dim": n_labels,
            "cells": d_cells,
        },
    }


def mutate(arch: dict) -> dict:
    """Evolutionary step: randomly swap one op in each network."""
    import copy
    child = copy.deepcopy(arch)
    for net in ("generator", "discriminator"):
        cells = child[net]["cells"]
        i = random.randrange(len(cells))
        cells[i] = random.choice(OPERATIONS)
    return child


def evaluate_candidate(arch: dict, data) -> float:
    """Return a fitness score (higher is better) for an architecture.

    REPLACE THIS with a short SD-CGAN training run + validation F1-score.
    The stub returns a random proxy so the search loop is runnable end-to-end.
    """
    # from sd_cgan_train import quick_proxy_f1
    # return quick_proxy_f1(arch, data, epochs=5)
    return random.random()


def search(feature_dim: int, noise_dim: int, n_labels: int,
           population: int = 8, generations: int = 5, data=None) -> dict:
    pop = [sample_arch(feature_dim, noise_dim, n_labels) for _ in range(population)]
    scored = [(evaluate_candidate(a, data), a) for a in pop]

    for g in range(generations):
        scored.sort(key=lambda t: t[0], reverse=True)
        elite = [a for _, a in scored[: max(2, population // 2)]]
        children = [mutate(random.choice(elite)) for _ in range(population - len(elite))]
        pop = elite + children
        scored = [(evaluate_candidate(a, data), a) for a in pop]
        best = max(scored, key=lambda t: t[0])
        print(f"[gen {g + 1}/{generations}] best fitness = {best[0]:.4f}")

    best_score, best_arch = max(scored, key=lambda t: t[0])
    print(f"[done] best fitness = {best_score:.4f}")
    return best_arch


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--feature-dim", type=int, default=7)
    ap.add_argument("--noise-dim", type=int, default=32)
    ap.add_argument("--labels", type=int, default=2, help="normal / LFA")
    ap.add_argument("--population", type=int, default=8)
    ap.add_argument("--generations", type=int, default=5)
    ap.add_argument("--out", default="best_arch.json")
    args = ap.parse_args()

    best = search(args.feature_dim, args.noise_dim, args.labels,
                  args.population, args.generations)
    with open(args.out, "w") as f:
        json.dump(best, f, indent=2)
    print(f"Wrote {args.out}")


if __name__ == "__main__":
    main()

# --- Using NNI's ENAS instead (optional) -----------------------------------
# from nni.retiarii import model_wrapper
# from nni.retiarii.oneshot.pytorch import EnasTrainer
# Define your search space with nni.retiarii.nn.pytorch.LayerChoice over OPERATIONS,
# set reward=validation F1, and let EnasTrainer handle the RL controller + weight
# sharing. Export the chosen architecture to best_arch.json in the same shape above.
