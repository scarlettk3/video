"""
monitor.py
----------
Periodically polls flow and port statistics from every connected switch using
OpenFlow read-state requests, and hands the parsed records to the feature
extractor. Mix this into your main Ryu app (or use it as a standalone app).

SKELETON: the request/reply handlers are complete; the aggregation into the
feature extractor's input format is marked TODO where topology-specific.
"""
from __future__ import annotations

from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER, DEAD_DISPATCHER, set_ev_cls
from ryu.lib import hub
from ryu.ofproto import ofproto_v1_3

POLL_INTERVAL = 3  # seconds (2-5 s recommended)


class Monitor(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.datapaths = {}
        self.latest_flows = []       # list of flow dicts for feature_extractor
        self.latest_port_stats = {}  # aggregated queue/latency proxies
        self.monitor_thread = hub.spawn(self._monitor)

    @set_ev_cls(ofp_event.EventOFPStateChange, [MAIN_DISPATCHER, DEAD_DISPATCHER])
    def _state_change(self, ev):
        dp = ev.datapath
        if ev.state == MAIN_DISPATCHER:
            self.datapaths[dp.id] = dp
        elif ev.state == DEAD_DISPATCHER and dp.id in self.datapaths:
            del self.datapaths[dp.id]

    def _monitor(self):
        while True:
            for dp in list(self.datapaths.values()):
                self._request_stats(dp)
            hub.sleep(POLL_INTERVAL)

    def _request_stats(self, datapath):
        parser = datapath.ofproto_parser
        datapath.send_msg(parser.OFPFlowStatsRequest(datapath))
        datapath.send_msg(parser.OFPPortStatsRequest(datapath, 0,
                                                     datapath.ofproto.OFPP_ANY))

    @set_ev_cls(ofp_event.EventOFPFlowStatsReply, MAIN_DISPATCHER)
    def _flow_stats_reply(self, ev):
        flows = []
        for stat in ev.msg.body:
            m = stat.match
            flows.append({
                "src_ip": m.get("ipv4_src", "?"),
                "dst_ip": m.get("ipv4_dst", "?"),
                "proto": m.get("ip_proto", 0),
                "bytes": stat.byte_count,
                "packets": stat.packet_count,
            })
        # TODO: key flows by link using topology adjacency for per-link entropy.
        self.latest_flows = flows

    @set_ev_cls(ofp_event.EventOFPPortStatsReply, MAIN_DISPATCHER)
    def _port_stats_reply(self, ev):
        # Approximate queue/latency proxies from port counters (no true INT).
        tx = sum(p.tx_bytes for p in ev.msg.body)
        drops = sum(p.tx_dropped + p.rx_dropped for p in ev.msg.body)
        self.latest_port_stats = {
            "avg_queue_len": float(drops),          # proxy: drops ~ congestion
            "avg_hop_latency": float(tx) / 1e6,     # crude proxy; replace w/ INT
        }
