"""
detector.py
-----------
Loads the offline-trained SD-CGAN discriminator and runs fast inference on the
Ryu controller. Called once per monitoring interval (2-5 s).

Requires the four offline artifacts on the controller's path:
    best_arch.json, discriminator.pt, scaler.pkl, threshold.pkl
"""
from __future__ import annotations

import json
import pickle
from pathlib import Path

import numpy as np
import torch

# The controller must be able to import the same model builder used offline.
# Copy offline/model_builder.py next to this file, or add it to PYTHONPATH.
from model_builder import build_model_from_arch

ARTIFACT_DIR = Path(__file__).parent


class LFADetector:
    def __init__(self, artifact_dir: str | Path = ARTIFACT_DIR, n_labels: int = 2):
        artifact_dir = Path(artifact_dir)
        arch = json.load(open(artifact_dir / "best_arch.json"))
        self.n_labels = n_labels
        self.model = build_model_from_arch(arch["discriminator"], "discriminator")
        self.model.load_state_dict(torch.load(artifact_dir / "discriminator.pt",
                                              map_location="cpu"))
        self.model.eval()
        with open(artifact_dir / "scaler.pkl", "rb") as f:
            self.scaler = pickle.load(f)
        with open(artifact_dir / "threshold.pkl", "rb") as f:
            self.threshold = float(pickle.load(f))

    def _cond(self, label: int = 1) -> torch.Tensor:
        c = torch.zeros(1, self.n_labels, dtype=torch.float32)
        c[0, label] = 1.0
        return c

    @torch.no_grad()
    def score(self, feature_vector: list[float]) -> float:
        x = self.scaler.transform([feature_vector]).astype(np.float32)
        x = torch.tensor(x, dtype=torch.float32)
        # Conditioned on the "LFA" label so the discriminator judges LFA-likeness.
        return float(self.model(x, self._cond(label=1)).item())

    def predict(self, feature_vector: list[float]) -> bool:
        """True => LFA detected."""
        return self.score(feature_vector) > self.threshold
