"""
mitigator.py
------------
Entropy-weighted shortest-path rerouting. No model, no training -- pure math on
the live topology graph.

Idea: low per-link entropy => repetitive/bursty (suspicious) traffic => higher
cost => Dijkstra avoids that link. When entropy normalizes, costs decay back to
`base_cost` and routing reverts automatically.
"""
from __future__ import annotations

import numpy as np

try:
    import networkx as nx
except Exception:  # allows import without networkx during static checks
    nx = None


def shannon_entropy(counts) -> float:
    counts = np.asarray(list(counts), dtype=np.float64)
    if counts.sum() == 0:
        return 0.0
    p = counts / counts.sum()
    return float(-np.sum(p * np.log2(p + 1e-12)))


def update_link_costs(graph, link_stats: dict, base_cost: float = 1.0,
                      alpha: float = 5.0):
    """
    link_stats: {(u, v): iterable_of_counts}  (e.g. src-IP distribution per link)
    Lower entropy -> higher cost. `alpha` is the main tuning knob.
    """
    for (u, v), dist in link_stats.items():
        dist = list(dist) or [1]
        H = shannon_entropy(dist)
        H_norm = H / np.log2(len(dist)) if len(dist) > 1 else 0.0
        congestion_factor = 1.0 - H_norm            # low entropy -> high factor
        cost = base_cost * (1.0 + alpha * congestion_factor)
        if graph.has_edge(u, v):
            graph[u][v]["weight"] = cost
        if graph.has_edge(v, u):
            graph[v][u]["weight"] = cost
    return graph


def decay_link_costs(graph, base_cost: float = 1.0, rate: float = 0.5):
    """Move every edge weight back toward base_cost (called on clean cycles)."""
    for u, v, data in graph.edges(data=True):
        w = data.get("weight", base_cost)
        data["weight"] = base_cost + (w - base_cost) * rate
    return graph


def recompute_path(graph, src, dst):
    if nx is None:
        raise RuntimeError("networkx is required for rerouting")
    return nx.dijkstra_path(graph, src, dst, weight="weight")


def paths_to_flowmods(datapaths, parser, path, match_fields):
    """
    Translate a switch path [s1, s2, ...] into OpenFlow FlowMod messages.

    This is a SKELETON: fill in per-switch output-port lookup from your
    topology_discovery adjacency (which port on s_i faces s_{i+1}).
    """
    mods = []
    for i in range(len(path) - 1):
        cur, nxt = path[i], path[i + 1]
        out_port = _port_between(cur, nxt)      # TODO: from topology adjacency
        dp = datapaths.get(cur)
        if dp is None or out_port is None:
            continue
        match = parser.OFPMatch(**match_fields)
        actions = [parser.OFPActionOutput(out_port)]
        inst = [parser.OFPInstructionActions(dp.ofproto.OFPIT_APPLY_ACTIONS, actions)]
        mods.append(parser.OFPFlowMod(datapath=dp, priority=200, match=match,
                                      instructions=inst, hard_timeout=60))
    return mods


def _port_between(src_dpid, dst_dpid):
    """TODO: return the output port on src_dpid that leads to dst_dpid,
    using the adjacency built by topology_discovery.py."""
    return None
