"""
main_controller.py
------------------
Wires the monitor, topology, detector and mitigator into a single Ryu app.

Run:
    ryu-manager --observe-links main_controller.py

Make sure the four offline artifacts and model_builder.py are on the path:
    best_arch.json, discriminator.pt, scaler.pkl, threshold.pkl, model_builder.py
"""
from __future__ import annotations

from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import CONFIG_DISPATCHER, MAIN_DISPATCHER, set_ev_cls
from ryu.lib import hub
from ryu.ofproto import ofproto_v1_3

from detector import LFADetector
from feature_extractor import extract_features, per_link_distributions
from mitigator import update_link_costs, decay_link_costs, recompute_path
from topology_discovery import TopologyGraph

POLL_INTERVAL = 3
ALPHA = 5.0        # entropy-cost aggressiveness (main knob)
BASE_COST = 1.0


class LFADefenseController(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.datapaths = {}
        self.topo = TopologyGraph()
        self.detector = LFADetector()          # loads offline artifacts
        self.latest_flows = []
        self.latest_port_stats = {}
        self.flows_by_link = {}
        self.thread = hub.spawn(self._loop)
        self.logger.info("LFA Defense controller ready (SD-CGAN + entropy rerouting)")

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def _features(self, ev):
        dp = ev.msg.datapath
        self.datapaths[dp.id] = dp
        # install table-miss -> controller
        p = dp.ofproto_parser
        match = p.OFPMatch()
        actions = [p.OFPActionOutput(dp.ofproto.OFPP_CONTROLLER,
                                     dp.ofproto.OFPCML_NO_BUFFER)]
        inst = [p.OFPInstructionActions(dp.ofproto.OFPIT_APPLY_ACTIONS, actions)]
        dp.send_msg(p.OFPFlowMod(datapath=dp, priority=0, match=match, instructions=inst))

    def _loop(self):
        while True:
            self._poll_stats()
            self._detect_and_mitigate()
            hub.sleep(POLL_INTERVAL)

    def _poll_stats(self):
        for dp in list(self.datapaths.values()):
            p = dp.ofproto_parser
            dp.send_msg(p.OFPFlowStatsRequest(dp))
            dp.send_msg(p.OFPPortStatsRequest(dp, 0, dp.ofproto.OFPP_ANY))

    @set_ev_cls(ofp_event.EventOFPFlowStatsReply, MAIN_DISPATCHER)
    def _flow_reply(self, ev):
        flows = []
        for s in ev.msg.body:
            m = s.match
            flows.append({
                "src_ip": m.get("ipv4_src", "?"), "dst_ip": m.get("ipv4_dst", "?"),
                "proto": m.get("ip_proto", 0),
                "bytes": s.byte_count, "packets": s.packet_count,
            })
        self.latest_flows = flows
        # TODO: bucket flows into self.flows_by_link using topology adjacency.

    @set_ev_cls(ofp_event.EventOFPPortStatsReply, MAIN_DISPATCHER)
    def _port_reply(self, ev):
        drops = sum(p.tx_dropped + p.rx_dropped for p in ev.msg.body)
        tx = sum(p.tx_bytes for p in ev.msg.body)
        self.latest_port_stats = {"avg_queue_len": float(drops),
                                  "avg_hop_latency": float(tx) / 1e6}

    def _detect_and_mitigate(self):
        feats = extract_features(self.latest_flows, self.latest_port_stats)
        is_lfa = self.detector.predict(feats)

        if not is_lfa:
            if self.topo.graph is not None:
                decay_link_costs(self.topo.graph, BASE_COST)
            return

        self.logger.warning("LFA DETECTED -> rerouting")
        if self.topo.graph is None or not self.flows_by_link:
            return
        link_stats = per_link_distributions(self.flows_by_link)
        update_link_costs(self.topo.graph, link_stats, BASE_COST, ALPHA)
        # TODO: for each affected (src_switch, dst_switch), recompute_path()
        #       and push OFPFlowMod via mitigator.paths_to_flowmods(...).
