"""
topology_discovery.py
---------------------
Builds a live NetworkX graph of switches/links from Ryu's LLDP-based topology
events. The graph (with per-link adjacency and output ports) is consumed by
mitigator.py for Dijkstra rerouting.

SKELETON: hook these handlers into your main Ryu app (or run ryu-manager with
--observe-links so topology events fire).
"""
from __future__ import annotations

try:
    import networkx as nx
except Exception:
    nx = None

from ryu.topology import event as topo_event
from ryu.topology.api import get_switch, get_link


class TopologyGraph:
    def __init__(self):
        self.graph = nx.DiGraph() if nx else None
        # adjacency[(src_dpid, dst_dpid)] = out_port on src facing dst
        self.adjacency: dict[tuple[int, int], int] = {}

    def rebuild(self, app):
        """Call on topology change: repopulate switches, links, adjacency."""
        if nx is None:
            return
        self.graph.clear()
        self.adjacency.clear()
        for sw in get_switch(app, None):
            self.graph.add_node(sw.dp.id)
        for link in get_link(app, None):
            s, d = link.src, link.dst
            self.graph.add_edge(s.dpid, d.dpid, weight=1.0)
            self.adjacency[(s.dpid, d.dpid)] = s.port_no

    def out_port(self, src_dpid: int, dst_dpid: int):
        return self.adjacency.get((src_dpid, dst_dpid))


# Example event wiring (place inside your RyuApp subclass):
#
#   @set_ev_cls(topo_event.EventSwitchEnter)
#   def _switch_enter(self, ev):
#       self.topo.rebuild(self)
#
#   @set_ev_cls(topo_event.EventLinkAdd)
#   def _link_add(self, ev):
#       self.topo.rebuild(self)
