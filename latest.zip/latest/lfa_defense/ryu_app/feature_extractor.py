"""
feature_extractor.py
--------------------
Turns raw per-flow / per-port statistics into the SD-CGAN feature vector:

    [ H_srcIP, H_dstIP, H_proto, total_bytes, total_packets,
      avg_queue_len, avg_hop_latency ]

The entropies use Shannon by default; set RENYI_ALPHA to use Renyi entropy
(better at catching stealthy low-rate floods -- tunable sensitivity).
"""
from __future__ import annotations

from collections import Counter

import numpy as np

RENYI_ALPHA: float | None = None  # e.g. 2.0 to switch to Renyi entropy


def shannon_entropy(counts) -> float:
    counts = np.asarray(list(counts), dtype=np.float64)
    if counts.sum() == 0:
        return 0.0
    p = counts / counts.sum()
    return float(-np.sum(p * np.log2(p + 1e-12)))


def renyi_entropy(counts, alpha: float) -> float:
    counts = np.asarray(list(counts), dtype=np.float64)
    if counts.sum() == 0:
        return 0.0
    p = counts / counts.sum()
    if abs(alpha - 1.0) < 1e-9:
        return shannon_entropy(counts)
    return float(1.0 / (1.0 - alpha) * np.log2(np.sum(p ** alpha) + 1e-12))


def _entropy(values) -> float:
    counts = Counter(values).values()
    if RENYI_ALPHA is not None:
        return renyi_entropy(counts, RENYI_ALPHA)
    return shannon_entropy(counts)


def extract_features(flows: list[dict], port_stats: dict) -> list[float]:
    """
    flows: list of dicts with keys src_ip, dst_ip, proto, bytes, packets
    port_stats: dict with keys avg_queue_len, avg_hop_latency (from monitor)
    """
    if not flows:
        return [0.0] * 7
    h_src = _entropy(f["src_ip"] for f in flows)
    h_dst = _entropy(f["dst_ip"] for f in flows)
    h_proto = _entropy(f["proto"] for f in flows)
    total_bytes = float(sum(f.get("bytes", 0) for f in flows))
    total_pkts = float(sum(f.get("packets", 0) for f in flows))
    avg_q = float(port_stats.get("avg_queue_len", 0.0))
    avg_lat = float(port_stats.get("avg_hop_latency", 0.0))
    return [h_src, h_dst, h_proto, total_bytes, total_pkts, avg_q, avg_lat]


def per_link_distributions(flows_by_link: dict) -> dict:
    """For mitigation: map each link (u,v) -> list of src-IP counts, used to
    compute per-link entropy in mitigator.update_link_costs()."""
    dist = {}
    for link, flows in flows_by_link.items():
        dist[link] = list(Counter(f["src_ip"] for f in flows).values()) or [1]
    return dist
