"""
topo.py
-------
Mininet topology (Network1-style) with legitimate hosts, attacker hosts, and a
bait/decoy server, plus a shared bottleneck link that LFA will try to congest.

Run:
    sudo python3 topo.py            # starts Mininet CLI against a remote Ryu ctrl
    # (start the controller first: ryu-manager --observe-links ../ryu_app/main_controller.py)
"""
from mininet.net import Mininet
from mininet.node import RemoteController, OVSSwitch
from mininet.link import TCLink
from mininet.cli import CLI
from mininet.log import setLogLevel


def build(controller_ip="127.0.0.1", controller_port=6653):
    net = Mininet(controller=None, switch=OVSSwitch, link=TCLink,
                  autoSetMacs=True)

    c0 = net.addController("c0", controller=RemoteController,
                           ip=controller_ip, port=controller_port)

    # Switches
    s1, s2, s3 = [net.addSwitch(s, protocols="OpenFlow13") for s in ("s1", "s2", "s3")]

    # Legitimate users
    h1 = net.addHost("h1"); h2 = net.addHost("h2"); h3 = net.addHost("h3")
    # Attackers (bots)
    h4 = net.addHost("h4"); h5 = net.addHost("h5"); h6 = net.addHost("h6")
    # Bait / decoy server near the target region
    bait = net.addHost("bait")

    # Access links
    net.addLink(h1, s1); net.addLink(h4, s1)
    net.addLink(h2, s2); net.addLink(h3, s2)
    net.addLink(h5, s3); net.addLink(h6, s3); net.addLink(bait, s3)

    # Backbone with a deliberate bottleneck s2--s3 (the LFA target link)
    net.addLink(s1, s2, bw=100)
    net.addLink(s2, s3, bw=10)     # narrow link -> easy to flood

    net.build()
    c0.start()
    for s in (s1, s2, s3):
        s.start([c0])
    return net


if __name__ == "__main__":
    setLogLevel("info")
    net = build()
    print("Topology up. Try:  h1 iperf -s   /   h5 iperf -c <bait> -u -b 2M -t 60")
    CLI(net)
    net.stop()
