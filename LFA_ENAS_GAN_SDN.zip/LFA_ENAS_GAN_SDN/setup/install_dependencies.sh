#!/bin/bash
# =============================================================================
# LFA-ENAS-GAN-SDN: Full Dependency Installation Script
# OS: Ubuntu 20.04 / 22.04 LTS
# Run as: sudo bash install_dependencies.sh
# =============================================================================

set -e  # Exit on error

echo "============================================================"
echo "  LFA-ENAS-GAN-SDN: Environment Setup"
echo "  Ubuntu 20.04/22.04 - Full Installation"
echo "============================================================"

# --- Step 1: Update system ---
echo "[1/12] Updating system packages..."
apt-get update -y && apt-get upgrade -y

# --- Step 2: Install system prerequisites ---
echo "[2/12] Installing system prerequisites..."
apt-get install -y \
    git curl wget build-essential \
    python3 python3-pip python3-dev python3-venv \
    net-tools iproute2 iputils-ping \
    tcpdump wireshark tshark \
    openvswitch-switch openvswitch-common \
    iperf iperf3 hping3 \
    software-properties-common \
    apt-transport-https ca-certificates \
    libssl-dev libffi-dev \
    unzip htop tmux vim

# --- Step 3: Install Mininet ---
echo "[3/12] Installing Mininet..."
cd /tmp
if [ -d "mininet" ]; then rm -rf mininet; fi
git clone https://github.com/mininet/mininet.git
cd mininet
# Install Mininet with OpenFlow reference switch (option -a = all components)
bash util/install.sh -a
cd ~
echo "  Mininet installed. Test with: sudo mn --test pingall"

# --- Step 4: Install Open vSwitch (if not already from Mininet install) ---
echo "[4/12] Verifying Open vSwitch..."
ovs-vswitchd --version || apt-get install -y openvswitch-switch
systemctl enable openvswitch-switch
systemctl start openvswitch-switch
echo "  OVS version: $(ovs-vswitchd --version | head -1)"

# --- Step 5: Install Ryu SDN Controller ---
echo "[5/12] Installing Ryu Controller..."
pip3 install ryu==4.34
# Ryu dependencies
pip3 install eventlet==0.30.2 oslo.config msgpack
echo "  Ryu installed. Test with: ryu-manager --version"

# --- Step 6: Install Scapy ---
echo "[6/12] Installing Scapy..."
pip3 install scapy
echo "  Scapy installed."

# --- Step 7: Install Python networking & ML packages ---
echo "[7/12] Installing Python packages..."
pip3 install \
    numpy==1.24.3 \
    pandas==2.0.3 \
    scikit-learn==1.3.0 \
    matplotlib==3.7.2 \
    seaborn==0.12.2 \
    scipy==1.11.1 \
    tqdm \
    joblib \
    networkx \
    dpkt \
    pyshark \
    imbalanced-learn

# --- Step 8: Install TensorFlow ---
echo "[8/12] Installing TensorFlow..."
pip3 install tensorflow==2.13.0
echo "  TensorFlow installed."

# --- Step 9: Install PyTorch ---
echo "[9/12] Installing PyTorch (CPU version)..."
pip3 install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
echo "  PyTorch installed."

# --- Step 10: Install D-ITG (traffic generator) ---
echo "[10/12] Installing D-ITG..."
apt-get install -y d-itg || {
    echo "  D-ITG not in apt repos, building from source..."
    cd /tmp
    wget -q http://traffic.comics.unina.it/software/ITG/codice/D-ITG-2.8.1-r1023-src.zip || \
        echo "  D-ITG not available - using iperf3 as alternative (already installed)"
}

# --- Step 11: Install CICFlowMeter dependencies ---
echo "[11/12] Installing flow feature extraction tools..."
pip3 install \
    cicflowmeter || \
    pip3 install nfstream  # Alternative flow analyzer
# tshark already installed above via wireshark/tshark

# --- Step 12: Install Jupyter for analysis ---
echo "[12/12] Installing Jupyter..."
pip3 install jupyter jupyterlab notebook ipywidgets

echo ""
echo "============================================================"
echo "  INSTALLATION COMPLETE"
echo "============================================================"
echo ""
echo "Post-install checks:"
echo "  mn --version           -> Mininet version"
echo "  ryu-manager --version  -> Ryu version"
echo "  ovs-vsctl show         -> OVS state"
echo "  python3 -c 'import tensorflow; print(tensorflow.__version__)'"
echo "  python3 -c 'import torch; print(torch.__version__)'"
echo ""
echo "  Next step: cd ../topology && sudo python3 fat_tree_topology.py"
echo "============================================================"
