# LFA-ENAS-GAN-SDN
## Evolutionary NAS + GAN for Advanced Link Flooding Attack Detection in SDN

> **Research Project** — Publication-level implementation for IEEE submission

---

## Project Structure

```
LFA_ENAS_GAN_SDN/
├── setup/
│   ├── install_dependencies.sh   # Full Ubuntu environment setup
│   └── requirements.txt          # Python package list
│
├── topology/
│   ├── fat_tree_topology.py      # Fat-Tree k=4 Mininet topology (16 hosts)
│   ├── nsfnet_topology.py        # 14-node NSFNET WAN topology
│   └── run_topology.sh           # Startup script
│
├── controller/
│   └── ryu_controller.py         # Ryu OpenFlow 1.3 controller + telemetry + REST API
│
├── traffic/
│   └── normal_traffic.py         # TCP / UDP / ICMP / HTTP / video traffic generator
│
├── attacks/
│   ├── traditional_lfa.py        # Attack A: Classic multi-bot LFA + hping3 cmds
│   ├── topology_poisoning_lfa.py # Attack B: Fake LLDP injection (Scapy)
│   ├── telemetry_evasion_lfa.py  # Attack C: Burst-timing + stealth flows
│   ├── slice_aware_lfa.py        # Attack D: DSCP/VLAN slice exhaustion
│   ├── flow_rule_saturation.py   # Attack E: TCAM overflow + Packet-In storm
│   └── quantum_inspired_lfa.py  # Attack F: Quantum random walk coordination
│
├── feature_extraction/
│   ├── capture_packets.sh        # tcpdump + tshark capture commands
│   ├── extract_features.py       # PCAP → 20 flow features (dpkt/Scapy)
│   └── dataset_builder.py        # Clean + normalize + SMOTE + train/val/test split
│
├── models/
│   ├── gan_model.py              # Generator + Discriminator + GANTrainer
│   ├── enas_search.py            # Evolutionary NAS (population, crossover, mutation)
│   └── train_model.py            # Full pipeline: ENAS→GAN→fine-tune→evaluate
│
├── evaluation/
│   └── metrics.py                # All 8 publication figures + metrics table
│
├── paper/
│   └── research_paper_outline.md # Complete IEEE paper structure
│
├── datasets/                     # Generated datasets (created at runtime)
│   ├── pcap/                     # Raw PCAP captures
│   ├── features/                 # Extracted CSV features
│   ├── train.csv / val.csv / test.csv
│   └── telemetry.csv             # Controller telemetry
│
└── logs/                         # Runtime logs
```

---

## Step-by-Step Execution Guide

### PHASE 1: Environment Setup (Ubuntu 20.04/22.04)

```bash
# Step 1.1: Install all dependencies
sudo bash setup/install_dependencies.sh

# Step 1.2: Verify installations
mn --version                  # Should show Mininet version
ryu-manager --version         # Should show Ryu version
ovs-vsctl show                # Should show OVS bridge info
python3 -c "import tensorflow; print(tensorflow.__version__)"
python3 -c "import torch; print(torch.__version__)"
```

---

### PHASE 2: Start SDN Topology + Controller

**Terminal 1** — Start Ryu controller:
```bash
cd controller/
ryu-manager ryu_controller.py \
    --observe-links \
    --ofp-tcp-listen-port 6633 \
    --wsapi-port 8080
```

**Terminal 2** — Start Mininet topology:
```bash
# Fat-Tree topology (default, recommended):
sudo python3 topology/fat_tree_topology.py --controller 127.0.0.1 --k 4

# OR: NSFNET WAN topology:
sudo python3 topology/nsfnet_topology.py --controller 127.0.0.1
```

**Expected output:**
```
*** Adding remote controller at 127.0.0.1:6633
*** Starting network
*** Network topology ready
    Switches : 20
    Hosts    : 16
    Links    : 48
```

---

### PHASE 3: Generate Normal Background Traffic

Inside Mininet CLI or from host terminals:
```bash
# Inside Mininet CLI:
mininet> h1 python3 traffic/normal_traffic.py --mode background --duration 120 &

# Manual commands (inside Mininet):
mininet> h2 iperf3 -s -p 5201 &
mininet> h1 iperf3 -c 10.0.1.2 -t 60 -b 10M -P 4 -p 5201

mininet> h4 iperf3 -s -u -p 5002 &
mininet> h3 iperf3 -c 10.0.1.3 -u -b 5M -t 60 -p 5002

mininet> h1 ping -c 500 -i 0.1 10.2.0.2

# View command reference:
python3 traffic/normal_traffic.py --mode info
```

---

### PHASE 4: Launch Attack Scenarios

**Attack A — Traditional LFA:**
```bash
# From multiple hosts simultaneously:
mininet> h1 python3 attacks/traditional_lfa.py --decoy 10.2.0.2 --num-bots 8 --duration 120 &
mininet> h2 python3 attacks/traditional_lfa.py --decoy 10.2.0.2 --num-bots 8 --duration 120 &

# Show hping3 commands:
python3 attacks/traditional_lfa.py --show-commands
# Then: hping3 -S -p 80 -i u10000 -c 12000 10.2.0.2
```

**Attack B — Topology Poisoning:**
```bash
# Requires root + Scapy:
sudo python3 attacks/topology_poisoning_lfa.py \
    --interface h1-eth0 \
    --target 10.2.0.2 \
    --controller 127.0.0.1

# Show Scapy LLDP script:
python3 attacks/topology_poisoning_lfa.py --show-scapy
```

**Attack C — Telemetry Evasion:**
```bash
python3 attacks/telemetry_evasion_lfa.py \
    --target 10.2.0.2 \
    --poll-interval 2 \
    --duration 120
```

**Attack D — Slice-Aware:**
```bash
# First configure QoS queues:
python3 attacks/slice_aware_lfa.py --show-ovs
# Then run attack:
python3 attacks/slice_aware_lfa.py \
    --interface eth0 --target 10.2.0.2 --slice 1 --duration 90
```

**Attack E — Flow-Rule Saturation:**
```bash
python3 attacks/flow_rule_saturation.py \
    --target 10.0.0.0/24 --duration 60 --rate 10000
```

**Attack F — Quantum-Inspired LFA:**
```bash
python3 attacks/quantum_inspired_lfa.py \
    --targets 10.0.0.2,10.1.0.2,10.2.0.2 \
    --bottleneck 10.2.0.2 \
    --num-bots 12 \
    --duration 180
```

---

### PHASE 5: Capture Traffic & Extract Features

```bash
# Capture normal traffic (run during Phase 3):
bash feature_extraction/capture_packets.sh 60 any normal

# Capture each attack type:
bash feature_extraction/capture_packets.sh 60 any traditional_lfa
bash feature_extraction/capture_packets.sh 60 any topology_poisoning
bash feature_extraction/capture_packets.sh 60 any telemetry_evasion
bash feature_extraction/capture_packets.sh 60 any slice_aware
bash feature_extraction/capture_packets.sh 60 any flow_saturation
bash feature_extraction/capture_packets.sh 60 any quantum_lfa

# Extract features from all PCAPs:
python3 feature_extraction/extract_features.py \
    --pcap datasets/pcap/ --label auto --output datasets/features/

# Build train/val/test dataset:
python3 feature_extraction/dataset_builder.py \
    --features-dir datasets/features/ \
    --output-dir datasets/

# Generate demo dataset (no real captures needed):
python3 feature_extraction/dataset_builder.py --demo
```

---

### PHASE 6: ENAS + GAN + Training Pipeline

```bash
# Full pipeline (ENAS search + GAN training + fine-tune):
python3 models/train_model.py \
    --dataset datasets/ \
    --save-dir models/ \
    --enas-gens 30 \
    --gan-epochs 200 \
    --detector-epochs 100

# Quick demo (skip ENAS, use default arch):
python3 models/train_model.py --no-enas --gan-epochs 50 --detector-epochs 50

# ENAS search only:
python3 models/enas_search.py \
    --dataset datasets/ \
    --population 20 \
    --generations 30 \
    --eval-epochs 10

# GAN training only:
python3 models/gan_model.py --train --epochs 200 --dataset datasets/
```

---

### PHASE 7: Evaluate & Generate Figures

```bash
# Generate all 8 publication figures:
python3 evaluation/metrics.py \
    --results-dir models/ \
    --dataset datasets/ \
    --output paper/figures/

# Demo mode (uses synthetic data):
python3 evaluation/metrics.py --demo

# Figures generated:
#   fig1_confusion_matrix.png    - Normalized confusion matrix
#   fig2_roc_curves.png          - Per-class ROC + AUC bar chart
#   fig3_pr_curves.png           - Precision-Recall curves
#   fig4_gan_losses.png          - GAN convergence + detector training
#   fig5_enas_evolution.png      - Fitness over generations
#   fig6_link_utilization.png    - SDN link utilization + detection timeline
#   fig7_metrics_table.png       - Per-class metric heatmap
#   fig8_feature_comparison.png  - Feature distributions by class
```

---

### PHASE 8: Real-Time SDN Detection

```bash
# With trained model + running Ryu controller:
python3 models/train_model.py \
    --realtime \
    --controller 127.0.0.1

# Expected output:
# 2024-01-01 12:00:00 [TRAIN] Real-time SDN detection started
# 2024-01-01 12:00:02 [TRAIN] Normal traffic (conf=94.3%)
# 2024-01-01 12:00:04 [TRAIN] ALERT #1: Traditional LFA detected (conf=87.2%)
# 2024-01-01 12:00:06 [TRAIN] ALERT #2: Quantum LFA detected (conf=79.5%)
```

---

## Expected Results

| Metric | Expected Value |
|--------|---------------|
| Test Accuracy | > 93% |
| Macro F1 | > 0.920 |
| False Positive Rate | < 2.5% |
| Detection Latency | < 2 ms/sample |
| ENAS Convergence | ~15-20 generations |

---

## System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| OS | Ubuntu 20.04 | Ubuntu 22.04 |
| CPU | 4 cores | 8+ cores |
| RAM | 8 GB | 16 GB |
| Disk | 20 GB | 50 GB |
| GPU | None (CPU works) | CUDA GPU for faster training |

---

## Troubleshooting

```bash
# Mininet cleanup after crash:
sudo mn -c

# OVS not starting:
sudo systemctl start openvswitch-switch
sudo ovs-vsctl show

# Ryu port already in use:
sudo pkill -f ryu-manager
sleep 2
ryu-manager controller/ryu_controller.py ...

# Python import errors:
pip3 install -r setup/requirements.txt

# PCAP permission denied:
sudo chmod a+r /tmp/*.pcap

# No Scapy LLDP module:
pip3 install scapy[complete]
```

---

## Citation

If you use this work, please cite:
```bibtex
@article{enas_gan_sdn_lfa_2024,
  title   = {ENAS-GAN-SDN: Evolutionary NAS with GAN for Advanced LFA Detection},
  author  = {[Your Name]},
  journal = {IEEE Transactions on Network and Service Management},
  year    = {2024},
  note    = {Under review}
}
```

---

*All code is modular and documented. Each file can be run independently.*
*See individual file headers for detailed usage instructions.*
