#!/usr/bin/env python3
"""
=============================================================================
LFA-ENAS-GAN-SDN: Ryu SDN Controller
=============================================================================
A full-featured Ryu OpenFlow 1.3 controller that:
  1. Manages flow tables with proactive + reactive forwarding
  2. Collects per-port and per-flow telemetry every 2 seconds
  3. Detects anomalies in link utilization (threshold-based)
  4. Exports telemetry to CSV for ML pipeline
  5. Exposes REST API for external monitoring

Usage (in a separate terminal, BEFORE starting topology):
    ryu-manager controller/ryu_controller.py \
        --observe-links \
        --ofp-tcp-listen-port 6633

REST endpoints:
    GET /stats/links     -> active link bandwidth utilization
    GET /stats/flows     -> current flow table entries
    GET /stats/anomaly   -> detected anomaly status
=============================================================================
"""

import os
import csv
import time
import logging
import datetime
import threading
from collections import defaultdict

from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import (CONFIG_DISPATCHER, MAIN_DISPATCHER,
                                     set_ev_cls)
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet, ethernet, ipv4, tcp, udp, icmp, arp
from ryu.lib import hub
from ryu.topology import event as topo_event
from ryu.topology.api import get_switch, get_link
from ryu.app.wsgi import WSGIApplication, ControllerBase, route
from webob import Response
import json

# ── Logging ────────────────────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO)
LOG = logging.getLogger('LFA_Controller')

# ── Constants ──────────────────────────────────────────────────────────────
TELEMETRY_INTERVAL  = 2          # seconds between stats polling
ANOMALY_BW_THRESH   = 0.85       # 85% link utilization → anomaly flag
FLOW_LIMIT_THRESH   = 800        # max flow entries per switch (TCAM overflow)
STATS_OUTPUT_DIR    = os.path.join(os.path.dirname(__file__),
                                   '..', 'datasets')
STATS_CSV_FILE      = os.path.join(STATS_OUTPUT_DIR, 'telemetry.csv')

os.makedirs(STATS_OUTPUT_DIR, exist_ok=True)

# ── REST API ───────────────────────────────────────────────────────────────
REST_API_NAME = 'lfa_controller_api'


class LFAController(app_manager.RyuApp):
    """
    Main Ryu controller application.
    Handles:
      - Switch connection / feature reply
      - Packet-in for MAC learning + routing
      - Flow statistics collection
      - Port statistics collection
      - Topology discovery (LLDP via --observe-links)
      - Anomaly detection (bandwidth + flow count)
    """

    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]
    _CONTEXTS = {'wsgi': WSGIApplication}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # MAC learning table: {dpid: {mac: out_port}}
        self.mac_to_port = defaultdict(dict)

        # Telemetry storage: {dpid: {port_no: {rx_bytes, tx_bytes, ...}}}
        self.port_stats   = defaultdict(dict)
        self.flow_stats   = defaultdict(list)
        self.prev_stats   = defaultdict(dict)   # for rate calculation
        self.anomaly_flags= defaultdict(bool)   # {dpid: is_anomalous}

        # CSV header written flag
        self._csv_header_written = False
        self._csv_lock = threading.Lock()

        # Register REST API
        wsgi = kwargs['wsgi']
        wsgi.register(LFARestApi,
                      {REST_API_NAME: self})

        # Start telemetry polling thread
        self.monitor_thread = hub.spawn(self._telemetry_loop)

        LOG.info('LFA Controller started. Telemetry → %s', STATS_CSV_FILE)

    # ─────────────────────────────────────────────────────────────────────
    # Switch Handshake
    # ─────────────────────────────────────────────────────────────────────
    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        """Install table-miss flow entry and ARP handler on switch connect."""
        datapath = ev.msg.datapath
        ofproto  = datapath.ofproto
        parser   = datapath.ofproto_parser
        dpid     = datapath.id

        LOG.info('Switch connected: dpid=%016x', dpid)

        # 1. Delete all existing flows
        self._delete_all_flows(datapath)

        # 2. Install ARP handler (send to controller + flood)
        match = parser.OFPMatch(eth_type=0x0806)  # ARP
        actions = [
            parser.OFPActionOutput(ofproto.OFPP_CONTROLLER,
                                   ofproto.OFPCML_NO_BUFFER),
            parser.OFPActionOutput(ofproto.OFPP_FLOOD)
        ]
        self._add_flow(datapath, priority=10, match=match, actions=actions,
                       idle_timeout=0, hard_timeout=0)

        # 3. Table-miss → send to controller
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER,
                                          ofproto.OFPCML_NO_BUFFER)]
        self._add_flow(datapath, priority=0, match=match, actions=actions,
                       idle_timeout=0, hard_timeout=0)

    # ─────────────────────────────────────────────────────────────────────
    # Packet-In: MAC Learning + Forwarding
    # ─────────────────────────────────────────────────────────────────────
    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def packet_in_handler(self, ev):
        msg      = ev.msg
        datapath = msg.datapath
        ofproto  = datapath.ofproto
        parser   = datapath.ofproto_parser
        dpid     = datapath.id
        in_port  = msg.match['in_port']

        pkt     = packet.Packet(msg.data)
        eth_pkt = pkt.get_protocol(ethernet.ethernet)

        if eth_pkt is None:
            return

        dst_mac = eth_pkt.dst
        src_mac = eth_pkt.src

        # Learn source MAC → in_port
        self.mac_to_port[dpid][src_mac] = in_port

        # Determine output port
        if dst_mac in self.mac_to_port[dpid]:
            out_port = self.mac_to_port[dpid][dst_mac]
        else:
            out_port = ofproto.OFPP_FLOOD

        actions = [parser.OFPActionOutput(out_port)]

        # Install a flow rule if we know the destination
        if out_port != ofproto.OFPP_FLOOD:
            # Handle IPv4 flows
            ip_pkt = pkt.get_protocol(ipv4.ipv4)
            if ip_pkt:
                match = parser.OFPMatch(
                    in_port=in_port,
                    eth_type=0x0800,
                    ipv4_src=ip_pkt.src,
                    ipv4_dst=ip_pkt.dst
                )
                self._add_flow(datapath, priority=1, match=match,
                               actions=actions,
                               idle_timeout=30, hard_timeout=60)
            else:
                match = parser.OFPMatch(
                    in_port=in_port,
                    eth_dst=dst_mac,
                    eth_src=src_mac
                )
                self._add_flow(datapath, priority=1, match=match,
                               actions=actions,
                               idle_timeout=30, hard_timeout=60)

        # Send packet out
        data = None
        if msg.buffer_id == ofproto.OFP_NO_BUFFER:
            data = msg.data

        out = parser.OFPPacketOut(
            datapath=datapath,
            buffer_id=msg.buffer_id,
            in_port=in_port,
            actions=actions,
            data=data
        )
        datapath.send_msg(out)

    # ─────────────────────────────────────────────────────────────────────
    # Flow Statistics Reply
    # ─────────────────────────────────────────────────────────────────────
    @set_ev_cls(ofp_event.EventOFPFlowStatsReply, MAIN_DISPATCHER)
    def flow_stats_reply_handler(self, ev):
        dpid = ev.msg.datapath.id
        flows = []
        for stat in ev.msg.body:
            if stat.priority == 0:   # skip table-miss
                continue
            flows.append({
                'priority'  : stat.priority,
                'match'     : str(stat.match),
                'packets'   : stat.packet_count,
                'bytes'     : stat.byte_count,
                'duration'  : stat.duration_sec,
                'idle_age'  : stat.idle_timeout,
            })
        self.flow_stats[dpid] = flows

        # Detect flow-table saturation (TCAM overflow attack indicator)
        if len(flows) > FLOW_LIMIT_THRESH:
            LOG.warning('ANOMALY: Flow table saturation on dpid=%016x '
                        '(entries=%d > threshold=%d)',
                        dpid, len(flows), FLOW_LIMIT_THRESH)
            self.anomaly_flags[dpid] = True

    # ─────────────────────────────────────────────────────────────────────
    # Port Statistics Reply
    # ─────────────────────────────────────────────────────────────────────
    @set_ev_cls(ofp_event.EventOFPPortStatsReply, MAIN_DISPATCHER)
    def port_stats_reply_handler(self, ev):
        dpid = ev.msg.datapath.id
        now  = time.time()

        for stat in ev.msg.body:
            port_no = stat.port_no
            if port_no == ev.msg.datapath.ofproto.OFPP_LOCAL:
                continue

            curr = {
                'rx_bytes'  : stat.rx_bytes,
                'tx_bytes'  : stat.tx_bytes,
                'rx_packets': stat.rx_packets,
                'tx_packets': stat.tx_packets,
                'rx_errors' : stat.rx_errors,
                'tx_errors' : stat.tx_errors,
                'timestamp' : now
            }

            # Compute rates using previous sample
            key = (dpid, port_no)
            if key in self.prev_stats:
                prev = self.prev_stats[key]
                dt = now - prev['timestamp']
                if dt > 0:
                    rx_rate = (curr['rx_bytes'] - prev['rx_bytes']) * 8 / dt  # bps
                    tx_rate = (curr['tx_bytes'] - prev['tx_bytes']) * 8 / dt

                    curr['rx_bps'] = max(0, rx_rate)
                    curr['tx_bps'] = max(0, tx_rate)

                    # Anomaly: bandwidth > threshold of 10 Mbps bottleneck
                    bottleneck_capacity_bps = 10e6   # 10 Mbps
                    utilization = max(rx_rate, tx_rate) / bottleneck_capacity_bps
                    if utilization > ANOMALY_BW_THRESH:
                        LOG.warning(
                            'ANOMALY: High link utilization dpid=%016x '
                            'port=%d util=%.1f%%',
                            dpid, port_no, utilization * 100)
                        self.anomaly_flags[dpid] = True

                    # Write to CSV
                    self._write_telemetry(dpid, port_no, curr)
                else:
                    curr['rx_bps'] = 0
                    curr['tx_bps'] = 0
            else:
                curr['rx_bps'] = 0
                curr['tx_bps'] = 0

            self.prev_stats[key] = curr
            self.port_stats[dpid][port_no] = curr

    # ─────────────────────────────────────────────────────────────────────
    # Telemetry Polling Loop
    # ─────────────────────────────────────────────────────────────────────
    def _telemetry_loop(self):
        """Poll all switches for flow and port statistics every N seconds."""
        while True:
            hub.sleep(TELEMETRY_INTERVAL)
            for dp in self._get_all_datapaths():
                self._request_port_stats(dp)
                self._request_flow_stats(dp)

    def _get_all_datapaths(self):
        """Return list of connected datapaths."""
        from ryu.base.app_manager import lookup_service_brick
        switches_app = lookup_service_brick('switches')
        if switches_app:
            return [sw.dp for sw in get_switch(self, None)]
        return []

    def _request_port_stats(self, datapath):
        parser  = datapath.ofproto_parser
        ofproto = datapath.ofproto
        req = parser.OFPPortStatsRequest(datapath, 0, ofproto.OFPP_ANY)
        datapath.send_msg(req)

    def _request_flow_stats(self, datapath):
        parser  = datapath.ofproto_parser
        ofproto = datapath.ofproto
        req = parser.OFPFlowStatsRequest(datapath)
        datapath.send_msg(req)

    # ─────────────────────────────────────────────────────────────────────
    # Helper: Add flow rule
    # ─────────────────────────────────────────────────────────────────────
    def _add_flow(self, datapath, priority, match, actions,
                  idle_timeout=0, hard_timeout=0, buffer_id=None):
        ofproto = datapath.ofproto
        parser  = datapath.ofproto_parser
        inst    = [parser.OFPInstructionActions(
            ofproto.OFPIT_APPLY_ACTIONS, actions)]

        kwargs = dict(
            datapath=datapath,
            priority=priority,
            match=match,
            instructions=inst,
            idle_timeout=idle_timeout,
            hard_timeout=hard_timeout
        )
        if buffer_id is not None:
            kwargs['buffer_id'] = buffer_id

        mod = parser.OFPFlowMod(**kwargs)
        datapath.send_msg(mod)

    def _delete_all_flows(self, datapath):
        ofproto = datapath.ofproto
        parser  = datapath.ofproto_parser
        match   = parser.OFPMatch()
        instructions = []
        mod = parser.OFPFlowMod(
            datapath=datapath,
            command=ofproto.OFPFC_DELETE,
            out_port=ofproto.OFPP_ANY,
            out_group=ofproto.OFPG_ANY,
            match=match,
            instructions=instructions
        )
        datapath.send_msg(mod)

    # ─────────────────────────────────────────────────────────────────────
    # CSV Telemetry Writer
    # ─────────────────────────────────────────────────────────────────────
    def _write_telemetry(self, dpid, port_no, stats):
        fieldnames = [
            'timestamp', 'dpid', 'port_no',
            'rx_bytes', 'tx_bytes', 'rx_packets', 'tx_packets',
            'rx_bps', 'tx_bps', 'rx_errors', 'tx_errors', 'anomaly'
        ]
        row = {
            'timestamp' : datetime.datetime.utcnow().isoformat(),
            'dpid'      : f'{dpid:016x}',
            'port_no'   : port_no,
            'rx_bytes'  : stats.get('rx_bytes', 0),
            'tx_bytes'  : stats.get('tx_bytes', 0),
            'rx_packets': stats.get('rx_packets', 0),
            'tx_packets': stats.get('tx_packets', 0),
            'rx_bps'    : round(stats.get('rx_bps', 0), 2),
            'tx_bps'    : round(stats.get('tx_bps', 0), 2),
            'rx_errors' : stats.get('rx_errors', 0),
            'tx_errors' : stats.get('tx_errors', 0),
            'anomaly'   : int(self.anomaly_flags.get(dpid, False))
        }
        with self._csv_lock:
            write_header = not self._csv_header_written
            self._csv_header_written = True
            with open(STATS_CSV_FILE, 'a', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                if write_header:
                    writer.writeheader()
                writer.writerow(row)


# =============================================================================
# REST API
# =============================================================================
class LFARestApi(ControllerBase):
    def __init__(self, req, link, data, **config):
        super().__init__(req, link, data, **config)
        self.controller = data[REST_API_NAME]

    @route('links', '/stats/links', methods=['GET'])
    def get_link_stats(self, req, **kwargs):
        result = {}
        for dpid, ports in self.controller.port_stats.items():
            result[f'{dpid:016x}'] = {
                str(p): {k: v for k, v in s.items() if k != 'timestamp'}
                for p, s in ports.items()
            }
        return Response(content_type='application/json',
                        body=json.dumps(result, default=str))

    @route('flows', '/stats/flows', methods=['GET'])
    def get_flow_stats(self, req, **kwargs):
        result = {f'{dpid:016x}': flows
                  for dpid, flows in self.controller.flow_stats.items()}
        return Response(content_type='application/json',
                        body=json.dumps(result, default=str))

    @route('anomaly', '/stats/anomaly', methods=['GET'])
    def get_anomaly(self, req, **kwargs):
        result = {f'{dpid:016x}': flag
                  for dpid, flag in self.controller.anomaly_flags.items()}
        return Response(content_type='application/json',
                        body=json.dumps(result))
