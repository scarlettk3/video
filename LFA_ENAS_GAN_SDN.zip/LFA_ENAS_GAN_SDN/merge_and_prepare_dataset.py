#!/usr/bin/env python3
"""
CICFlowMeter Dataset Merger & Preprocessor for ENAS+GAN+SDN LFA Detection
==========================================================================
Merges two CICFlowMeter CSV files and prepares them for training.

Requirements:
    pip install pandas numpy scikit-learn
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
import pickle
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("  ENAS+GAN+SDN Dataset Preparation for LFA Detection")
print("="*80)

# ============================================================================
# STEP 1: LOAD CSV FILES
# ============================================================================
print("\n[STEP 1] Loading CSV files...")

try:
    df1 = pd.read_csv('attack3_microflow_100ms.csv', low_memory=False)
    print(f"✓ Loaded attack3_microflow_100ms.csv: {len(df1):,} rows, {len(df1.columns)} columns")
except Exception as e:
    print(f"✗ Error loading attack3_microflow_100ms.csv: {e}")
    df1 = pd.DataFrame()

try:
    df2 = pd.read_csv('final_merged.csv', low_memory=False)
    print(f"✓ Loaded final_merged.csv: {len(df2):,} rows, {len(df2.columns)} columns")
except Exception as e:
    print(f"✗ Error loading final_merged.csv: {e}")
    df2 = pd.DataFrame()

print(f"\nTotal rows before merge: {len(df1) + len(df2):,}")

# ============================================================================
# STEP 2: FEATURE MAPPING & STANDARDIZATION
# ============================================================================
print("\n[STEP 2] Standardizing column names...")

# Define feature mapping for consistent naming
FEATURE_MAPPING = {
    # From attack3_microflow format
    'Flow_Duration': 'Flow Duration',
    'Packet_Count': 'Tot Fwd Pkts',
    'Byte_Count': 'TotLen Fwd Pkts',
    'Packet_Length_Mean': 'Pkt Len Mean',
    'Packet_Length_Std': 'Pkt Len Std',
    'Packet_Length_Min': 'Pkt Len Min',
    'Packet_Length_Max': 'Pkt Len Max',
    'Packets_Per_Second': 'Flow Pkts/s',
    'Bytes_Per_Second': 'Flow Byts/s',
    'TCP_Window_Mean': 'Init Fwd Win Byts',
    'TCP_Window_Max': 'Init Bwd Win Byts',
    
    # Standardize port naming
    'Dst_Port': 'Dst Port',
    'Src_Port': 'Src Port',
    'Destination Port': 'Dst Port',
    'Source Port': 'Src Port',
    
    # Keep standard CICFlowMeter names as-is
    'Tot Fwd Pkts': 'Tot Fwd Pkts',
    'Tot Bwd Pkts': 'Tot Bwd Pkts',
    'TotLen Fwd Pkts': 'TotLen Fwd Pkts',
    'TotLen Bwd Pkts': 'TotLen Bwd Pkts',
}

# Rename columns in df1 if needed
if not df1.empty:
    df1_renamed = df1.rename(columns=FEATURE_MAPPING)
    print(f"  df1 columns after mapping: {len(df1_renamed.columns)}")
else:
    df1_renamed = df1

# Rename columns in df2 if needed  
if not df2.empty:
    df2_renamed = df2.rename(columns=FEATURE_MAPPING)
    print(f"  df2 columns after mapping: {len(df2_renamed.columns)}")
else:
    df2_renamed = df2

# ============================================================================
# STEP 3: SELECT IMPORTANT FEATURES FOR LFA DETECTION
# ============================================================================
print("\n[STEP 3] Selecting features for LFA detection...")

# Features critical for LFA detection
SELECTED_FEATURES = [
    # Flow basic statistics
    'Flow Duration',
    'Tot Fwd Pkts',
    'Tot Bwd Pkts',
    'TotLen Fwd Pkts',
    'TotLen Bwd Pkts',
    
    # Packet length statistics
    'Fwd Pkt Len Max',
    'Fwd Pkt Len Min',
    'Fwd Pkt Len Mean',
    'Fwd Pkt Len Std',
    'Bwd Pkt Len Max',
    'Bwd Pkt Len Min',
    'Bwd Pkt Len Mean',
    'Bwd Pkt Len Std',
    'Pkt Len Min',
    'Pkt Len Max',
    'Pkt Len Mean',
    'Pkt Len Std',
    'Pkt Len Var',
    
    # Flow rates (critical for LFA)
    'Flow Byts/s',
    'Flow Pkts/s',
    'Fwd Pkts/s',
    'Bwd Pkts/s',
    
    # Inter-arrival times (timing patterns)
    'Flow IAT Mean',
    'Flow IAT Std',
    'Flow IAT Max',
    'Flow IAT Min',
    'Fwd IAT Tot',
    'Fwd IAT Mean',
    'Fwd IAT Std',
    'Fwd IAT Max',
    'Fwd IAT Min',
    'Bwd IAT Tot',
    'Bwd IAT Mean',
    'Bwd IAT Std',
    'Bwd IAT Max',
    'Bwd IAT Min',
    
    # TCP flags (protocol behavior)
    'FIN Flag Cnt',
    'SYN Flag Cnt',
    'RST Flag Cnt',
    'PSH Flag Cnt',
    'ACK Flag Cnt',
    'URG Flag Cnt',
    'Fwd PSH Flags',
    'Bwd PSH Flags',
    'Fwd URG Flags',
    'Bwd URG Flags',
    
    # Header lengths
    'Fwd Header Len',
    'Bwd Header Len',
    
    # Communication patterns
    'Down/Up Ratio',
    'Pkt Size Avg',
    'Fwd Seg Size Avg',
    'Bwd Seg Size Avg',
    
    # Subflow features
    'Subflow Fwd Pkts',
    'Subflow Fwd Byts',
    'Subflow Bwd Pkts',
    'Subflow Bwd Byts',
    
    # Window sizes
    'Init Fwd Win Byts',
    'Init Bwd Win Byts',
    
    # Active/Idle times (burstiness)
    'Active Mean',
    'Active Std',
    'Active Max',
    'Active Min',
    'Idle Mean',
    'Idle Std',
    'Idle Max',
    'Idle Min',
    
    # Protocol info
    'Protocol',
    'Dst Port',
]

# Create feature selection function
def select_features(df, selected_cols):
    """Select only available features from dataframe"""
    available = [col for col in selected_cols if col in df.columns]
    missing = [col for col in selected_cols if col not in df.columns]
    
    if missing:
        print(f"  Missing features ({len(missing)}): {', '.join(missing[:5])}...")
    
    # Include Label column if it exists
    if 'Label' in df.columns:
        return df[available + ['Label']].copy()
    else:
        return df[available].copy()

# ============================================================================
# STEP 4: MERGE DATASETS
# ============================================================================
print("\n[STEP 4] Merging datasets...")

# Process df1
if not df1_renamed.empty:
    df1_selected = select_features(df1_renamed, SELECTED_FEATURES)
    print(f"  df1: {len(df1_selected):,} rows, {len(df1_selected.columns)} features selected")
else:
    df1_selected = pd.DataFrame()

# Process df2
if not df2_renamed.empty:
    df2_selected = select_features(df2_renamed, SELECTED_FEATURES)
    print(f"  df2: {len(df2_selected):,} rows, {len(df2_selected.columns)} features selected")
else:
    df2_selected = pd.DataFrame()

# Merge with alignment
if not df1_selected.empty and not df2_selected.empty:
    # Align columns
    all_features = sorted(set(df1_selected.columns) | set(df2_selected.columns))
    
    for col in all_features:
        if col not in df1_selected.columns:
            df1_selected[col] = np.nan
        if col not in df2_selected.columns:
            df2_selected[col] = np.nan
    
    # Reorder columns
    df1_selected = df1_selected[all_features]
    df2_selected = df2_selected[all_features]
    
    # Concatenate
    df_merged = pd.concat([df1_selected, df2_selected], ignore_index=True)
elif not df1_selected.empty:
    df_merged = df1_selected
elif not df2_selected.empty:
    df_merged = df2_selected
else:
    print("✗ Error: No data to merge")
    exit(1)

print(f"\n✓ Merged dataset: {len(df_merged):,} rows, {len(df_merged.columns)} columns")

# ============================================================================
# STEP 5: ASSIGN LABELS
# ============================================================================
print("\n[STEP 5] Assigning traffic labels...")

# Label assignment logic based on existing labels or heuristics
def assign_lfa_label(row):
    """Assign appropriate LFA attack label"""
    existing_label = row.get('Label', 'NORMAL')
    
    if pd.notna(existing_label):
        existing_label = str(existing_label).upper()
        
        # Map existing labels
        if 'ATTACK' in existing_label:
            # Use heuristics to classify attack type based on traffic characteristics
            
            # Flow-Rule Saturation: Very high packet rate
            flow_pkts = row.get('Flow Pkts/s', 0)
            if flow_pkts > 10000:
                return 'Flow-Rule Saturation'
            
            # Topology Poisoning: High SYN count (LLDP injection characteristics)
            syn_count = row.get('SYN Flag Cnt', 0)
            if syn_count > 10:
                return 'Topology Poisoning'
            
            # Telemetry Evasion: High IAT variance (burst timing)
            iat_std = row.get('Flow IAT Std', 0)
            iat_mean = row.get('Flow IAT Mean', 1)
            if iat_std > iat_mean and iat_mean > 0:
                return 'Telemetry Evasion'
            
            # Slice-Aware: Highly asymmetric traffic
            down_up = row.get('Down/Up Ratio', 1)
            if down_up > 5 or (down_up < 0.2 and down_up > 0):
                return 'Slice-Aware'
            
            # Quantum-Inspired LFA: High burst characteristics
            active_mean = row.get('Active Mean', 0)
            idle_mean = row.get('Idle Mean', 1)
            if active_mean > 0 and idle_mean > 0:
                burst_ratio = active_mean / max(idle_mean, 0.001)
                if burst_ratio > 2:
                    return 'Quantum-Inspired LFA'
            
            # Default attack type
            return 'Traditional LFA'
        
        elif 'NORMAL' in existing_label or 'NO LABEL' in existing_label:
            return 'Normal'
        else:
            return 'Normal'
    else:
        return 'Normal'

# Apply labeling
df_merged['Label'] = df_merged.apply(assign_lfa_label, axis=1)

# Print label distribution
print("\nLabel distribution:")
label_counts = df_merged['Label'].value_counts()
for label, count in label_counts.items():
    print(f"  {label:30s}: {count:,} ({100*count/len(df_merged):.2f}%)")

# ============================================================================
# STEP 6: DATA PREPROCESSING
# ============================================================================
print("\n[STEP 6] Preprocessing data...")

# Remove Label column temporarily
labels = df_merged['Label'].copy()
df_features = df_merged.drop('Label', axis=1)

print(f"  Initial shape: {df_features.shape}")

# 6.1: Handle infinite values
print("  → Replacing infinite values...")
df_features.replace([np.inf, -np.inf], np.nan, inplace=True)

# 6.2: Remove constant columns
print("  → Removing constant columns...")
constant_cols = [col for col in df_features.columns if df_features[col].nunique() <= 1]
if constant_cols:
    print(f"    Removing {len(constant_cols)} constant columns")
    df_features.drop(columns=constant_cols, inplace=True)

# 6.3: Handle missing values
print("  → Handling missing values...")
missing_pct = (df_features.isnull().sum() / len(df_features) * 100).sort_values(ascending=False)
high_missing = missing_pct[missing_pct > 50].index.tolist()
if high_missing:
    print(f"    Removing {len(high_missing)} columns with >50% missing")
    df_features.drop(columns=high_missing, inplace=True)

# Fill remaining missing values with median
for col in df_features.select_dtypes(include=[np.number]).columns:
    if df_features[col].isnull().any():
        median_val = df_features[col].median()
        df_features[col].fillna(median_val, inplace=True)

# 6.4: Remove duplicate rows
print("  → Removing duplicate rows...")
initial_rows = len(df_features)
df_features = df_features.drop_duplicates()
labels = labels[df_features.index]
print(f"    Removed {initial_rows - len(df_features):,} duplicates")

# 6.5: Handle outliers (cap at 99th percentile)
print("  → Capping outliers at 99th percentile...")
for col in df_features.select_dtypes(include=[np.number]).columns:
    q99 = df_features[col].quantile(0.99)
    q01 = df_features[col].quantile(0.01)
    df_features[col] = df_features[col].clip(lower=q01, upper=q99)

# 6.6: Normalize features
print("  → Normalizing features using StandardScaler...")
scaler = StandardScaler()
df_normalized = pd.DataFrame(
    scaler.fit_transform(df_features),
    columns=df_features.columns,
    index=df_features.index
)

# Save scaler for later use during inference
with open('scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)
print("    ✓ Scaler saved to: scaler.pkl")

# 6.7: Add labels back
df_final = df_normalized.copy()
df_final['Label'] = labels.values

# Create label encoder for numerical encoding (useful for training)
label_encoder = LabelEncoder()
df_final['Label_Encoded'] = label_encoder.fit_transform(df_final['Label'])

# Save label encoder
with open('label_encoder.pkl', 'wb') as f:
    pickle.dump(label_encoder, f)
print("    ✓ Label encoder saved to: label_encoder.pkl")

print(f"  Final shape: {df_final.shape}")
print(f"  Label classes: {list(label_encoder.classes_)}")

# ============================================================================
# STEP 7: SAVE DATASET
# ============================================================================
print("\n[STEP 7] Saving final dataset...")

output_file = 'ENAS_GAN_SDN_LFA_Dataset.csv'
df_final.to_csv(output_file, index=False)
print(f"✓ Saved to: {output_file}")

# Also save version with only encoded labels (for direct training)
df_final_encoded = df_final.copy()
df_final_encoded = df_final_encoded.drop('Label', axis=1)
df_final_encoded.rename(columns={'Label_Encoded': 'Label'}, inplace=True)
output_file_encoded = 'ENAS_GAN_SDN_LFA_Dataset_Encoded.csv'
df_final_encoded.to_csv(output_file_encoded, index=False)
print(f"✓ Saved encoded version to: {output_file_encoded}")

# ============================================================================
# STEP 8: GENERATE REPORT
# ============================================================================
print("\n" + "="*80)
print("  DATASET PROCESSING REPORT")
print("="*80)

print("\n📊 SAMPLE COUNTS:")
print(f"  Before processing : {len(df1) + len(df2):,} rows")
print(f"  After merge       : {len(df_merged):,} rows")
print(f"  After cleaning    : {len(df_final):,} rows")
print(f"  Removed           : {len(df_merged) - len(df_final):,} rows")

print("\n📊 FEATURE COUNTS:")
print(f"  Initial features  : {len(SELECTED_FEATURES)} (target)")
print(f"  After selection   : {len(df_merged.columns) - 1} (available)")
print(f"  After cleaning    : {len(df_final.columns) - 1} (final)")

print("\n📊 CLASS DISTRIBUTION:")
final_label_counts = df_final['Label'].value_counts()
for label, count in final_label_counts.items():
    label_code = df_final[df_final['Label'] == label]['Label_Encoded'].iloc[0]
    print(f"  {label:30s}: {count:,} ({100*count/len(df_final):.2f}%) [Code: {label_code}]")

print("\n📊 REMOVED FEATURES:")
removed_features = set(SELECTED_FEATURES) - set(df_final.columns)
if removed_features:
    print(f"  Total removed: {len(removed_features)}")
    for feat in sorted(removed_features)[:20]:
        print(f"    - {feat}")
    if len(removed_features) > 20:
        print(f"    ... and {len(removed_features) - 20} more")
else:
    print("  No features removed (all available)")

print("\n📊 FINAL FEATURES:")
print(f"  Total: {len(df_final.columns) - 1} features")
feature_list = [col for col in df_final.columns if col != 'Label']
for i, feat in enumerate(sorted(feature_list), 1):
    print(f"  {i:2d}. {feat}")

print("\n📊 DATA QUALITY:")
print(f"  Missing values    : {df_final.isnull().sum().sum()}")
print(f"  Infinite values   : {np.isinf(df_final.select_dtypes(include=[np.number])).sum().sum()}")
print(f"  Duplicate rows    : {df_final.duplicated().sum()}")

print("\n📊 DATASET STATISTICS:")
print(df_final.describe())

print("\n" + "="*80)
print("  ✓ Dataset ready for ENAS + GAN + SDN training!")
print("="*80)

# Save feature list for reference
with open('selected_features.txt', 'w') as f:
    f.write("Selected Features for ENAS+GAN+SDN LFA Detection\n")
    f.write("="*60 + "\n\n")
    for i, feat in enumerate(sorted(feature_list), 1):
        f.write(f"{i:2d}. {feat}\n")
    f.write(f"\nTotal: {len(feature_list)} features\n")

print("\n✓ Feature list saved to: selected_features.txt")

# Save label mapping
with open('label_mapping.txt', 'w') as f:
    f.write("Label Encoding for ENAS+GAN+SDN LFA Detection\n")
    f.write("="*60 + "\n\n")
    for i, label in enumerate(label_encoder.classes_):
        count = final_label_counts.get(label, 0)
        f.write(f"{i}: {label:30s} ({count:,} samples)\n")
    f.write(f"\nTotal classes: {len(label_encoder.classes_)}\n")

print("✓ Label mapping saved to: label_mapping.txt")

print("\n" + "="*80)
print("  OUTPUT FILES GENERATED:")
print("="*80)
print(f"  1. ENAS_GAN_SDN_LFA_Dataset.csv         - Full dataset with text labels")
print(f"  2. ENAS_GAN_SDN_LFA_Dataset_Encoded.csv - Dataset with numeric labels")
print(f"  3. scaler.pkl                            - StandardScaler object")
print(f"  4. label_encoder.pkl                     - LabelEncoder object")
print(f"  5. selected_features.txt                 - List of features")
print(f"  6. label_mapping.txt                     - Label encoding map")

print("\n" + "="*80)
print("  USAGE FOR TRAINING:")
print("="*80)
print("""
# Load the dataset
import pandas as pd
import pickle

# Option 1: With text labels
df = pd.read_csv('ENAS_GAN_SDN_LFA_Dataset.csv')
X = df.drop(['Label', 'Label_Encoded'], axis=1)
y = df['Label_Encoded']

# Option 2: Pre-encoded
df = pd.read_csv('ENAS_GAN_SDN_LFA_Dataset_Encoded.csv')
X = df.drop('Label', axis=1)
y = df['Label']

# Load preprocessing objects
with open('scaler.pkl', 'rb') as f:
    scaler = pickle.load(f)

with open('label_encoder.pkl', 'rb') as f:
    label_encoder = pickle.load(f)

# For inference on new data:
# X_new_scaled = scaler.transform(X_new)
# predictions = label_encoder.inverse_transform(y_pred)
""")
