#!/usr/bin/env python3
"""
=============================================================================
LFA-ENAS-GAN-SDN: Flow Feature Extraction from PCAP Files
=============================================================================
Extracts the 20 key network flow features used for ML-based LFA detection.

Features extracted per bidirectional flow:
  1.  flow_duration         - Total duration of the flow (seconds)
  2.  fwd_packet_count      - Number of forward packets
  3.  bwd_packet_count      - Number of backward packets
  4.  total_packet_count    - Total packets
  5.  fwd_byte_count        - Total bytes in forward direction
  6.  bwd_byte_count        - Total bytes in backward direction
  7.  fwd_packet_len_mean   - Mean forward packet length
  8.  fwd_packet_len_std    - Std dev of forward packet lengths
  9.  bwd_packet_len_mean   - Mean backward packet length
  10. fwd_iat_mean          - Mean inter-arrival time (forward)
  11. fwd_iat_std           - Std dev of IAT (forward)
  12. flow_bytes_per_sec    - Total bytes / duration
  13. flow_pkts_per_sec     - Total packets / duration
  14. src_entropy           - Shannon entropy of source IPs
  15. dst_entropy           - Shannon entropy of destination IPs
  16. port_entropy          - Shannon entropy of destination ports
  17. tcp_flag_ratio        - Ratio of SYN/RST flags to total packets
  18. unique_src_count      - Number of unique source IPs
  19. unique_dst_count      - Number of unique destination IPs
  20. bandwidth_utilization - Estimated link bandwidth utilization

Usage:
    python3 extract_features.py --pcap <file.pcap> --label <label> --output <dir>
    python3 extract_features.py --pcap ../datasets/pcap/ --label auto --output ../datasets/features/
=============================================================================
"""

import os
import sys
import csv
import math
import glob
import argparse
import logging
from collections import defaultdict, Counter
from typing import List, Dict, Optional, Tuple
import struct
import socket

# Try dpkt first (fast), fall back to scapy
try:
    import dpkt
    DPKT_AVAILABLE = True
except ImportError:
    DPKT_AVAILABLE = False

try:
    from scapy.all import rdpcap, IP, TCP, UDP, ICMP
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False

import numpy as np
import pandas as pd

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [FEATURE] %(message)s'
)
LOG = logging.getLogger('FeatureExtractor')

# Flow identifier: (src_ip, dst_ip, src_port, dst_port, proto)
FlowKey = Tuple[str, str, int, int, str]

# Link capacity for utilization calculation (10 Mbps bottleneck)
LINK_CAPACITY_BPS = 10e6

# Label mapping
LABEL_MAP = {
    'normal'           : 0,
    'traditional_lfa'  : 1,
    'topology_poisoning': 2,
    'telemetry_evasion': 3,
    'slice_aware'      : 4,
    'flow_saturation'  : 5,
    'quantum_lfa'      : 6,
}


def shannon_entropy(values: List) -> float:
    """Calculate Shannon entropy of a list of values."""
    if not values:
        return 0.0
    counter = Counter(values)
    total   = len(values)
    entropy = 0.0
    for count in counter.values():
        p = count / total
        if p > 0:
            entropy -= p * math.log2(p)
    return entropy


class FlowRecord:
    """Accumulates per-flow packet statistics."""

    def __init__(self, key: FlowKey):
        self.key = key
        self.fwd_packets   : List[Tuple[float, int]] = []  # (timestamp, size)
        self.bwd_packets   : List[Tuple[float, int]] = []
        self.tcp_flags     : List[int] = []
        self.first_seen    : Optional[float] = None
        self.last_seen     : Optional[float] = None

    def add_packet(self, timestamp: float, size: int, is_forward: bool,
                   tcp_flags: int = 0):
        if self.first_seen is None:
            self.first_seen = timestamp
        self.last_seen = timestamp

        if is_forward:
            self.fwd_packets.append((timestamp, size))
        else:
            self.bwd_packets.append((timestamp, size))

        if tcp_flags:
            self.tcp_flags.append(tcp_flags)

    @property
    def duration(self) -> float:
        if self.first_seen and self.last_seen:
            return max(1e-6, self.last_seen - self.first_seen)
        return 1e-6

    @property
    def fwd_sizes(self) -> List[int]:
        return [s for _, s in self.fwd_packets]

    @property
    def bwd_sizes(self) -> List[int]:
        return [s for _, s in self.bwd_packets]

    @property
    def fwd_timestamps(self) -> List[float]:
        return [t for t, _ in self.fwd_packets]

    def compute_iat(self, timestamps: List[float]) -> List[float]:
        """Compute inter-arrival times."""
        if len(timestamps) < 2:
            return [0.0]
        return [timestamps[i+1] - timestamps[i] for i in range(len(timestamps)-1)]

    def to_feature_dict(self) -> Dict:
        """Compute all 20 features for this flow."""
        fwd_sizes = self.fwd_sizes
        bwd_sizes = self.bwd_sizes
        all_sizes = fwd_sizes + bwd_sizes
        fwd_iats  = self.compute_iat(self.fwd_timestamps)

        total_bytes = sum(all_sizes)
        total_pkts  = len(self.fwd_packets) + len(self.bwd_packets)

        # TCP flag analysis
        syn_count = sum(1 for f in self.tcp_flags if f & 0x02)   # SYN
        rst_count = sum(1 for f in self.tcp_flags if f & 0x04)   # RST
        flag_ratio = (syn_count + rst_count) / max(1, len(self.tcp_flags))

        src_ip, dst_ip, src_port, dst_port, proto = self.key

        return {
            'flow_duration'         : round(self.duration, 6),
            'fwd_packet_count'      : len(self.fwd_packets),
            'bwd_packet_count'      : len(self.bwd_packets),
            'total_packet_count'    : total_pkts,
            'fwd_byte_count'        : sum(fwd_sizes),
            'bwd_byte_count'        : sum(bwd_sizes),
            'fwd_packet_len_mean'   : round(np.mean(fwd_sizes) if fwd_sizes else 0, 2),
            'fwd_packet_len_std'    : round(np.std(fwd_sizes) if fwd_sizes else 0, 2),
            'bwd_packet_len_mean'   : round(np.mean(bwd_sizes) if bwd_sizes else 0, 2),
            'fwd_iat_mean'          : round(np.mean(fwd_iats), 6),
            'fwd_iat_std'           : round(np.std(fwd_iats), 6),
            'flow_bytes_per_sec'    : round(total_bytes / self.duration, 2),
            'flow_pkts_per_sec'     : round(total_pkts / self.duration, 2),
            'tcp_flag_ratio'        : round(flag_ratio, 4),
            'src_ip'                : src_ip,
            'dst_ip'                : dst_ip,
            'src_port'              : src_port,
            'dst_port'              : dst_port,
            'protocol'              : proto,
        }


class PCAPFeatureExtractor:
    """
    Reads a PCAP file and extracts per-flow features.
    Supports both dpkt (faster) and Scapy (fallback).
    """

    def __init__(self, pcap_file: str, label: str):
        self.pcap_file = pcap_file
        self.label     = label
        self.flows     : Dict[FlowKey, FlowRecord] = {}
        self.all_src_ips  : List[str] = []
        self.all_dst_ips  : List[str] = []
        self.all_dst_ports: List[int] = []

    def _flow_key(self, src_ip, dst_ip, src_port, dst_port, proto) -> FlowKey:
        """Normalize flow key (bidirectional: always sort by IP)."""
        if src_ip <= dst_ip:
            return (src_ip, dst_ip, src_port, dst_port, proto)
        else:
            return (dst_ip, src_ip, dst_port, src_port, proto)

    def _is_forward(self, src_ip, dst_ip, key: FlowKey) -> bool:
        return key[0] == src_ip

    def parse_dpkt(self):
        """Parse PCAP using dpkt library (faster for large files)."""
        LOG.info('Parsing with dpkt: %s', self.pcap_file)
        with open(self.pcap_file, 'rb') as f:
            try:
                pcap = dpkt.pcap.Reader(f)
                for ts, buf in pcap:
                    try:
                        eth = dpkt.ethernet.Ethernet(buf)
                        if not isinstance(eth.data, dpkt.ip.IP):
                            continue
                        ip = eth.data
                        src_ip = socket.inet_ntoa(ip.src)
                        dst_ip = socket.inet_ntoa(ip.dst)

                        self.all_src_ips.append(src_ip)
                        self.all_dst_ips.append(dst_ip)

                        if isinstance(ip.data, dpkt.tcp.TCP):
                            tcp   = ip.data
                            key   = self._flow_key(src_ip, dst_ip,
                                                   tcp.sport, tcp.dport, 'TCP')
                            flags = tcp.flags
                            self.all_dst_ports.append(tcp.dport)
                        elif isinstance(ip.data, dpkt.udp.UDP):
                            udp   = ip.data
                            key   = self._flow_key(src_ip, dst_ip,
                                                   udp.sport, udp.dport, 'UDP')
                            flags = 0
                            self.all_dst_ports.append(udp.dport)
                        elif isinstance(ip.data, dpkt.icmp.ICMP):
                            key   = self._flow_key(src_ip, dst_ip, 0, 0, 'ICMP')
                            flags = 0
                        else:
                            continue

                        if key not in self.flows:
                            self.flows[key] = FlowRecord(key)

                        is_fwd = self._is_forward(src_ip, dst_ip, key)
                        self.flows[key].add_packet(ts, len(buf), is_fwd, flags)

                    except Exception:
                        continue
            except Exception as e:
                LOG.error('dpkt parse error: %s', e)

    def parse_scapy(self):
        """Parse PCAP using Scapy (fallback, slower)."""
        LOG.info('Parsing with Scapy: %s', self.pcap_file)
        try:
            packets = rdpcap(self.pcap_file)
        except Exception as e:
            LOG.error('Scapy read error: %s', e)
            return

        for pkt in packets:
            try:
                if not pkt.haslayer(IP):
                    continue
                ip = pkt[IP]
                ts = float(pkt.time)
                pkt_size = len(pkt)

                src_ip = ip.src
                dst_ip = ip.dst
                self.all_src_ips.append(src_ip)
                self.all_dst_ips.append(dst_ip)

                if pkt.haslayer(TCP):
                    l4     = pkt[TCP]
                    key    = self._flow_key(src_ip, dst_ip,
                                            l4.sport, l4.dport, 'TCP')
                    flags  = int(l4.flags)
                    self.all_dst_ports.append(l4.dport)
                elif pkt.haslayer(UDP):
                    l4     = pkt[UDP]
                    key    = self._flow_key(src_ip, dst_ip,
                                            l4.sport, l4.dport, 'UDP')
                    flags  = 0
                    self.all_dst_ports.append(l4.dport)
                elif pkt.haslayer(ICMP):
                    key    = self._flow_key(src_ip, dst_ip, 0, 0, 'ICMP')
                    flags  = 0
                else:
                    continue

                if key not in self.flows:
                    self.flows[key] = FlowRecord(key)

                is_fwd = self._is_forward(src_ip, dst_ip, key)
                self.flows[key].add_packet(ts, pkt_size, is_fwd, flags)
            except Exception:
                continue

    def extract(self) -> pd.DataFrame:
        """Extract features from PCAP and return as DataFrame."""
        if not os.path.isfile(self.pcap_file):
            LOG.error('File not found: %s', self.pcap_file)
            return pd.DataFrame()

        if DPKT_AVAILABLE:
            self.parse_dpkt()
        elif SCAPY_AVAILABLE:
            self.parse_scapy()
        else:
            LOG.error('Neither dpkt nor Scapy is available. Install one.')
            return pd.DataFrame()

        LOG.info('Parsed %d flows from %s', len(self.flows), self.pcap_file)

        if not self.flows:
            LOG.warning('No flows extracted.')
            return pd.DataFrame()

        records = []
        for flow in self.flows.values():
            feat = flow.to_feature_dict()
            feat['label']      = LABEL_MAP.get(self.label, -1)
            feat['label_name'] = self.label
            records.append(feat)

        df = pd.DataFrame(records)

        # Add aggregate features across all flows in this capture
        if self.all_src_ips:
            df['src_entropy']     = shannon_entropy(self.all_src_ips)
            df['dst_entropy']     = shannon_entropy(self.all_dst_ips)
            df['port_entropy']    = shannon_entropy(self.all_dst_ports)
            df['unique_src_count']= len(set(self.all_src_ips))
            df['unique_dst_count']= len(set(self.all_dst_ips))

            total_bps = df['flow_bytes_per_sec'].sum() * 8
            df['bandwidth_utilization'] = min(1.0, total_bps / LINK_CAPACITY_BPS)
        else:
            df['src_entropy'] = df['dst_entropy'] = df['port_entropy'] = 0.0
            df['unique_src_count'] = df['unique_dst_count'] = 0
            df['bandwidth_utilization'] = 0.0

        LOG.info('Feature extraction complete: %d flow records, %d features',
                 len(df), len(df.columns))
        return df


def extract_from_directory(pcap_dir: str, output_dir: str) -> pd.DataFrame:
    """
    Extract features from all PCAP files in a directory.
    Filename must contain label keyword for auto-labeling.
    """
    all_dfs = []
    pcap_files = glob.glob(os.path.join(pcap_dir, '**/*.pcap'), recursive=True)
    pcap_files += glob.glob(os.path.join(pcap_dir, '*.pcap'))
    pcap_files = list(set(pcap_files))

    LOG.info('Found %d PCAP files in %s', len(pcap_files), pcap_dir)

    for pcap_file in pcap_files:
        # Auto-detect label from filename
        fname = os.path.basename(pcap_file).lower()
        label = 'normal'
        for lbl in LABEL_MAP.keys():
            if lbl.replace('_', '') in fname.replace('_', '').replace('-', ''):
                label = lbl
                break

        LOG.info('Processing: %s → label=%s', fname, label)
        extractor = PCAPFeatureExtractor(pcap_file, label)
        df = extractor.extract()
        if not df.empty:
            all_dfs.append(df)

    if not all_dfs:
        LOG.warning('No features extracted.')
        return pd.DataFrame()

    combined = pd.concat(all_dfs, ignore_index=True)
    out_file  = os.path.join(output_dir, 'combined_features.csv')
    combined.to_csv(out_file, index=False)
    LOG.info('Combined dataset: %d flows → %s', len(combined), out_file)
    LOG.info('Class distribution:\n%s', combined['label_name'].value_counts())
    return combined


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='PCAP Feature Extractor')
    parser.add_argument('--pcap',   required=True,
                        help='PCAP file or directory of PCAP files')
    parser.add_argument('--label',  default='normal',
                        help='Traffic label (or "auto" for directory mode)')
    parser.add_argument('--output', default='../datasets/features',
                        help='Output directory for feature CSV')
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)

    if os.path.isdir(args.pcap):
        df = extract_from_directory(args.pcap, args.output)
    else:
        extractor = PCAPFeatureExtractor(args.pcap, args.label)
        df = extractor.extract()
        if not df.empty:
            out_file = os.path.join(
                args.output,
                f'{args.label}_features.csv'
            )
            df.to_csv(out_file, index=False)
            LOG.info('Saved: %s (%d rows)', out_file, len(df))

    if not df.empty:
        print('\nFeature summary:')
        print(df.describe())
        print(f'\nLabel distribution:\n{df["label_name"].value_counts()}')
