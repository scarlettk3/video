#!/usr/bin/env python3
"""
=============================================================================
LFA-ENAS-GAN-SDN: Dataset Builder
=============================================================================
Assembles, cleans, and balances the final ML dataset from extracted features.
Also generates synthetic samples using GAN output (Phase 2 integration).

Steps:
  1. Load all feature CSVs from the features directory
  2. Clean: handle missing values, remove duplicates
  3. Normalize: MinMax scaling on numerical features
  4. Balance: SMOTE oversampling for minority attack classes
  5. Split: 70% train / 15% val / 15% test (stratified)
  6. Export: train.csv, val.csv, test.csv, full_dataset.csv

Usage:
    python3 dataset_builder.py [--features-dir ../datasets/features] [--balance]
=============================================================================
"""

import os
import logging
import argparse
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.utils import shuffle

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [DATASET] %(message)s'
)
LOG = logging.getLogger('DatasetBuilder')

# Feature columns used for ML (numeric only)
NUMERIC_FEATURES = [
    'flow_duration', 'fwd_packet_count', 'bwd_packet_count',
    'total_packet_count', 'fwd_byte_count', 'bwd_byte_count',
    'fwd_packet_len_mean', 'fwd_packet_len_std', 'bwd_packet_len_mean',
    'fwd_iat_mean', 'fwd_iat_std', 'flow_bytes_per_sec',
    'flow_pkts_per_sec', 'tcp_flag_ratio', 'src_entropy',
    'dst_entropy', 'port_entropy', 'unique_src_count',
    'unique_dst_count', 'bandwidth_utilization'
]

CATEGORICAL_FEATURES = ['protocol']
TARGET_COLUMN = 'label'
TARGET_NAME_COLUMN = 'label_name'


def load_features(features_dir: str) -> pd.DataFrame:
    """Load all CSV feature files from directory."""
    import glob
    csv_files = glob.glob(os.path.join(features_dir, '**/*.csv'), recursive=True)
    csv_files += glob.glob(os.path.join(features_dir, '*.csv'))
    csv_files = list(set(csv_files))

    LOG.info('Found %d CSV files in %s', len(csv_files), features_dir)
    if not csv_files:
        LOG.warning('No CSV files found. Generating synthetic demo dataset.')
        return _generate_demo_dataset()

    dfs = []
    for f in csv_files:
        try:
            df = pd.read_csv(f)
            dfs.append(df)
            LOG.info('  Loaded: %s (%d rows)', os.path.basename(f), len(df))
        except Exception as e:
            LOG.error('  Failed to load %s: %s', f, e)

    if not dfs:
        return _generate_demo_dataset()

    combined = pd.concat(dfs, ignore_index=True)
    LOG.info('Total rows loaded: %d', len(combined))
    return combined


def _generate_demo_dataset(n_samples: int = 10000) -> pd.DataFrame:
    """
    Generate a synthetic demonstration dataset for testing the ML pipeline.
    Creates realistic feature distributions for each attack class.
    """
    LOG.info('Generating synthetic demo dataset (%d samples)...', n_samples)
    np.random.seed(42)

    records = []

    # Class distributions (approximate real-world imbalance)
    class_counts = {
        'normal'           : int(n_samples * 0.40),   # 40%
        'traditional_lfa'  : int(n_samples * 0.15),   # 15%
        'topology_poisoning': int(n_samples * 0.12),  # 12%
        'telemetry_evasion': int(n_samples * 0.12),   # 12%
        'slice_aware'      : int(n_samples * 0.10),   # 10%
        'flow_saturation'  : int(n_samples * 0.06),   # 6%
        'quantum_lfa'      : int(n_samples * 0.05),   # 5%
    }

    label_map = {
        'normal': 0, 'traditional_lfa': 1, 'topology_poisoning': 2,
        'telemetry_evasion': 3, 'slice_aware': 4,
        'flow_saturation': 5, 'quantum_lfa': 6
    }

    # Feature distributions per class (mean, std for each feature)
    # Order: flow_dur, fwd_pkts, bwd_pkts, total_pkts, fwd_bytes, bwd_bytes,
    #        fwd_len_mean, fwd_len_std, bwd_len_mean, fwd_iat_mean, fwd_iat_std,
    #        bytes_s, pkts_s, tcp_flag, src_ent, dst_ent, port_ent,
    #        unique_src, unique_dst, bw_util
    distributions = {
        'normal': {
            'means': [10.0, 50, 30, 80, 50000, 30000, 800, 200, 700,
                      0.2, 0.1, 5000, 8, 0.05, 2.0, 1.5, 3.0, 5, 3, 0.3],
            'stds' : [5.0, 20, 15, 30, 20000, 15000, 200, 100, 200,
                      0.1, 0.05, 2000, 4, 0.02, 0.5, 0.5, 0.8, 2, 1, 0.1]
        },
        'traditional_lfa': {
            'means': [120.0, 1000, 5, 1005, 512000, 5000, 512, 50, 500,
                      0.002, 0.001, 50000, 1000, 0.9, 0.5, 0.2, 1.0, 20, 3, 0.85],
            'stds' : [30.0, 200, 3, 200, 100000, 2000, 100, 20, 200,
                      0.001, 0.0005, 10000, 200, 0.05, 0.2, 0.1, 0.3, 5, 1, 0.1]
        },
        'topology_poisoning': {
            'means': [5.0, 20, 2, 22, 2000, 200, 100, 500, 100,
                      0.5, 2.0, 1000, 5, 0.8, 3.5, 0.1, 0.5, 15, 2, 0.4],
            'stds' : [2.0, 10, 2, 10, 1000, 100, 50, 300, 50,
                      0.3, 1.0, 500, 3, 0.1, 0.5, 0.05, 0.2, 5, 1, 0.1]
        },
        'telemetry_evasion': {
            'means': [2.0, 500, 2, 502, 250000, 1000, 500, 400, 300,
                      0.004, 0.003, 125000, 250, 0.3, 1.0, 0.3, 1.5, 8, 2, 0.7],
            'stds' : [1.0, 200, 1, 200, 100000, 500, 200, 200, 150,
                      0.002, 0.001, 50000, 100, 0.1, 0.5, 0.2, 0.5, 3, 1, 0.15]
        },
        'slice_aware': {
            'means': [30.0, 300, 50, 350, 150000, 20000, 160, 20, 200,
                      0.003, 0.001, 5000, 12, 0.1, 0.8, 0.5, 2.0, 4, 4, 0.65],
            'stds' : [10.0, 100, 20, 110, 50000, 10000, 40, 10, 100,
                      0.001, 0.0005, 2000, 5, 0.05, 0.3, 0.2, 0.5, 2, 2, 0.1]
        },
        'flow_saturation': {
            'means': [0.1, 2, 0, 2, 200, 0, 100, 30, 0,
                      0.05, 0.02, 2000, 20, 0.95, 4.0, 4.0, 5.0, 1000, 500, 0.5],
            'stds' : [0.05, 1, 0, 1, 100, 0, 50, 20, 0,
                      0.02, 0.01, 1000, 10, 0.03, 0.5, 0.5, 0.5, 200, 100, 0.1]
        },
        'quantum_lfa': {
            'means': [2.0, 200, 1, 201, 100000, 100, 500, 400, 100,
                      0.005, 0.005, 50000, 100, 0.4, 3.5, 3.5, 4.5, 50, 20, 0.75],
            'stds' : [1.0, 80, 1, 80, 40000, 50, 200, 200, 50,
                      0.003, 0.003, 20000, 40, 0.15, 0.5, 0.5, 0.5, 15, 8, 0.12]
        }
    }

    for class_name, count in class_counts.items():
        dist = distributions[class_name]
        data = np.random.normal(
            loc=dist['means'],
            scale=dist['stds'],
            size=(count, len(NUMERIC_FEATURES))
        )
        # Clip to non-negative
        data = np.abs(data)

        for i in range(count):
            row = dict(zip(NUMERIC_FEATURES, data[i].tolist()))
            row['protocol']    = np.random.choice(['TCP', 'UDP', 'ICMP'],
                                                  p=[0.6, 0.35, 0.05])
            row['label']       = label_map[class_name]
            row['label_name']  = class_name
            row['src_ip']      = f'10.{np.random.randint(0,4)}.{np.random.randint(0,4)}.{np.random.randint(2,254)}'
            row['dst_ip']      = f'10.{np.random.randint(0,4)}.{np.random.randint(0,4)}.{np.random.randint(2,254)}'
            row['src_port']    = int(np.random.randint(1024, 65535))
            row['dst_port']    = int(np.random.choice([80, 443, 22, 8080, 5201, 5002]))
            records.append(row)

    df = pd.DataFrame(records)
    LOG.info('Demo dataset generated: %d rows', len(df))
    LOG.info('Class distribution:\n%s', df['label_name'].value_counts())
    return df


def clean_dataset(df: pd.DataFrame) -> pd.DataFrame:
    """Remove NaN, duplicates, and invalid rows."""
    original_size = len(df)
    df = df.dropna(subset=NUMERIC_FEATURES + [TARGET_COLUMN])
    df = df.drop_duplicates()
    # Remove rows with negative durations
    df = df[df['flow_duration'] >= 0]
    LOG.info('Cleaned: %d → %d rows (removed %d)',
             original_size, len(df), original_size - len(df))
    return df


def normalize_features(df: pd.DataFrame, scaler: MinMaxScaler = None) -> (pd.DataFrame, MinMaxScaler):
    """Apply MinMax normalization to numeric features."""
    if scaler is None:
        scaler = MinMaxScaler(feature_range=(0, 1))
        df[NUMERIC_FEATURES] = scaler.fit_transform(df[NUMERIC_FEATURES].fillna(0))
    else:
        df[NUMERIC_FEATURES] = scaler.transform(df[NUMERIC_FEATURES].fillna(0))
    return df, scaler


def encode_protocol(df: pd.DataFrame) -> pd.DataFrame:
    """One-hot encode protocol column."""
    protocol_dummies = pd.get_dummies(df['protocol'], prefix='proto')
    df = pd.concat([df, protocol_dummies], axis=1)
    return df


def balance_dataset(df: pd.DataFrame) -> pd.DataFrame:
    """
    Balance class distribution using SMOTE (Synthetic Minority Oversampling).
    Falls back to random oversampling if imbalanced-learn not available.
    """
    try:
        from imblearn.over_sampling import SMOTE
        X = df[NUMERIC_FEATURES].values
        y = df[TARGET_COLUMN].values

        smote = SMOTE(random_state=42, k_neighbors=5)
        X_res, y_res = smote.fit_resample(X, y)

        # Rebuild dataframe
        df_balanced = pd.DataFrame(X_res, columns=NUMERIC_FEATURES)
        df_balanced[TARGET_COLUMN] = y_res

        # Re-add label names
        label_map_inv = {v: k for k, v in {
            'normal': 0, 'traditional_lfa': 1, 'topology_poisoning': 2,
            'telemetry_evasion': 3, 'slice_aware': 4,
            'flow_saturation': 5, 'quantum_lfa': 6
        }.items()}
        df_balanced[TARGET_NAME_COLUMN] = df_balanced[TARGET_COLUMN].map(label_map_inv)

        LOG.info('SMOTE balanced: %d → %d rows', len(df), len(df_balanced))
        LOG.info('Balanced distribution:\n%s',
                 df_balanced[TARGET_NAME_COLUMN].value_counts())
        return df_balanced

    except ImportError:
        LOG.warning('imbalanced-learn not available. Using random oversampling.')
        return _random_oversample(df)


def _random_oversample(df: pd.DataFrame) -> pd.DataFrame:
    """Simple random oversampling to majority class size."""
    max_count = df[TARGET_COLUMN].value_counts().max()
    parts = []
    for label in df[TARGET_COLUMN].unique():
        subset = df[df[TARGET_COLUMN] == label]
        if len(subset) < max_count:
            subset = subset.sample(n=max_count, replace=True, random_state=42)
        parts.append(subset)
    return shuffle(pd.concat(parts), random_state=42)


def split_dataset(df: pd.DataFrame, train=0.70, val=0.15, test=0.15):
    """Stratified train/val/test split."""
    X = df.drop(columns=[TARGET_COLUMN, TARGET_NAME_COLUMN], errors='ignore')
    y = df[TARGET_COLUMN]

    X_train, X_temp, y_train, y_temp = train_test_split(
        X, y, test_size=(val + test), stratify=y, random_state=42)
    X_val, X_test, y_val, y_test = train_test_split(
        X_temp, y_temp, test_size=test / (val + test),
        stratify=y_temp, random_state=42)

    train_df = X_train.copy(); train_df[TARGET_COLUMN] = y_train.values
    val_df   = X_val.copy();   val_df[TARGET_COLUMN]   = y_val.values
    test_df  = X_test.copy();  test_df[TARGET_COLUMN]  = y_test.values

    LOG.info('Split: train=%d  val=%d  test=%d', len(train_df), len(val_df), len(test_df))
    return train_df, val_df, test_df


def build_dataset(features_dir: str, output_dir: str, do_balance: bool = True):
    """Full pipeline: load → clean → normalize → balance → split → save."""
    os.makedirs(output_dir, exist_ok=True)

    # Load
    df = load_features(features_dir)
    LOG.info('Loaded dataset: %d rows, %d columns', len(df), len(df.columns))

    # Clean
    df = clean_dataset(df)

    # Normalize
    df, scaler = normalize_features(df)

    # Encode protocol
    df = encode_protocol(df)

    # Save full dataset before balancing
    full_out = os.path.join(output_dir, 'full_dataset.csv')
    df.to_csv(full_out, index=False)
    LOG.info('Full dataset saved: %s', full_out)

    # Balance
    if do_balance:
        df_balanced = balance_dataset(df)
    else:
        df_balanced = df

    # Split
    train_df, val_df, test_df = split_dataset(df_balanced)

    # Save splits
    for name, split_df in [('train', train_df), ('val', val_df), ('test', test_df)]:
        out = os.path.join(output_dir, f'{name}.csv')
        split_df.to_csv(out, index=False)
        LOG.info('Saved: %s (%d rows)', out, len(split_df))

    # Save scaler for inference time
    import joblib
    scaler_path = os.path.join(output_dir, 'scaler.pkl')
    joblib.dump(scaler, scaler_path)
    LOG.info('Scaler saved: %s', scaler_path)

    LOG.info('Dataset build complete.')
    return train_df, val_df, test_df, scaler


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='LFA Dataset Builder')
    parser.add_argument('--features-dir', default='../datasets/features',
                        help='Directory with feature CSV files')
    parser.add_argument('--output-dir',   default='../datasets',
                        help='Output directory for train/val/test splits')
    parser.add_argument('--no-balance',   action='store_true',
                        help='Skip SMOTE balancing')
    parser.add_argument('--demo',         action='store_true',
                        help='Generate and use synthetic demo data')
    args = parser.parse_args()

    if args.demo:
        demo_dir = os.path.join(args.features_dir, 'demo')
        os.makedirs(demo_dir, exist_ok=True)
        demo_df = _generate_demo_dataset(10000)
        demo_df.to_csv(os.path.join(demo_dir, 'demo_features.csv'), index=False)

    build_dataset(
        features_dir=args.features_dir,
        output_dir=args.output_dir,
        do_balance=not args.no_balance
    )
