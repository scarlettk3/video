#!/bin/bash
# =============================================================================
# LFA-ENAS-GAN-SDN: Packet Capture & Feature Extraction Commands
# Run on Ubuntu with Mininet active
# =============================================================================

PCAP_DIR="../datasets/pcap"
FEATURE_DIR="../datasets/features"
DURATION=${1:-60}   # Capture duration in seconds (default: 60)
INTERFACE=${2:-any} # Interface to capture on (default: any)
LABEL=${3:-normal}  # Traffic label: normal, traditional_lfa, topo_poison, etc.

mkdir -p "$PCAP_DIR" "$FEATURE_DIR"

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
PCAP_FILE="$PCAP_DIR/${LABEL}_${TIMESTAMP}.pcap"

echo "============================================================"
echo "  Packet Capture & Feature Extraction"
echo "  Interface : $INTERFACE"
echo "  Duration  : ${DURATION}s"
echo "  Label     : $LABEL"
echo "  Output    : $PCAP_FILE"
echo "============================================================"

# ── Step 1: Start tcpdump capture ──────────────────────────────────────────
echo "[1] Starting tcpdump..."
echo "  Command: sudo tcpdump -i $INTERFACE -w $PCAP_FILE -G $DURATION -W 1"

sudo tcpdump \
    -i "$INTERFACE" \
    -w "$PCAP_FILE" \
    -G "$DURATION" \
    -W 1 \
    -s 0 \
    -n \
    'not port 6633 and not port 6634' &   # exclude OpenFlow control traffic

TCPDUMP_PID=$!
echo "  tcpdump PID: $TCPDUMP_PID"
echo "  Capturing for ${DURATION}s..."
sleep "$DURATION"

# Wait for tcpdump to flush and close
wait $TCPDUMP_PID 2>/dev/null || kill $TCPDUMP_PID 2>/dev/null
sleep 1

if [ ! -f "$PCAP_FILE" ]; then
    echo "WARNING: PCAP file not created. Checking with timeout..."
    PCAP_FILE=$(ls -t "$PCAP_DIR"/*.pcap 2>/dev/null | head -1)
fi

echo "  Capture complete: $PCAP_FILE"
echo "  File size: $(du -sh "$PCAP_FILE" 2>/dev/null | cut -f1)"

# ── Step 2: Basic stats with tcpdump ───────────────────────────────────────
echo ""
echo "[2] Basic PCAP statistics:"
echo "  Command: tcpdump -r $PCAP_FILE -nn | head -20"
echo ""
sudo tcpdump -r "$PCAP_FILE" -nn 2>/dev/null | head -20
echo ""
echo "  Total packets:"
sudo tcpdump -r "$PCAP_FILE" -nn 2>/dev/null | wc -l

# ── Step 3: Protocol distribution ──────────────────────────────────────────
echo ""
echo "[3] Protocol distribution:"
echo "  Command: tshark -r $PCAP_FILE -q -z io,phs"
echo ""
tshark -r "$PCAP_FILE" -q -z io,phs 2>/dev/null | head -30

# ── Step 4: Flow statistics with tshark ────────────────────────────────────
echo ""
echo "[4] Flow conversations (top 20 by bytes):"
echo "  Command: tshark -r $PCAP_FILE -q -z conv,ip"
echo ""
tshark -r "$PCAP_FILE" -q -z conv,ip 2>/dev/null | head -25

# ── Step 5: Export features with tshark ────────────────────────────────────
echo ""
echo "[5] Exporting flow features to CSV..."
FEATURES_CSV="$FEATURE_DIR/${LABEL}_${TIMESTAMP}_features.csv"

tshark -r "$PCAP_FILE" \
    -T fields \
    -E header=y \
    -E separator=, \
    -E quote=d \
    -E occurrence=f \
    -e frame.time_relative \
    -e ip.src \
    -e ip.dst \
    -e ip.proto \
    -e tcp.srcport \
    -e tcp.dstport \
    -e udp.srcport \
    -e udp.dstport \
    -e frame.len \
    -e ip.len \
    -e tcp.flags \
    -e ip.ttl \
    -e tcp.window_size \
    > "$FEATURES_CSV" 2>/dev/null

echo "  Raw features exported: $FEATURES_CSV"
echo "  Rows: $(wc -l < "$FEATURES_CSV") (including header)"

# ── Step 6: Entropy analysis ───────────────────────────────────────────────
echo ""
echo "[6] Source IP entropy (diversity indicator):"
tshark -r "$PCAP_FILE" -T fields -e ip.src 2>/dev/null \
    | sort | uniq -c | sort -rn | head -10

echo ""
echo "[7] Destination port distribution:"
tshark -r "$PCAP_FILE" -T fields -e tcp.dstport -e udp.dstport 2>/dev/null \
    | sort | uniq -c | sort -rn | head -10

# ── Step 7: Extract OVS flow stats ─────────────────────────────────────────
echo ""
echo "[8] OVS flow table snapshot:"
echo "  Command: sudo ovs-ofctl dump-flows s1 -O OpenFlow13"
sudo ovs-ofctl dump-flows s1 -O OpenFlow13 2>/dev/null | head -30

echo ""
echo "[9] OVS port statistics:"
echo "  Command: sudo ovs-ofctl dump-ports s1 -O OpenFlow13"
sudo ovs-ofctl dump-ports s1 -O OpenFlow13 2>/dev/null

# ── Step 8: Run Python feature extractor ───────────────────────────────────
echo ""
echo "[10] Running Python feature extractor..."
echo "  Command: python3 extract_features.py --pcap $PCAP_FILE --label $LABEL"
python3 "$(dirname "$0")/extract_features.py" \
    --pcap "$PCAP_FILE" \
    --label "$LABEL" \
    --output "$FEATURE_DIR"

echo ""
echo "============================================================"
echo "  CAPTURE & EXTRACTION COMPLETE"
echo "  PCAP     : $PCAP_FILE"
echo "  Features : $FEATURES_CSV"
echo "============================================================"
echo ""
echo "Next step: Run all attack scenarios and combine:"
echo "  bash capture_packets.sh 60 any normal"
echo "  bash capture_packets.sh 60 any traditional_lfa"
echo "  bash capture_packets.sh 60 any topology_poisoning"
echo "  bash capture_packets.sh 60 any telemetry_evasion"
echo "  bash capture_packets.sh 60 any slice_aware"
echo "  bash capture_packets.sh 60 any flow_saturation"
echo "  bash capture_packets.sh 60 any quantum_lfa"
echo ""
echo "Then build dataset:"
echo "  python3 dataset_builder.py"
