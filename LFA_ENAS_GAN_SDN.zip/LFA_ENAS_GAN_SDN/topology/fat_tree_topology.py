#!/usr/bin/env python3
"""
=============================================================================
LFA-ENAS-GAN-SDN: Fat-Tree Topology (k=4, 20 hosts)
=============================================================================
Fat-Tree is the standard data-center topology used in SDN LFA research.
k=4 → 4 core switches, 4 aggregate switches, 4 edge switches, 16 hosts

Usage:
    sudo python3 fat_tree_topology.py [--controller <IP>] [--k <value>]

Controller IP defaults to 127.0.0.1:6633 (local Ryu).
=============================================================================
"""

import argparse
import sys
from mininet.net import Mininet
from mininet.node import RemoteController, OVSKernelSwitch
from mininet.link import TCLink
from mininet.log import setLogLevel, info
from mininet.cli import CLI
from mininet.topo import Topo


class FatTreeTopo(Topo):
    """
    Fat-Tree topology with k=4.

    Structure:
      - Core layer    : (k/2)^2 = 4 switches  (c1..c4)
      - Aggregate layer: k pods × k/2 = 8 switches (a1..a8)
      - Edge layer    : k pods × k/2 = 8 switches  (e1..e8)
      - Hosts         : k pods × (k/2)^2 = 16 hosts (h1..h16)

    Bottleneck links are placed between aggregate and edge layers
    to simulate LFA congestion points.
    """

    def __init__(self, k=4, bw_host=100, bw_edge=50, bw_agg=100,
                 bw_core=200, bottleneck_bw=10, **opts):
        """
        Args:
            k             : Fat-tree parameter (must be even). Default 4.
            bw_host       : Host-to-edge link bandwidth (Mbps). Default 100.
            bw_edge       : Edge-to-aggregate bandwidth (Mbps). Default 50.
            bw_agg        : Aggregate-to-core bandwidth (Mbps). Default 100.
            bw_core       : Core switch uplink bandwidth (Mbps). Default 200.
            bottleneck_bw : Bottleneck link bandwidth (Mbps). Default 10.
        """
        self.k = k
        self.bw_host = bw_host
        self.bw_edge = bw_edge
        self.bw_agg = bw_agg
        self.bw_core = bw_core
        self.bottleneck_bw = bottleneck_bw
        super().__init__(**opts)

    def build(self):
        k = self.k
        half_k = k // 2
        num_pods = k

        # ---- Core Switches ----------------------------------------
        # (k/2)^2 core switches, labelled c1 .. c(k/2)^2
        core_switches = []
        for i in range(1, half_k ** 2 + 1):
            sw = self.addSwitch(f'c{i}',
                                cls=OVSKernelSwitch,
                                protocols='OpenFlow13')
            core_switches.append(sw)

        # ---- Aggregate & Edge Switches + Hosts --------------------
        # Indexed by pod (0..k-1) and position within pod (0..k/2-1)
        agg_switches = {}    # agg_switches[pod][pos]
        edge_switches = {}   # edge_switches[pod][pos]
        hosts = {}           # hosts[pod][pos][host_idx]

        host_count = 1
        for pod in range(num_pods):
            agg_switches[pod] = []
            edge_switches[pod] = []
            hosts[pod] = []

            # -- Aggregate layer (k/2 switches per pod) --
            for agg in range(half_k):
                sw = self.addSwitch(f'a{pod * half_k + agg + 1}',
                                    cls=OVSKernelSwitch,
                                    protocols='OpenFlow13')
                agg_switches[pod].append(sw)

            # -- Edge layer (k/2 switches per pod) --
            for edge in range(half_k):
                sw = self.addSwitch(f'e{pod * half_k + edge + 1}',
                                    cls=OVSKernelSwitch,
                                    protocols='OpenFlow13')
                edge_switches[pod].append(sw)
                host_list = []

                # -- Hosts (k/2 per edge switch) --
                for h in range(half_k):
                    host = self.addHost(
                        f'h{host_count}',
                        ip=f'10.{pod}.{edge}.{h + 2}/24',
                        defaultRoute=f'via 10.{pod}.{edge}.1'
                    )
                    # Mark ONE edge link as bottleneck (first edge in pod 0)
                    if pod == 0 and edge == 0:
                        self.addLink(host, sw,
                                     cls=TCLink,
                                     bw=self.bottleneck_bw,
                                     delay='1ms', loss=0,
                                     max_queue_size=100)
                    else:
                        self.addLink(host, sw,
                                     cls=TCLink,
                                     bw=self.bw_host,
                                     delay='1ms', loss=0)
                    host_list.append(host)
                    host_count += 1
                hosts[pod].append(host_list)

            # -- Edge ↔ Aggregate links (fully connected within pod) --
            for edge in range(half_k):
                for agg in range(half_k):
                    self.addLink(edge_switches[pod][edge],
                                 agg_switches[pod][agg],
                                 cls=TCLink,
                                 bw=self.bw_edge,
                                 delay='2ms', loss=0)

        # ---- Aggregate ↔ Core links --------------------------------
        # Each aggregate switch connects to k/2 core switches.
        # Core switch index: core[(agg_pos * half_k + pod) % num_core]
        for pod in range(num_pods):
            for agg in range(half_k):
                for core_idx in range(half_k):
                    c_sw = core_switches[agg * half_k + core_idx]
                    self.addLink(agg_switches[pod][agg], c_sw,
                                 cls=TCLink,
                                 bw=self.bw_agg,
                                 delay='3ms', loss=0)


def run_fat_tree(controller_ip='127.0.0.1', controller_port=6633, k=4):
    """Launch Fat-Tree topology and connect to remote Ryu controller."""
    setLogLevel('info')

    topo = FatTreeTopo(k=k, bottleneck_bw=10)

    net = Mininet(
        topo=topo,
        controller=None,          # We add remote controller manually
        switch=OVSKernelSwitch,
        link=TCLink,
        autoSetMacs=True,
        autoStaticArp=False
    )

    info(f"\n*** Adding remote controller at {controller_ip}:{controller_port}\n")
    c0 = net.addController(
        'c0',
        controller=RemoteController,
        ip=controller_ip,
        port=controller_port
    )

    info('*** Starting network\n')
    net.start()

    info('*** Configuring OpenFlow 1.3 on all switches\n')
    for sw in net.switches:
        sw.cmd(f'ovs-vsctl set bridge {sw.name} protocols=OpenFlow13')
        sw.cmd(f'ovs-vsctl set-controller {sw.name} '
               f'tcp:{controller_ip}:{controller_port}')

    info('\n*** Network topology ready\n')
    info(f'    Switches : {len(net.switches)}\n')
    info(f'    Hosts    : {len(net.hosts)}\n')
    info(f'    Links    : {len(net.links)}\n')

    info('\n*** Testing connectivity (ping all)...\n')
    net.pingAll()

    info('\n*** Entering Mininet CLI (type "exit" or Ctrl-D to quit)\n')
    info('    Useful CLI commands:\n')
    info('      nodes          - list all nodes\n')
    info('      net            - show links\n')
    info('      dump           - dump node info\n')
    info('      h1 ping h16    - ping between hosts\n')
    info('      iperf h1 h16   - bandwidth test\n')
    info('      exit           - stop network\n\n')
    CLI(net)

    info('*** Stopping network\n')
    net.stop()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Fat-Tree SDN Topology for LFA Research')
    parser.add_argument('--controller', default='127.0.0.1',
                        help='Controller IP (default: 127.0.0.1)')
    parser.add_argument('--port', type=int, default=6633,
                        help='Controller port (default: 6633)')
    parser.add_argument('--k', type=int, default=4,
                        help='Fat-tree k parameter (default: 4)')
    args = parser.parse_args()

    run_fat_tree(controller_ip=args.controller,
                 controller_port=args.port,
                 k=args.k)
