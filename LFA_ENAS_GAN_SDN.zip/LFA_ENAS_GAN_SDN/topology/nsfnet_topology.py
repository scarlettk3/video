#!/usr/bin/env python3
"""
=============================================================================
LFA-ENAS-GAN-SDN: NSFNET-Like WAN Topology (14 nodes)
=============================================================================
NSFNET (National Science Foundation Network) is a 14-node backbone topology
widely used in SDN LFA research to simulate wide-area link flooding.

Nodes represent major US cities:
  0=NY  1=DC  2=Pittsburgh  3=Atlanta  4=Miami  5=Houston  6=Kansas City
  7=Chicago  8=Denver  9=Seattle  10=Los Angeles  11=Palo Alto
  12=Salt Lake City  13=Minneapolis

Usage:
    sudo python3 nsfnet_topology.py [--controller <IP>]
=============================================================================
"""

import argparse
from mininet.net import Mininet
from mininet.node import RemoteController, OVSKernelSwitch
from mininet.link import TCLink
from mininet.log import setLogLevel, info
from mininet.cli import CLI
from mininet.topo import Topo


# NSFNET topology: (node_a, node_b, bandwidth_Mbps, delay_ms)
NSFNET_LINKS = [
    (0, 1, 100, 2),    # NY - DC
    (0, 7, 100, 12),   # NY - Chicago
    (1, 2, 100, 3),    # DC - Pittsburgh
    (1, 3, 50, 8),     # DC - Atlanta  <-- bottleneck link
    (2, 7, 100, 6),    # Pittsburgh - Chicago
    (3, 4, 100, 4),    # Atlanta - Miami
    (3, 5, 50, 10),    # Atlanta - Houston  <-- bottleneck link
    (4, 5, 100, 6),    # Miami - Houston
    (5, 6, 100, 8),    # Houston - Kansas City
    (5, 10, 100, 15),  # Houston - Los Angeles
    (6, 7, 100, 5),    # Kansas City - Chicago
    (6, 12, 100, 10),  # Kansas City - Salt Lake City
    (7, 8, 100, 12),   # Chicago - Denver
    (7, 13, 100, 4),   # Chicago - Minneapolis
    (8, 9, 100, 15),   # Denver - Seattle
    (8, 12, 100, 6),   # Denver - Salt Lake City
    (9, 11, 100, 10),  # Seattle - Palo Alto
    (10, 11, 100, 3),  # Los Angeles - Palo Alto
    (11, 12, 100, 8),  # Palo Alto - Salt Lake City
    (12, 13, 100, 20), # Salt Lake City - Minneapolis
]

NODE_NAMES = [
    'NY', 'DC', 'Pittsburgh', 'Atlanta', 'Miami', 'Houston',
    'KansasCity', 'Chicago', 'Denver', 'Seattle', 'LosAngeles',
    'PaloAlto', 'SaltLake', 'Minneapolis'
]


class NSFNETTopo(Topo):
    """
    14-node NSFNET backbone topology.
    Each router node has one host attached (h1..h14).
    Bottleneck links are explicitly set to lower bandwidth.
    """

    def __init__(self, bottleneck_bw=10, normal_bw=100, **opts):
        self.bottleneck_bw = bottleneck_bw
        self.normal_bw = normal_bw
        super().__init__(**opts)

    def build(self):
        # Bottleneck link pairs (based on NSFNET_LINKS above)
        bottleneck_pairs = {(1, 3), (3, 5)}

        switches = []
        hosts = []

        # Add 14 router/switches
        for i, name in enumerate(NODE_NAMES):
            sw = self.addSwitch(f's{i + 1}',
                                cls=OVSKernelSwitch,
                                protocols='OpenFlow13',
                                dpid=f'{i + 1:016x}')
            switches.append(sw)

            # Each router has one host attached
            host = self.addHost(
                f'h{i + 1}',
                ip=f'10.0.{i + 1}.1/24',
                defaultRoute=f'via 10.0.{i + 1}.254'
            )
            hosts.append(host)

            # Host-to-router link (access link)
            self.addLink(host, sw,
                         cls=TCLink,
                         bw=1000, delay='0.1ms', loss=0)

        # Add inter-router links
        for (a, b, bw, delay) in NSFNET_LINKS:
            pair = (min(a, b), max(a, b))
            link_bw = self.bottleneck_bw if pair in bottleneck_pairs else bw
            self.addLink(switches[a], switches[b],
                         cls=TCLink,
                         bw=link_bw,
                         delay=f'{delay}ms',
                         loss=0,
                         max_queue_size=1000)


def run_nsfnet(controller_ip='127.0.0.1', controller_port=6633):
    setLogLevel('info')

    topo = NSFNETTopo(bottleneck_bw=10)

    net = Mininet(
        topo=topo,
        controller=None,
        switch=OVSKernelSwitch,
        link=TCLink,
        autoSetMacs=True
    )

    info(f"\n*** Adding remote controller at {controller_ip}:{controller_port}\n")
    net.addController(
        'c0',
        controller=RemoteController,
        ip=controller_ip,
        port=controller_port
    )

    info('*** Starting NSFNET topology\n')
    net.start()

    info('*** Configuring OpenFlow 1.3\n')
    for sw in net.switches:
        sw.cmd(f'ovs-vsctl set bridge {sw.name} protocols=OpenFlow13')
        sw.cmd(f'ovs-vsctl set-controller {sw.name} '
               f'tcp:{controller_ip}:{controller_port}')

    info('\n=== NSFNET Topology Ready ===\n')
    info(f'  Nodes     : {len(net.switches)} (14 NSFNET routers)\n')
    info(f'  Hosts     : {len(net.hosts)}\n')
    info(f'  Links     : {len(NSFNET_LINKS)} inter-router + 14 access\n')
    info('  Bottleneck: DC-Atlanta (s2-s4), Atlanta-Houston (s4-s6)\n\n')

    # Label bottleneck links for attack simulation
    info('*** Bottleneck links identified for LFA simulation:\n')
    info('    h4 (Atlanta) → h2 (DC): bw=10Mbps (target)\n')
    info('    h6 (Houston) → h4 (Atlanta): bw=10Mbps (target)\n\n')

    net.pingAll()
    CLI(net)
    net.stop()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='NSFNET WAN Topology for LFA Research')
    parser.add_argument('--controller', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=6633)
    args = parser.parse_args()
    run_nsfnet(args.controller, args.port)
