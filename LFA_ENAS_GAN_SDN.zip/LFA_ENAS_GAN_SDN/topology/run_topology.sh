#!/bin/bash
# =============================================================================
# LFA-ENAS-GAN-SDN: Topology Startup & Management Commands
# Run inside Ubuntu where Mininet is installed
# =============================================================================

# Usage: bash run_topology.sh [fat_tree | nsfnet] [controller_ip]

TOPOLOGY=${1:-fat_tree}
CONTROLLER=${2:-127.0.0.1}
CONTROLLER_PORT=6633

echo "============================================================"
echo "  Starting $TOPOLOGY topology"
echo "  Controller: $CONTROLLER:$CONTROLLER_PORT"
echo "============================================================"

# ----- Pre-flight checks -----
echo "[1] Checking OVS..."
sudo systemctl start openvswitch-switch
sudo ovs-vsctl show

echo "[2] Cleaning up any previous Mininet state..."
sudo mn -c 2>/dev/null || true
sudo pkill -f mininet 2>/dev/null || true

echo "[3] Checking controller is running at $CONTROLLER:$CONTROLLER_PORT..."
nc -z -w 2 "$CONTROLLER" "$CONTROLLER_PORT" && echo "  Controller: REACHABLE" \
    || echo "  WARNING: Controller not responding. Start ryu-manager first!"

# ----- Start topology -----
echo "[4] Starting topology..."
case "$TOPOLOGY" in
    fat_tree)
        echo "  Topology: Fat-Tree (k=4, 16 hosts, 20 switches)"
        echo "  Command: sudo python3 fat_tree_topology.py --controller $CONTROLLER --port $CONTROLLER_PORT"
        sudo python3 "$(dirname "$0")/fat_tree_topology.py" \
            --controller "$CONTROLLER" --port "$CONTROLLER_PORT"
        ;;
    nsfnet)
        echo "  Topology: NSFNET (14 nodes, 20 links)"
        echo "  Command: sudo python3 nsfnet_topology.py --controller $CONTROLLER"
        sudo python3 "$(dirname "$0")/nsfnet_topology.py" \
            --controller "$CONTROLLER" --port "$CONTROLLER_PORT"
        ;;
    *)
        echo "ERROR: Unknown topology '$TOPOLOGY'. Use 'fat_tree' or 'nsfnet'."
        exit 1
        ;;
esac

echo "============================================================"
echo "  Topology stopped. Run 'sudo mn -c' to clean up."
echo "============================================================"
