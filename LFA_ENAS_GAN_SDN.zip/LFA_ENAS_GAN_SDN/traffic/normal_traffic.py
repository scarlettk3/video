#!/usr/bin/env python3
"""
=============================================================================
LFA-ENAS-GAN-SDN: Normal Traffic Generator
=============================================================================
Generates 5 types of legitimate background traffic inside Mininet:
  1. Normal TCP (bulk transfer)
  2. Normal UDP
  3. ICMP / ping
  4. Web-like HTTP traffic (random page requests)
  5. Video streaming (CBR UDP)

Run this INSIDE Mininet CLI via:
    mininet> py exec(open('/path/to/normal_traffic.py').read())

Or from individual host terminals:
    mininet> xterm h1 h2
    # In h1 terminal: python3 normal_traffic.py --mode tcp --src h1 --dst h2

For automated background traffic during experiments:
    sudo python3 normal_traffic.py --auto --duration 120
=============================================================================
"""

import os
import sys
import time
import random
import socket
import struct
import threading
import argparse
import subprocess
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
LOG = logging.getLogger('NormalTraffic')

# Host IP mapping (matches fat-tree topology 10.pod.edge.host)
HOST_IPS = {
    'h1' : '10.0.0.2',  'h2' : '10.0.0.3',
    'h3' : '10.0.1.2',  'h4' : '10.0.1.3',
    'h5' : '10.1.0.2',  'h6' : '10.1.0.3',
    'h7' : '10.1.1.2',  'h8' : '10.1.1.3',
    'h9' : '10.2.0.2',  'h10': '10.2.0.3',
    'h11': '10.2.1.2',  'h12': '10.2.1.3',
    'h13': '10.3.0.2',  'h14': '10.3.0.3',
    'h15': '10.3.1.2',  'h16': '10.3.1.3',
}


# =============================================================================
# 1. TCP Bulk Transfer (iperf3)
# =============================================================================
def generate_tcp_traffic(src_ip, dst_ip, duration=30, bandwidth='10M',
                          port=5201, parallel=4):
    """
    Generate normal TCP bulk transfer using iperf3.

    Commands equivalent:
        Server: iperf3 -s -p 5201
        Client: iperf3 -c <dst_ip> -t 30 -b 10M -P 4 -p 5201
    """
    LOG.info('[TCP] Starting iperf3: %s → %s  bw=%s  dur=%ds  streams=%d',
             src_ip, dst_ip, bandwidth, duration, parallel)

    # Start iperf3 server in background
    server_cmd = f'iperf3 -s -p {port} -1 --daemon'
    LOG.info('[TCP] Server cmd: %s', server_cmd)

    # Client command
    client_cmd = (
        f'iperf3 -c {dst_ip} -t {duration} -b {bandwidth} '
        f'-P {parallel} -p {port} -J'
    )
    LOG.info('[TCP] Client cmd: %s', client_cmd)

    try:
        result = subprocess.run(
            client_cmd.split(), capture_output=True, text=True, timeout=duration + 10
        )
        LOG.info('[TCP] Result: %s', result.stdout[:200] if result.stdout else 'No output')
    except subprocess.TimeoutExpired:
        LOG.warning('[TCP] iperf3 timed out')
    except FileNotFoundError:
        LOG.error('[TCP] iperf3 not found. Install with: apt install iperf3')


# =============================================================================
# 2. UDP Traffic
# =============================================================================
def generate_udp_traffic(src_ip, dst_ip, duration=30, bandwidth='5M',
                          port=5002):
    """
    Generate UDP traffic using iperf3.

    Commands equivalent:
        Server: iperf3 -s -p 5002
        Client: iperf3 -c <dst_ip> -u -t 30 -b 5M -p 5002
    """
    LOG.info('[UDP] Starting UDP traffic: %s → %s  bw=%s  dur=%ds',
             src_ip, dst_ip, bandwidth, duration)

    client_cmd = (
        f'iperf3 -c {dst_ip} -u -t {duration} -b {bandwidth} -p {port}'
    )
    LOG.info('[UDP] Client cmd: %s', client_cmd)

    try:
        result = subprocess.run(
            client_cmd.split(), capture_output=True, text=True, timeout=duration + 10
        )
        LOG.info('[UDP] Done. stdout: %s', result.stdout[:100])
    except subprocess.TimeoutExpired:
        LOG.warning('[UDP] Timed out')


# =============================================================================
# 3. ICMP Ping Traffic
# =============================================================================
def generate_icmp_traffic(dst_ip, count=100, interval=0.1, size=64):
    """
    Generate ICMP echo traffic using ping.

    Commands equivalent:
        ping -c 100 -i 0.1 -s 64 <dst_ip>
    """
    LOG.info('[ICMP] Pinging %s: count=%d interval=%.2fs size=%d',
             dst_ip, count, interval, size)

    cmd = f'ping -c {count} -i {interval} -s {size} {dst_ip}'
    LOG.info('[ICMP] Command: %s', cmd)

    try:
        result = subprocess.run(
            cmd.split(), capture_output=True, text=True, timeout=count * interval * 2 + 5
        )
        # Parse packet loss
        output = result.stdout
        for line in output.split('\n'):
            if 'packet loss' in line:
                LOG.info('[ICMP] Result: %s', line.strip())
    except subprocess.TimeoutExpired:
        LOG.warning('[ICMP] Ping timed out')


# =============================================================================
# 4. Web-Like HTTP Traffic (Python socket)
# =============================================================================
class WebTrafficGenerator:
    """
    Simulates HTTP GET requests to random destinations.
    Mimics browser traffic patterns:
      - Short connection bursts
      - Think time between requests
      - Variable request sizes
    """

    def __init__(self, target_ip, port=80, num_requests=50, think_time=0.5):
        self.target_ip   = target_ip
        self.port        = port
        self.num_requests= num_requests
        self.think_time  = think_time
        self.pages       = [
            '/index.html', '/about.html', '/products.html',
            '/api/data', '/static/main.js', '/images/logo.png',
            '/search?q=test', '/login', '/dashboard'
        ]

    def send_request(self, path='/index.html'):
        """Send one HTTP GET request via raw socket."""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            sock.connect((self.target_ip, self.port))

            request = (
                f'GET {path} HTTP/1.1\r\n'
                f'Host: {self.target_ip}\r\n'
                f'User-Agent: LFA-Research-Traffic/1.0\r\n'
                f'Accept: text/html\r\n'
                f'Connection: close\r\n\r\n'
            )
            sock.sendall(request.encode())

            # Read response (partial)
            response = b''
            while True:
                chunk = sock.recv(4096)
                if not chunk:
                    break
                response += chunk
                if len(response) > 8192:   # cap at 8KB
                    break
            sock.close()
            return len(response)
        except (socket.error, socket.timeout):
            return 0

    def run(self):
        LOG.info('[HTTP] Web traffic → %s:%d  requests=%d',
                 self.target_ip, self.port, self.num_requests)
        success = 0
        for i in range(self.num_requests):
            path = random.choice(self.pages)
            size = self.send_request(path)
            if size > 0:
                success += 1
            time.sleep(random.uniform(self.think_time * 0.5,
                                      self.think_time * 1.5))
        LOG.info('[HTTP] Done: %d/%d successful', success, self.num_requests)


# =============================================================================
# 5. Video Streaming Traffic (CBR UDP)
# =============================================================================
def generate_video_streaming(dst_ip, duration=60, bitrate='4M', port=5004):
    """
    Simulate video streaming using constant bit-rate UDP.
    Equivalent to a 4 Mbps HD video stream.

    Commands equivalent:
        Server: iperf3 -s -p 5004
        Client: iperf3 -c <dst_ip> -u -b 4M -t 60 -l 1316 -p 5004
        (packet size 1316 bytes = typical RTP payload over UDP)
    """
    LOG.info('[VIDEO] Streaming to %s: %s for %ds', dst_ip, bitrate, duration)

    # Packet size 1316 = RTP over UDP (H.264 typical)
    cmd = (
        f'iperf3 -c {dst_ip} -u -b {bitrate} -t {duration} '
        f'-l 1316 -p {port}'
    )
    LOG.info('[VIDEO] Command: %s', cmd)

    try:
        result = subprocess.run(
            cmd.split(), capture_output=True, text=True, timeout=duration + 10
        )
        LOG.info('[VIDEO] Done. %s',
                 result.stdout[-200:] if result.stdout else '')
    except subprocess.TimeoutExpired:
        LOG.warning('[VIDEO] Timed out')


# =============================================================================
# 6. Mixed Background Traffic (multi-threaded)
# =============================================================================
def generate_background_traffic(duration=120):
    """
    Launch all traffic types simultaneously in threads.
    Simulates realistic background network activity.
    """
    LOG.info('Starting mixed background traffic for %ds...', duration)
    LOG.info('This simulates realistic LFA background conditions.')

    # Define traffic flows
    flows = [
        # (function, args)
        (generate_tcp_traffic,    ('10.0.0.2', '10.2.0.2', duration, '20M', 5201, 3)),
        (generate_tcp_traffic,    ('10.0.1.2', '10.3.0.2', duration, '15M', 5202, 2)),
        (generate_udp_traffic,    ('10.1.0.2', '10.2.1.2', duration, '8M',  5003)),
        (generate_udp_traffic,    ('10.1.1.2', '10.3.1.2', duration, '5M',  5004)),
        (generate_icmp_traffic,   ('10.2.0.2', int(duration / 0.1), 0.1, 64)),
        (generate_video_streaming,('10.3.0.2', duration, '4M', 5005)),
    ]

    threads = []
    for func, args in flows:
        t = threading.Thread(target=func, args=args, daemon=True)
        t.start()
        threads.append(t)
        time.sleep(0.2)   # stagger starts

    LOG.info('All %d traffic flows started. Waiting for completion...', len(threads))
    for t in threads:
        t.join(timeout=duration + 30)

    LOG.info('Background traffic generation complete.')


# =============================================================================
# Shell Command Reference (for manual execution)
# =============================================================================
COMMAND_REFERENCE = """
╔══════════════════════════════════════════════════════════════════╗
║           MANUAL TRAFFIC COMMANDS (run inside Mininet)          ║
╚══════════════════════════════════════════════════════════════════╝

── iperf3 TCP bulk transfer ──────────────────────────────────────
  # On h2 (server):
  mininet> h2 iperf3 -s -p 5201 &

  # On h1 (client):
  mininet> h1 iperf3 -c 10.0.1.2 -t 30 -b 10M -P 4 -p 5201

── iperf3 UDP ────────────────────────────────────────────────────
  mininet> h4 iperf3 -s -u -p 5002 &
  mininet> h1 iperf3 -c 10.0.1.3 -u -b 5M -t 30 -p 5002

── ICMP ping ─────────────────────────────────────────────────────
  mininet> h1 ping -c 100 -i 0.1 -s 64 10.2.0.2

── Video streaming (4 Mbps CBR) ──────────────────────────────────
  mininet> h16 iperf3 -s -u -p 5004 &
  mininet> h1 iperf3 -c 10.3.1.3 -u -b 4M -t 60 -l 1316 -p 5004

── D-ITG mixed traffic ───────────────────────────────────────────
  # On receiver (h2):
  mininet> h2 ITGRecv &

  # On sender (h1) — mixed TCP+UDP traffic:
  mininet> h1 ITGSend -a 10.0.1.2 -T TCP -t 30000 -c 1000 -C 500 &
  mininet> h1 ITGSend -a 10.0.1.2 -T UDP -t 30000 -c 512 -C 1000 &

── Monitor traffic in real time ──────────────────────────────────
  # Watch interface stats:
  mininet> h1 ifconfig h1-eth0

  # Full link monitoring:
  sudo iftop -i s1-eth1

"""


# =============================================================================
# Main Entry Point
# =============================================================================
if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Normal SDN Traffic Generator')
    parser.add_argument('--mode', choices=['tcp', 'udp', 'icmp', 'web',
                                           'video', 'background', 'info'],
                        default='background',
                        help='Traffic type (default: background)')
    parser.add_argument('--src', default='10.0.0.2', help='Source IP')
    parser.add_argument('--dst', default='10.1.0.2', help='Destination IP')
    parser.add_argument('--duration', type=int, default=60,
                        help='Duration in seconds (default: 60)')
    parser.add_argument('--bw', default='10M', help='Bandwidth (default: 10M)')
    args = parser.parse_args()

    if args.mode == 'tcp':
        generate_tcp_traffic(args.src, args.dst, args.duration, args.bw)
    elif args.mode == 'udp':
        generate_udp_traffic(args.src, args.dst, args.duration, args.bw)
    elif args.mode == 'icmp':
        generate_icmp_traffic(args.dst, count=200, interval=0.1)
    elif args.mode == 'web':
        WebTrafficGenerator(args.dst, num_requests=100).run()
    elif args.mode == 'video':
        generate_video_streaming(args.dst, args.duration, args.bw)
    elif args.mode == 'background':
        generate_background_traffic(args.duration)
    elif args.mode == 'info':
        print(COMMAND_REFERENCE)
