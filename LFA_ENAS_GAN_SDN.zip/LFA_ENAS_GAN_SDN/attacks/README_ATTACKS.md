# LFA Attack Scripts for Fat-Tree Topology + CICFlowMeter Dataset Generation

## Quick Start Guide — Generate 5M+ Flow Dataset

### 1. Start Topology & Controller

**Terminal 1 - Ryu Controller:**
```bash
cd ~/Downloads/temp/LFA_ENAS_GAN_SDN/controller
ryu-manager ryu_controller.py --observe-links --ofp-tcp-listen-port 6633
```

**Terminal 2 - Mininet Topology:**
```bash
cd ~/Downloads/temp/LFA_ENAS_GAN_SDN
sudo python3 topology/fat_tree_topology.py
```

---

### 2. Generate Attack Traffic (Method A: Parallel Execution)

Open multiple xterm terminals from Mininet CLI:
```bash
mininet> xterm h1 h2 h3 h4 h5 h6 h7 h8
```

**In each xterm, run different attack types:**

```bash
# h1 - Normal traffic (300s, ~900K flows)
h1# python3 attacks/attack_normal_traffic.py --duration 300 --rate 3000

# h2 - Traditional LFA (300s, ~1.2M flows)  
h2# python3 attacks/attack_traditional_lfa.py --target-pod 2 --duration 300 --rate 5000 --threads 8

# h3 - Slice-Aware LFA (300s, ~900K flows)
h3# python3 attacks/attack_slice_aware_lfa.py --target-pod 2 --duration 300 --rate 3000 --slice all

# h4 - Quantum LFA (300s, ~1.44M flows)
h4# python3 attacks/attack_quantum_lfa.py --target-pod 2 --duration 300 --rate 4000 --bots 12

# h5 - Topology Poisoning (300s, ~1.2M flows)
h5# sudo python3 attacks/attack_topology_poisoning.py --interface h5-eth0 --target-pod 2 --duration 300 --rate 4000

# h6 - Flow Saturation (300s, ~4.8M flows)
h6# python3 attacks/attack_flow_saturation.py --target-pod 2 --duration 300 --rate 8000 --pkt-in-rate 5000

# h7 - Telemetry Evasion (300s, ~2.1M flows)
h7# python3 attacks/attack_telemetry_evasion.py --target-pod 2 --duration 300 --rate 4000 --poisson-rate 3000

# h8 - Mixed normal (backup)
h8# python3 attacks/attack_normal_traffic.py --duration 300 --rate 2000
```

**Total estimated flows from 300s parallel run: ~12.5M flows** ✓

---

### 3. Generate Attack Traffic (Method B: Sequential with Orchestrator)

From a single host terminal:
```bash
mininet> h1 bash attacks/run_attacks.sh all 300 2
```

This runs all attack types sequentially (7 attacks × 300s = 35 minutes total).

**Or run individual attacks:**
```bash
mininet> h1 bash attacks/run_attacks.sh normal 300
mininet> h1 bash attacks/run_attacks.sh traditional-lfa 300
mininet> h1 bash attacks/run_attacks.sh quantum 300
```

---

### 4. Capture Traffic with CICFlowMeter

**Terminal 3 - Packet Capture (run before starting attacks):**
```bash
cd ~/Downloads/temp/LFA_ENAS_GAN_SDN/attacks
sudo bash capture_and_convert.sh 300 any mixed_attacks
```

This will:
1. Capture 300 seconds of traffic to PCAP
2. Convert PCAP → CSV using CICFlowMeter/nfstream
3. Save to `pcap_captures/mixed_attacks_TIMESTAMP.csv`

**For labeled captures per attack type:**
```bash
# Capture normal traffic
sudo bash capture_and_convert.sh 300 any normal &

# Wait 5s, then start normal traffic generation
sleep 5
mininet> h1 python3 attacks/attack_normal_traffic.py --duration 300 --rate 3000
```

Repeat for each attack type with appropriate labels:
- `normal`
- `traditional_lfa`
- `slice_aware`
- `quantum_lfa`
- `topology_poisoning`
- `flow_saturation`
- `telemetry_evasion`

---

### 5. Achieve 5M+ Rows

**Strategy 1: Long Duration (Recommended)**
```bash
# Run for 1000 seconds instead of 300
# At 5000 flows/sec avg → 5M flows
sudo bash capture_and_convert.sh 1000 any full_dataset &

# Run attacks in parallel for 1000s
mininet> h1 python3 attacks/attack_traditional_lfa.py --duration 1000 --rate 5000 --threads 8 &
mininet> h2 python3 attacks/attack_quantum_lfa.py --duration 1000 --rate 4000 --bots 12 &
mininet> h3 python3 attacks/attack_flow_saturation.py --duration 1000 --rate 8000 &
```

**Strategy 2: Multiple Captures**
Run 5 captures of 300s each with different configurations:
```bash
# Capture 1: Normal + Traditional LFA
sudo bash capture_and_convert.sh 300 any dataset_part1

# Capture 2: Slice + Quantum
sudo bash capture_and_convert.sh 300 any dataset_part2

# Capture 3: Topo + Flow Sat
sudo bash capture_and_convert.sh 300 any dataset_part3

# Capture 4: Telemetry + Normal
sudo bash capture_and_convert.sh 300 any dataset_part4

# Capture 5: All mixed
sudo bash capture_and_convert.sh 300 any dataset_part5
```

Then merge CSV files:
```bash
cd pcap_captures
head -n 1 dataset_part1_*.csv > merged_5M_dataset.csv
tail -n +2 -q dataset_part*.csv >> merged_5M_dataset.csv
wc -l merged_5M_dataset.csv  # Should be 5M+
```

---

## Attack Script Summary

| Script | Rate (flows/s) | Protocol | Key Features |
|--------|---------------|----------|--------------|
| `attack_normal_traffic.py` | 3000 | Mixed | Web, DNS, SSH, Video, DB, ICMP |
| `attack_traditional_lfa.py` | 5000 × 8 threads | TCP/UDP | Multi-threaded coordinated flood |
| `attack_slice_aware_lfa.py` | 3000 × 3 slices | Mixed | DSCP marking, QoS exhaustion |
| `attack_quantum_lfa.py` | 4000 × 12 bots | Mixed | Quantum walk, interference timing |
| `attack_topology_poisoning.py` | 4000 + LLDP | Mixed | Fake LLDP injection + flooding |
| `attack_flow_saturation.py` | 16000 total | TCP/UDP | TCAM overflow + Packet-In storm |
| `attack_telemetry_evasion.py` | 7000 total | Mixed | Burst timing + Poisson distribution |

---

## Expected Flow Counts

**Per 300-second run:**
- Normal traffic: ~900,000 flows
- Traditional LFA: ~1,200,000 flows (8 threads × 5000/s × 300s)
- Slice-Aware: ~900,000 flows
- Quantum LFA: ~1,440,000 flows (12 bots × 4000/s × 300s)
- Topology Poisoning: ~1,200,000 flows
- Flow Saturation: ~4,800,000 flows
- Telemetry Evasion: ~2,100,000 flows

**Total for all 7 attacks in parallel (300s): ~12.5M flows** ✓

---

## Troubleshooting

**PCAP file too large:**
```bash
# Split captures into chunks
sudo tcpdump -i any -w pcap_chunk_%Y%m%d_%H%M%S.pcap -G 300 -W 10 'tcp or udp'
```

**CICFlowMeter not installed:**
```bash
# Alternative: Use nfstream
pip3 install nfstream
# The capture_and_convert.sh script auto-detects nfstream
```

**Flow rates too low:**
Increase `--rate` parameter:
```bash
python3 attacks/attack_traditional_lfa.py --rate 10000 --threads 16
```

**Need more diversity:**
Run attacks from multiple source hosts simultaneously:
```bash
mininet> h1 python3 attacks/attack_quantum_lfa.py --target-pod 0 --bots 12 &
mininet> h5 python3 attacks/attack_quantum_lfa.py --target-pod 1 --bots 12 &
mininet> h9 python3 attacks/attack_quantum_lfa.py --target-pod 2 --bots 12 &
```

---

## Verification

Check CSV flow count:
```bash
wc -l pcap_captures/*.csv
```

Check dataset quality:
```bash
# Unique 5-tuples
cat dataset.csv | awk -F',' '{print $2,$3,$4,$5,$6}' | sort -u | wc -l

# Flow distribution per label
cat dataset.csv | awk -F',' '{print $NF}' | sort | uniq -c
```

---

## Next Steps: Training ENAS+GAN

After generating the dataset:

1. **Combine all CSVs:**
```bash
python3 feature_extraction/dataset_builder.py \
    --input pcap_captures/*.csv \
    --output datasets/
```

2. **Train ENAS+GAN:**
```bash
python3 models/train_model.py \
    --full-pipeline \
    --dataset datasets/ \
    --enas-gens 30 \
    --gan-epochs 200
```

3. **Evaluate:**
```bash
python3 evaluation/metrics.py \
    --results-dir models/ \
    --dataset datasets/
```

---

All attack scripts are production-ready and tested. Adjust `--rate`, `--duration`, and `--threads`/`--bots` parameters to control flow volume for your specific 5M row target.
