#!/bin/bash
#
# Master Attack Orchestration Script
# ===================================
# Sequentially runs all attack types to generate comprehensive dataset
# Target: 5,000,000+ flows for CICFlowMeter
#
# Usage:
#   From Mininet CLI:
#   mininet> xterm h1 h2 h3 h4 h5 h6 h7 h8
#   
#   In each xterm terminal, run this script with different attack types:
#   h1# bash run_attacks.sh normal 300
#   h2# bash run_attacks.sh traditional-lfa 300
#   h3# bash run_attacks.sh slice-aware 300
#   ...

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ATTACK_TYPE="${1:-all}"
DURATION="${2:-300}"
TARGET_POD="${3:-2}"

# Color output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() {
    echo -e "${GREEN}[$(date '+%H:%M:%S')]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

# Check Python availability
if ! command -v python3 &> /dev/null; then
    error "python3 not found"
    exit 1
fi

run_normal_traffic() {
    log "Running NORMAL traffic generation..."
    python3 "$SCRIPT_DIR/attack_normal_traffic.py" \
        --duration "$DURATION" \
        --rate 3000
}

run_traditional_lfa() {
    log "Running TRADITIONAL LFA attack..."
    python3 "$SCRIPT_DIR/attack_traditional_lfa.py" \
        --target-pod "$TARGET_POD" \
        --duration "$DURATION" \
        --rate 5000 \
        --threads 8 \
        --protocol mixed
}

run_slice_aware() {
    log "Running SLICE-AWARE LFA attack..."
    python3 "$SCRIPT_DIR/attack_slice_aware_lfa.py" \
        --target-pod "$TARGET_POD" \
        --duration "$DURATION" \
        --rate 3000 \
        --slice all
}

run_quantum() {
    log "Running QUANTUM-INSPIRED LFA attack..."
    
    # Check numpy availability
    if ! python3 -c "import numpy" 2>/dev/null; then
        warning "NumPy not available, skipping quantum attack"
        return 1
    fi
    
    python3 "$SCRIPT_DIR/attack_quantum_lfa.py" \
        --target-pod "$TARGET_POD" \
        --duration "$DURATION" \
        --rate 4000 \
        --bots 12
}

run_topology_poisoning() {
    log "Running TOPOLOGY POISONING attack..."
    
    # Check if running as root
    if [[ $EUID -ne 0 ]]; then
        warning "Not root - LLDP injection will be simulated"
    fi
    
    python3 "$SCRIPT_DIR/attack_topology_poisoning.py" \
        --interface eth0 \
        --target-pod "$TARGET_POD" \
        --duration "$DURATION" \
        --rate 4000
}

run_flow_saturation() {
    log "Running FLOW RULE SATURATION attack..."
    python3 "$SCRIPT_DIR/attack_flow_saturation.py" \
        --target-pod "$TARGET_POD" \
        --duration "$DURATION" \
        --rate 8000 \
        --pkt-in-rate 5000 \
        --thrash-rate 3000
}

run_telemetry_evasion() {
    log "Running TELEMETRY EVASION attack..."
    python3 "$SCRIPT_DIR/attack_telemetry_evasion.py" \
        --target-pod "$TARGET_POD" \
        --duration "$DURATION" \
        --rate 4000 \
        --poisson-rate 3000 \
        --poll-interval 2.0
}

# Main execution
echo ""
echo "=================================================================="
echo "  LFA Attack Orchestration"
echo "=================================================================="
echo "  Attack Type: $ATTACK_TYPE"
echo "  Duration:    ${DURATION}s"
echo "  Target Pod:  $TARGET_POD"
echo "=================================================================="
echo ""

case "$ATTACK_TYPE" in
    normal)
        run_normal_traffic
        ;;
    traditional-lfa|traditional)
        run_traditional_lfa
        ;;
    slice-aware|slice)
        run_slice_aware
        ;;
    quantum|quantum-lfa)
        run_quantum
        ;;
    topology-poisoning|topo-poison)
        run_topology_poisoning
        ;;
    flow-saturation|flow-sat)
        run_flow_saturation
        ;;
    telemetry-evasion|telem-evade)
        run_telemetry_evasion
        ;;
    all)
        log "Running ALL attack types sequentially..."
        log "Total estimated time: $((DURATION * 7 / 60)) minutes"
        echo ""
        
        run_normal_traffic
        sleep 5
        
        run_traditional_lfa
        sleep 5
        
        run_slice_aware
        sleep 5
        
        run_quantum || warning "Quantum attack skipped"
        sleep 5
        
        run_topology_poisoning
        sleep 5
        
        run_flow_saturation
        sleep 5
        
        run_telemetry_evasion
        
        log "All attacks completed!"
        ;;
    *)
        error "Unknown attack type: $ATTACK_TYPE"
        echo ""
        echo "Valid attack types:"
        echo "  normal             - Normal traffic"
        echo "  traditional-lfa    - Traditional coordinated LFA"
        echo "  slice-aware        - QoS slice exhaustion"
        echo "  quantum            - Quantum-inspired coordination"
        echo "  topology-poisoning - LLDP-based topology corruption"
        echo "  flow-saturation    - TCAM overflow + Packet-In storm"
        echo "  telemetry-evasion  - Timing-based evasion"
        echo "  all                - Run all attacks sequentially"
        exit 1
        ;;
esac

echo ""
log "Attack execution completed successfully"
