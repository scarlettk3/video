#!/usr/bin/env python3
"""
Normal Traffic Generator for Fat-Tree Topology
===============================================
Generates diverse normal traffic patterns for baseline dataset.

Usage:
    mininet> h1 python3 attacks/attack_normal_traffic.py --duration 300 --rate 3000 &
"""

import socket
import random
import time
import argparse
import threading

TOPOLOGY = {
    0: ['10.0.0.1', '10.0.0.2', '10.0.1.1', '10.0.1.2'],
    1: ['10.1.0.1', '10.1.0.2', '10.1.1.1', '10.1.1.2'],
    2: ['10.2.0.1', '10.2.0.2', '10.2.1.1', '10.2.1.2'],
    3: ['10.3.0.1', '10.3.0.2', '10.3.1.1', '10.3.1.2']
}

# All hosts across all pods
ALL_HOSTS = []
for hosts in TOPOLOGY.values():
    ALL_HOSTS.extend(hosts)


class NormalTrafficGenerator:
    """Generate realistic normal traffic patterns"""
    
    def __init__(self, rate=3000):
        self.rate = rate
        self.active = False
        self.stats = {'flows': 0, 'packets': 0, 'bytes': 0}
    
    def generate_web_traffic(self, src_ip, dst_ip):
        """Simulate HTTP/HTTPS traffic"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            source_port = random.randint(10000, 65000)
            sock.bind(('', source_port))
            
            target_port = random.choice([80, 443, 8080])
            
            try:
                sock.connect((dst_ip, target_port))
                
                # Simulate HTTP request-response
                # Request
                request = b'GET / HTTP/1.1\r\nHost: example.com\r\n\r\n'
                sock.send(request)
                self.stats['bytes'] += len(request)
                self.stats['packets'] += 1
                
                # Response (simulated)
                response_size = random.randint(500, 5000)
                for _ in range(response_size // 1400 + 1):
                    chunk_size = min(1400, response_size)
                    chunk = bytes([random.randint(0, 255) for _ in range(chunk_size)])
                    try:
                        sock.send(chunk)
                        self.stats['bytes'] += chunk_size
                        self.stats['packets'] += 1
                    except:
                        break
                    response_size -= chunk_size
                    time.sleep(0.001)
            except:
                pass
            finally:
                sock.close()
                self.stats['flows'] += 1
        except:
            pass
    
    def generate_dns_traffic(self, dst_ip):
        """Simulate DNS queries"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            source_port = random.randint(10000, 65000)
            sock.bind(('', source_port))
            
            # DNS query
            query = bytes([random.randint(0, 255) for _ in range(random.randint(40, 80))])
            sock.sendto(query, (dst_ip, 53))
            self.stats['bytes'] += len(query)
            self.stats['packets'] += 1
            
            # DNS response (simulated)
            response = bytes([random.randint(0, 255) for _ in range(random.randint(60, 200))])
            sock.sendto(response, (dst_ip, 53))
            self.stats['bytes'] += len(response)
            self.stats['packets'] += 1
            
            sock.close()
            self.stats['flows'] += 1
        except:
            pass
    
    def generate_ssh_traffic(self, dst_ip):
        """Simulate SSH session"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            source_port = random.randint(10000, 65000)
            sock.bind(('', source_port))
            
            try:
                sock.connect((dst_ip, 22))
                
                # Simulate interactive SSH
                num_exchanges = random.randint(10, 50)
                for _ in range(num_exchanges):
                    packet_size = random.randint(50, 200)
                    packet = bytes([random.randint(0, 255) for _ in range(packet_size)])
                    sock.send(packet)
                    self.stats['bytes'] += packet_size
                    self.stats['packets'] += 1
                    time.sleep(random.uniform(0.05, 0.2))
            except:
                pass
            finally:
                sock.close()
                self.stats['flows'] += 1
        except:
            pass
    
    def generate_video_streaming(self, dst_ip):
        """Simulate video streaming (UDP)"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            source_port = random.randint(10000, 65000)
            sock.bind(('', source_port))
            
            # Video packets at ~30 fps
            num_frames = random.randint(30, 150)
            for _ in range(num_frames):
                frame_size = random.randint(800, 1400)
                frame = bytes([random.randint(0, 255) for _ in range(frame_size)])
                sock.sendto(frame, (dst_ip, 554))  # RTSP port
                self.stats['bytes'] += frame_size
                self.stats['packets'] += 1
                time.sleep(0.033)  # 30 fps
            
            sock.close()
            self.stats['flows'] += 1
        except:
            pass
    
    def generate_database_traffic(self, dst_ip):
        """Simulate database queries"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            source_port = random.randint(10000, 65000)
            sock.bind(('', source_port))
            
            port = random.choice([3306, 5432, 27017])  # MySQL, PostgreSQL, MongoDB
            
            try:
                sock.connect((dst_ip, port))
                
                # Simulate queries
                num_queries = random.randint(5, 30)
                for _ in range(num_queries):
                    query_size = random.randint(100, 500)
                    query = bytes([random.randint(0, 255) for _ in range(query_size)])
                    sock.send(query)
                    self.stats['bytes'] += query_size
                    self.stats['packets'] += 1
                    
                    # Response
                    response_size = random.randint(200, 2000)
                    response = bytes([random.randint(0, 255) for _ in range(response_size)])
                    sock.send(response)
                    self.stats['bytes'] += response_size
                    self.stats['packets'] += 1
                    
                    time.sleep(random.uniform(0.01, 0.05))
            except:
                pass
            finally:
                sock.close()
                self.stats['flows'] += 1
        except:
            pass
    
    def generate_icmp_ping(self, dst_ip):
        """Simulate ICMP ping (using UDP as simulation)"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            source_port = random.randint(10000, 65000)
            sock.bind(('', source_port))
            
            # Simulate ping packets
            num_pings = random.randint(5, 20)
            for _ in range(num_pings):
                ping = bytes([random.randint(0, 255) for _ in range(64)])
                sock.sendto(ping, (dst_ip, 0))
                self.stats['bytes'] += 64
                self.stats['packets'] += 1
                time.sleep(random.uniform(0.1, 1.0))
            
            sock.close()
            self.stats['flows'] += 1
        except:
            pass
    
    def run_attack(self, duration):
        """Generate mixed normal traffic"""
        self.active = True
        start_time = time.time()
        flow_interval = 1.0 / self.rate if self.rate > 0 else 0.001
        
        print(f"[NORMAL] Starting normal traffic generation")
        print(f"  Rate: {self.rate} flows/sec")
        print(f"  Duration: {duration}s")
        
        traffic_types = [
            (self.generate_web_traffic, 0.40, True),   # 40% web, needs 2 IPs
            (self.generate_dns_traffic, 0.15, False),   # 15% DNS
            (self.generate_ssh_traffic, 0.10, False),   # 10% SSH
            (self.generate_video_streaming, 0.15, False),  # 15% video
            (self.generate_database_traffic, 0.10, False), # 10% DB
            (self.generate_icmp_ping, 0.10, False)      # 10% ICMP
        ]
        
        # Normalize probabilities
        total_prob = sum(p for _, p, _ in traffic_types)
        traffic_types = [(f, p/total_prob, needs_two) for f, p, needs_two in traffic_types]
        
        while self.active and (time.time() - start_time) < duration:
            # Select traffic type
            rand = random.random()
            cumulative = 0
            selected_func = traffic_types[0][0]
            needs_two_ips = traffic_types[0][2]
            
            for func, prob, needs_two in traffic_types:
                cumulative += prob
                if rand <= cumulative:
                    selected_func = func
                    needs_two_ips = needs_two
                    break
            
            # Select IPs
            if needs_two_ips:
                src_ip = random.choice(ALL_HOSTS)
                dst_ip = random.choice([ip for ip in ALL_HOSTS if ip != src_ip])
                selected_func(src_ip, dst_ip)
            else:
                dst_ip = random.choice(ALL_HOSTS)
                selected_func(dst_ip)
            
            time.sleep(flow_interval)
            
            if int(time.time() - start_time) % 15 == 0 and self.stats['flows'] > 0:
                elapsed = time.time() - start_time
                print(f"[NORMAL] {elapsed:.0f}s - Flows: {self.stats['flows']:,}, "
                      f"Rate: {self.stats['flows']/elapsed:.1f} flows/s")
        
        self.active = False
        total_time = time.time() - start_time
        print(f"\n[NORMAL] Traffic Generation Complete:")
        print(f"  Total flows:  {self.stats['flows']:,}")
        print(f"  Total pkts:   {self.stats['packets']:,}")
        print(f"  Total bytes:  {self.stats['bytes']:,}")
        print(f"  Avg rate:     {self.stats['flows']/total_time:.1f} flows/s")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Normal Traffic Generator')
    parser.add_argument('--duration', type=int, default=300,
                        help='Traffic generation duration (seconds)')
    parser.add_argument('--rate', type=int, default=3000,
                        help='Flows per second (default: 3000)')
    
    args = parser.parse_args()
    
    gen = NormalTrafficGenerator(rate=args.rate)
    gen.run_attack(args.duration)
