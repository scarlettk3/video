#!/bin/bash
#
# PCAP Capture & CICFlowMeter Conversion Script
# ==============================================
# Captures traffic and converts to CSV using CICFlowMeter
#
# Prerequisites:
#   - tcpdump installed
#   - CICFlowMeter installed (or use nfstream as alternative)
#   - Run with sudo for packet capture
#
# Usage:
#   sudo bash capture_and_convert.sh [duration] [interface] [label]
#   
#   Example:
#   sudo bash capture_and_convert.sh 300 any normal
#   sudo bash capture_and_convert.sh 300 any traditional_lfa

set -e

DURATION="${1:-300}"
INTERFACE="${2:-any}"
LABEL="${3:-unknown}"
OUTPUT_DIR="$(pwd)/pcap_captures"
PCAP_FILE="${OUTPUT_DIR}/${LABEL}_$(date +%Y%m%d_%H%M%S).pcap"
CSV_FILE="${OUTPUT_DIR}/${LABEL}_$(date +%Y%m%d_%H%M%S).csv"

# Create output directory
mkdir -p "$OUTPUT_DIR"

echo "=================================================================="
echo "  Traffic Capture for CICFlowMeter"
echo "=================================================================="
echo "  Duration:   ${DURATION}s"
echo "  Interface:  $INTERFACE"
echo "  Label:      $LABEL"
echo "  PCAP file:  $PCAP_FILE"
echo "  CSV file:   $CSV_FILE"
echo "=================================================================="

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo "Error: This script must be run as root (for tcpdump)" 
   exit 1
fi

# Step 1: Capture packets
echo ""
echo "[Step 1/3] Capturing packets for ${DURATION} seconds..."
timeout "$DURATION" tcpdump -i "$INTERFACE" \
    -w "$PCAP_FILE" \
    -s 65535 \
    'tcp or udp or icmp' 2>&1 | \
    grep -v "listening on" || true

# Check if PCAP was created
if [[ ! -f "$PCAP_FILE" ]]; then
    echo "Error: PCAP file not created"
    exit 1
fi

PCAP_SIZE=$(du -h "$PCAP_FILE" | cut -f1)
echo "PCAP file created: $PCAP_FILE ($PCAP_SIZE)"

# Step 2: Convert to CSV using CICFlowMeter or alternative
echo ""
echo "[Step 2/3] Converting PCAP to CSV..."

# Method 1: Try CICFlowMeter (if installed)
if command -v cfm &> /dev/null; then
    echo "Using CICFlowMeter..."
    cfm "$PCAP_FILE" "$OUTPUT_DIR"
    
    # Find generated CSV
    GENERATED_CSV=$(find "$OUTPUT_DIR" -name "*.csv" -newer "$PCAP_FILE" | head -1)
    if [[ -n "$GENERATED_CSV" ]]; then
        mv "$GENERATED_CSV" "$CSV_FILE"
    fi

# Method 2: Try nfstream (Python alternative)
elif python3 -c "import nfstream" 2>/dev/null; then
    echo "Using nfstream (Python)..."
    python3 << EOF
from nfstream import NFStreamer
import pandas as pd

# Process PCAP
streamer = NFStreamer(source="$PCAP_FILE", statistical_analysis=True)
flows = []

for flow in streamer:
    flows.append({
        'src_ip': flow.src_ip,
        'dst_ip': flow.dst_ip,
        'src_port': flow.src_port,
        'dst_port': flow.dst_port,
        'protocol': flow.protocol,
        'bidirectional_duration_ms': flow.bidirectional_duration_ms,
        'bidirectional_packets': flow.bidirectional_packets,
        'bidirectional_bytes': flow.bidirectional_bytes,
        'src2dst_packets': flow.src2dst_packets,
        'src2dst_bytes': flow.src2dst_bytes,
        'dst2src_packets': flow.dst2src_packets,
        'dst2src_bytes': flow.dst2src_bytes,
        'bidirectional_mean_ps': flow.bidirectional_mean_ps,
        'bidirectional_stddev_ps': flow.bidirectional_stddev_ps,
        'src2dst_mean_ps': flow.src2dst_mean_ps,
        'dst2src_mean_ps': flow.dst2src_mean_ps,
        'bidirectional_mean_piat_ms': flow.bidirectional_mean_piat_ms,
        'bidirectional_stddev_piat_ms': flow.bidirectional_stddev_piat_ms,
        'src2dst_mean_piat_ms': flow.src2dst_mean_piat_ms,
        'dst2src_mean_piat_ms': flow.dst2src_mean_piat_ms,
        'label': '$LABEL'
    })

df = pd.DataFrame(flows)
df.to_csv('$CSV_FILE', index=False)
print(f"Converted {len(flows)} flows to CSV")
EOF

# Method 3: Basic tshark conversion
elif command -v tshark &> /dev/null; then
    echo "Using tshark (basic conversion)..."
    tshark -r "$PCAP_FILE" -T fields \
        -e frame.time_epoch \
        -e ip.src \
        -e ip.dst \
        -e tcp.srcport -e udp.srcport \
        -e tcp.dstport -e udp.dstport \
        -e ip.proto \
        -e frame.len \
        -E header=y \
        -E separator=, \
        -E quote=d > "${CSV_FILE}.tmp"
    
    # Add label column
    echo "timestamp,src_ip,dst_ip,src_port_tcp,src_port_udp,dst_port_tcp,dst_port_udp,protocol,frame_length,label" > "$CSV_FILE"
    tail -n +2 "${CSV_FILE}.tmp" | awk -v label="$LABEL" '{print $0","label}' >> "$CSV_FILE"
    rm "${CSV_FILE}.tmp"
else
    echo "Error: No flow extraction tool found"
    echo "Please install one of: CICFlowMeter, nfstream (pip3 install nfstream), or tshark"
    exit 1
fi

# Step 3: Verify CSV
echo ""
echo "[Step 3/3] Verifying CSV output..."

if [[ -f "$CSV_FILE" ]]; then
    NUM_FLOWS=$(tail -n +2 "$CSV_FILE" | wc -l)
    CSV_SIZE=$(du -h "$CSV_FILE" | cut -f1)
    
    echo "✓ CSV file created: $CSV_FILE"
    echo "  - Size: $CSV_SIZE"
    echo "  - Flows: $NUM_FLOWS"
    
    # Show first few lines
    echo ""
    echo "Sample (first 3 flows):"
    head -n 4 "$CSV_FILE"
else
    echo "Warning: CSV file not created"
    exit 1
fi

echo ""
echo "=================================================================="
echo "  Capture Complete"
echo "=================================================================="
echo "  PCAP: $PCAP_FILE ($PCAP_SIZE)"
echo "  CSV:  $CSV_FILE ($CSV_SIZE, $NUM_FLOWS flows)"
echo "=================================================================="
