"""
network/topology.py — Mininet topology definitions for the LFA experiment.

Provides:
  - FatTreeTopo: k=4 fat-tree (baseline experiment topology)
  - LinearTopo:  n-switch linear chain (generalization test)
  - RingTopo:    n-switch ring (generalization test)
  - build_network(): creates and returns a Mininet object ready to start

The user can select a topology variant in config.py or pass it as a CLI arg
to run_experiment.py.
"""

import sys
from mininet.net import Mininet
from mininet.node import RemoteController, OVSKernelSwitch
from mininet.link import TCLink
from mininet.log import setLogLevel, info
from mininet.topo import Topo

from realtime_framework.config import (
    CONTROLLER_IP, CONTROLLER_PORT, OF_VERSION,
    TOPO_K, TOPO_BW_HOST, TOPO_BW_EDGE, TOPO_BW_AGG,
    TOPO_BW_CORE, TOPO_BOTTLENECK_BW,
)


# ---------------------------------------------------------------------------
# Fat-Tree k=4
# ---------------------------------------------------------------------------

class FatTreeTopo(Topo):
    """
    Fat-tree topology with configurable k (default k=4 → 16 hosts, 20 switches).
    Bottleneck link is placed between first aggregate (a1) and first edge (e1)
    to serve as the LFA congestion target.
    """

    def __init__(self, k=TOPO_K, bw_host=TOPO_BW_HOST, bw_edge=TOPO_BW_EDGE,
                 bw_agg=TOPO_BW_AGG, bw_core=TOPO_BW_CORE,
                 bottleneck_bw=TOPO_BOTTLENECK_BW, **opts):
        self.k   = k
        self.bw_host       = bw_host
        self.bw_edge       = bw_edge
        self.bw_agg        = bw_agg
        self.bw_core       = bw_core
        self.bottleneck_bw = bottleneck_bw
        super().__init__(**opts)

    def build(self):
        k      = self.k
        half_k = k // 2

        # Core switches
        core = [
            self.addSwitch(f"c{i+1}", cls=OVSKernelSwitch,
                           protocols=OF_VERSION)
            for i in range(half_k ** 2)
        ]

        host_count = 1
        agg_list, edge_list = [], []

        for pod in range(k):
            # Aggregate layer
            agg_in_pod = []
            for a in range(half_k):
                sw = self.addSwitch(f"a{pod * half_k + a + 1}",
                                    cls=OVSKernelSwitch, protocols=OF_VERSION)
                agg_in_pod.append(sw)
                # Connect aggregate to core switches
                # Aggregate switch a(pod, a) connects to core block a
                for j in range(half_k):
                    core_idx = a * half_k + j
                    self.addLink(sw, core[core_idx],
                                 bw=self.bw_agg, cls=TCLink)
            agg_list.extend(agg_in_pod)

            # Edge layer
            edge_in_pod = []
            for e in range(half_k):
                sw = self.addSwitch(f"e{pod * half_k + e + 1}",
                                    cls=OVSKernelSwitch, protocols=OF_VERSION)
                edge_in_pod.append(sw)

                # Connect edge to each aggregate in the same pod
                for a_sw in agg_in_pod:
                    is_bottleneck = (
                        sw == edge_in_pod[0] and a_sw == agg_in_pod[0]
                        and pod == 0
                    )
                    bw = self.bottleneck_bw if is_bottleneck else self.bw_edge
                    self.addLink(sw, a_sw, bw=bw, cls=TCLink)

                # Add k/2 hosts per edge switch
                for h in range(half_k):
                    host = self.addHost(f"h{host_count}",
                                        ip=f"10.{pod}.{e}.{h+1}/24")
                    self.addLink(host, sw, bw=self.bw_host, cls=TCLink)
                    host_count += 1
            edge_list.extend(edge_in_pod)


# ---------------------------------------------------------------------------
# Linear topology (generalization test)
# ---------------------------------------------------------------------------

class LinearTopo(Topo):
    """
    n-switch linear chain: h1—s1—s2—…—sn—hn.
    Bottleneck is the middle link (s_{n//2} ↔ s_{n//2+1}).
    """

    def __init__(self, n=6, bw_link=100, bottleneck_bw=10, **opts):
        self.n             = n
        self.bw_link       = bw_link
        self.bottleneck_bw = bottleneck_bw
        super().__init__(**opts)

    def build(self):
        switches = [
            self.addSwitch(f"s{i+1}", cls=OVSKernelSwitch, protocols=OF_VERSION)
            for i in range(self.n)
        ]
        mid = self.n // 2
        for i in range(self.n - 1):
            bw = self.bottleneck_bw if i == mid - 1 else self.bw_link
            self.addLink(switches[i], switches[i + 1], bw=bw, cls=TCLink)

        for i, sw in enumerate(switches):
            h = self.addHost(f"h{i+1}", ip=f"10.0.0.{i+1}/24")
            self.addLink(h, sw, bw=self.bw_link, cls=TCLink)


# ---------------------------------------------------------------------------
# Ring topology (generalization test)
# ---------------------------------------------------------------------------

class RingTopo(Topo):
    """
    n-switch ring: s1—s2—…—sn—s1.
    One link is the bottleneck (s1 ↔ s2 by default).
    """

    def __init__(self, n=6, bw_link=100, bottleneck_bw=10, **opts):
        self.n             = n
        self.bw_link       = bw_link
        self.bottleneck_bw = bottleneck_bw
        super().__init__(**opts)

    def build(self):
        switches = [
            self.addSwitch(f"r{i+1}", cls=OVSKernelSwitch, protocols=OF_VERSION)
            for i in range(self.n)
        ]
        for i in range(self.n):
            bw = self.bottleneck_bw if i == 0 else self.bw_link
            self.addLink(switches[i], switches[(i + 1) % self.n], bw=bw, cls=TCLink)

        for i, sw in enumerate(switches):
            h = self.addHost(f"h{i+1}", ip=f"10.0.1.{i+1}/24")
            self.addLink(h, sw, bw=self.bw_link, cls=TCLink)


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

TOPOLOGY_MAP = {
    "fat_tree": FatTreeTopo,
    "linear":   LinearTopo,
    "ring":     RingTopo,
}


def build_network(topo_name: str = "fat_tree", **topo_kwargs) -> Mininet:
    """
    Create and return a configured Mininet network (not yet started).

    Args:
        topo_name: "fat_tree" | "linear" | "ring"
        **topo_kwargs: forwarded to the topology constructor

    Returns:
        Mininet object — call net.start() to begin.
    """
    setLogLevel("info")
    topo_cls = TOPOLOGY_MAP.get(topo_name, FatTreeTopo)
    topo = topo_cls(**topo_kwargs)

    net = Mininet(
        topo=topo,
        controller=RemoteController("c0", ip=CONTROLLER_IP, port=CONTROLLER_PORT),
        link=TCLink,
        switch=OVSKernelSwitch,
        autoSetMacs=True,
        build=False,
    )
    return net
