"""
experiment_manager.py — Ground Truth Logger and Experiment Scenario Sequencer.

Responsibilities:
  1. Record ground-truth events (attack start/end, scenario transitions, target
     link, generator mode) to a JSONL file.  Ground truth is NEVER provided to
     the Detection Agent — it is used only for evaluation / plotting.

  2. Sequence the experiment through the configured scenarios (benign → LFA →
     benign → adaptive → ...).

  3. Drive Agent 1's bandit feedback loop: after each detection window,
     retrieve detection_confidence from SharedState and call
     generation_agent.receive_reward().

  4. Coordinate traffic generation start/stop with scenario transitions.
"""

import json
import threading
import time
from pathlib import Path
from typing import List, Optional, Tuple

from realtime_framework.config import (
    GROUND_TRUTH_LOG, RESULTS_DIR,
    SCENARIO_BENIGN, SCENARIO_CONV_LFA, SCENARIO_GAN_LFA, SCENARIO_ADAPTIVE_LFA,
    DEFAULT_EXPERIMENT_SEQUENCE, BENIGN_FLOWS, CONV_LFA_FLOWS,
    LFA_ATTACKER_HOSTS, LFA_TARGET_HOST,
)
from realtime_framework.shared_state import STATE
from realtime_framework.agents.generation_agent import get_generation_agent
from realtime_framework.traffic.profile_translator import (
    TrafficProfile, translate, conventional_lfa_profile,
)
from realtime_framework.utils.logger import log_event, log_info, log_warn

GT_LOG_PATH = Path(GROUND_TRUTH_LOG)
GT_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)


class ExperimentManager:
    """
    Orchestrates the experiment sequence and logs all ground-truth events.

    Usage:
        net   = Mininet(...)       # started topology
        tgen  = TrafficGenerator(net)
        mgr   = ExperimentManager(tgen)
        mgr.run(sequence=DEFAULT_EXPERIMENT_SEQUENCE)
    """

    def __init__(self, traffic_generator, net=None):
        self._tgen  = traffic_generator
        self._net   = net
        self._gt_fh = open(GT_LOG_PATH, "a", buffering=1)
        self._gt_lock = threading.Lock()

        self._gen_agent   = get_generation_agent()
        self._stop_event  = threading.Event()
        self._feedback_thread: Optional[threading.Thread] = None

    # ------------------------------------------------------------------ #
    # Ground-truth logging (separate from detector inputs)                 #
    # ------------------------------------------------------------------ #

    def _log_gt(self, event: str, **kwargs) -> None:
        """Write a ground-truth record.  Never read by the Detection Agent."""
        record = {"gt_event": event, "ts": time.time(), **kwargs}
        with self._gt_lock:
            self._gt_fh.write(json.dumps(record) + "\n")
        log_event(f"gt:{event}", **kwargs)

    # ------------------------------------------------------------------ #
    # Main sequence driver                                                 #
    # ------------------------------------------------------------------ #

    def run(
        self,
        sequence: List[Tuple[str, int]] = None,
    ) -> None:
        """
        Run the experiment sequence.  Blocks until all scenarios complete.

        sequence: list of (scenario_name, duration_seconds)
        """
        seq = sequence or DEFAULT_EXPERIMENT_SEQUENCE
        STATE.start_experiment()

        # Start bandit feedback loop in background thread
        self._feedback_thread = threading.Thread(
            target=self._feedback_loop, daemon=True
        )
        self._feedback_thread.start()

        self._log_gt("experiment_start",
                     sequence=[(s, d) for s, d in seq],
                     n_scenarios=len(seq))

        for scenario, duration_sec in seq:
            if self._stop_event.is_set():
                break
            self._run_scenario(scenario, duration_sec)

        self._stop_event.set()
        STATE.stop_experiment()
        self._tgen.stop_all()

        with self._gt_lock:
            self._gt_fh.flush()
            self._gt_fh.close()

        self._log_gt("experiment_end")
        log_info("[ExperimentManager] Experiment complete.")

    def stop(self) -> None:
        """Signal early termination."""
        self._stop_event.set()

    # ------------------------------------------------------------------ #
    # Scenario runners                                                     #
    # ------------------------------------------------------------------ #

    def _run_scenario(self, scenario: str, duration_sec: int) -> None:
        STATE.set_scenario(scenario)
        self._log_gt(
            "scenario_start",
            scenario=scenario,
            duration_sec=duration_sec,
            target_link=list(from_realtime_framework_config_lfa_target_link()),
        )
        log_info(f"[ExperimentManager] Scenario: {scenario} ({duration_sec}s)")

        if scenario == SCENARIO_BENIGN:
            self._run_benign(duration_sec)

        elif scenario == SCENARIO_CONV_LFA:
            self._run_conventional_lfa(duration_sec)

        elif scenario == SCENARIO_GAN_LFA:
            self._run_gan_lfa(duration_sec)

        elif scenario == SCENARIO_ADAPTIVE_LFA:
            self._run_adaptive_lfa(duration_sec)

        else:
            log_warn(f"Unknown scenario: {scenario} — treating as benign.")
            self._run_benign(duration_sec)

        self._log_gt("scenario_end", scenario=scenario)

    # -- Benign -------------------------------------------------------

    def _run_benign(self, duration_sec: int) -> None:
        self._tgen.stop_lfa()
        self._tgen.start_benign(BENIGN_FLOWS, duration_sec=duration_sec)
        self._log_gt("benign_traffic_started", n_flows=len(BENIGN_FLOWS))
        self._wait(duration_sec)
        self._tgen.stop_benign()

    # -- Conventional LFA ---------------------------------------------

    def _run_conventional_lfa(self, duration_sec: int) -> None:
        """Direct iperf UDP flood — no GAN involved."""
        profile = conventional_lfa_profile(duration_sec=duration_sec)
        self._tgen.start_benign(BENIGN_FLOWS, duration_sec=duration_sec)
        self._tgen.start_lfa(profile)
        self._log_gt(
            "attack_start",
            attack_type="conventional_lfa",
            n_attacker_flows=profile.n_flows,
            rate_kbps=profile.rate_kbps,
            target=profile.dst_host,
        )
        self._wait(duration_sec)
        self._tgen.stop_lfa()
        self._log_gt("attack_stop", attack_type="conventional_lfa")

    # -- GAN-generated LFA -------------------------------------------

    def _run_gan_lfa(self, duration_sec: int) -> None:
        """GAN generates LFA profile; bandit uses fixed arm (converged strength)."""
        _, evasion = self._gen_agent.bandit.converged_arm()
        self._run_lfa_loop(duration_sec, adaptive=False, evasion=evasion)

    # -- Adaptive AI-generated LFA -----------------------------------

    def _run_adaptive_lfa(self, duration_sec: int) -> None:
        """Bandit actively adapts evasion mode based on detection confidence."""
        self._run_lfa_loop(duration_sec, adaptive=True, evasion=None)

    # -- Shared LFA loop ----------------------------------------------

    def _run_lfa_loop(
        self,
        duration_sec: int,
        adaptive: bool,
        evasion: Optional[float],
    ) -> None:
        """
        Main LFA generation loop.
        Every BANDIT_ROUND_SEC seconds:
          1. Bandit selects evasion mode (if adaptive=True)
          2. GAN generates feature profile
          3. Profile translated to traffic parameters
          4. Traffic spawned in Mininet
          (Bandit reward is handled by _feedback_loop thread)
        """
        from realtime_framework.config import STATS_POLL_INTERVAL
        BANDIT_ROUND_SEC = max(STATS_POLL_INTERVAL * 3, 6.0)

        self._tgen.start_benign(BENIGN_FLOWS, duration_sec=duration_sec)
        self._log_gt(
            "attack_start",
            attack_type="adaptive_lfa" if adaptive else "gan_lfa",
            adaptive=adaptive,
        )

        start_ts  = time.time()
        round_num = 0
        from realtime_framework.feature_extraction.preprocessor import get_feature_columns
        feat_cols = get_feature_columns()

        while not self._stop_event.is_set():
            elapsed = time.time() - start_ts
            if elapsed >= duration_sec:
                break

            round_num += 1
            round_start = time.time()

            # 1. Bandit selects evasion mode
            if adaptive:
                arm_idx, evasion_strength = self._gen_agent.select_evasion_mode()
            else:
                arm_idx = 0
                evasion_strength = evasion or 0.0
                STATE.set_evasion_strength(evasion_strength)

            # 2. GAN generates feature profile
            ts_gen_decision = time.time()
            batch = self._gen_agent.generate(
                batch_size=4, evasion_strength=evasion_strength
            )
            ts_gen_done = time.time()

            # 3. Translate first sample to traffic parameters
            sample_vec = batch[0]
            from realtime_framework.traffic.profile_translator import set_feature_index
            if feat_cols:
                set_feature_index(feat_cols)
            profile = translate(sample_vec, evasion_strength=evasion_strength)

            # 4. Launch traffic
            ts_traffic_start = time.time()
            self._tgen.start_lfa(profile)

            self._log_gt(
                "generation_round",
                round=round_num,
                adaptive=adaptive,
                arm=arm_idx,
                evasion_strength=round(evasion_strength, 3),
                ts_gen_decision=ts_gen_decision,
                ts_traffic_start=ts_traffic_start,
                profile_n_flows=profile.n_flows,
                profile_rate_kbps=profile.rate_kbps,
                profile_protocol=profile.protocol,
            )

            # Wait for one bandit round, then repeat
            remaining_in_round = BANDIT_ROUND_SEC - (time.time() - round_start)
            if remaining_in_round > 0:
                self._wait(remaining_in_round)

        self._tgen.stop_lfa()
        self._log_gt("attack_stop")

    # ------------------------------------------------------------------ #
    # Bandit feedback thread                                               #
    # ------------------------------------------------------------------ #

    def _feedback_loop(self) -> None:
        """
        Continuously reads detection_confidence from SharedState and feeds
        it back to the generation agent's bandit.  Runs every detection window.
        """
        from realtime_framework.config import DETECTION_WINDOW_SEC
        last_window = 0

        while not self._stop_event.is_set():
            time.sleep(DETECTION_WINDOW_SEC)
            scenario = STATE.get_scenario()
            if scenario == SCENARIO_BENIGN:
                continue

            conf = STATE.get_detection_confidence()
            self._gen_agent.receive_reward(conf)

            self._log_gt(
                "bandit_feedback",
                scenario=scenario,
                detection_confidence=round(conf, 4),
                evasion_strength=STATE.get_evasion_strength(),
            )

    # ------------------------------------------------------------------ #
    # Helper                                                               #
    # ------------------------------------------------------------------ #

    def _wait(self, seconds: float) -> None:
        """Sleep with stop-event check every second."""
        end = time.time() + seconds
        while not self._stop_event.is_set() and time.time() < end:
            time.sleep(min(1.0, end - time.time()))


def from_realtime_framework_config_lfa_target_link():
    from realtime_framework.config import LFA_TARGET_LINK
    return LFA_TARGET_LINK
