"""
ryu_app/lfa_controller.py — Real-time LFA detection and mitigation Ryu controller.

This is the central real-time component.  It runs as a Ryu application and:

  1. STATS COLLECTION  — polls OpenFlow port/flow stats every STATS_POLL_INTERVAL
     seconds from all connected switches.

  2. FEATURE EXTRACTION — converts accumulated FlowTable records into the same
     feature vector the ENAS+GAN model was trained on (same preprocessor.pkl).

  3. DETECTION          — runs the frozen ENAS+GAN classifier on each window.
     Publishes pred_prob to SharedState (read by the generation agent's bandit).

  4. MITIGATION         — if ATTACK is detected, the DQN selects an action and
     this controller installs the corresponding OpenFlow rule.

  5. REST API           — exposes /lfa/status, /lfa/stats, /lfa/metrics for
     the experiment manager and external monitoring.

Launch command:
    ryu-manager realtime_framework/ryu_app/lfa_controller.py \
        --observe-links --ofp-tcp-listen-port 6633

All inter-agent communication goes through shared_state.py.
No ground-truth information is passed to the detector.
"""

import json
import os
import sys
import time
import threading
from collections import defaultdict

# Ensure the project root is on PYTHONPATH when Ryu loads this as a module
_HERE = os.path.dirname(os.path.abspath(__file__))
_PROJ = os.path.dirname(os.path.dirname(_HERE))
if _PROJ not in sys.path:
    sys.path.insert(0, _PROJ)

from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import (
    CONFIG_DISPATCHER, MAIN_DISPATCHER, DEAD_DISPATCHER, set_ev_cls,
)
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet, ethernet, ipv4, tcp, udp, arp
from ryu.lib import hub
from ryu.topology import event as topo_event
from ryu.topology.api import get_switch, get_link
from ryu.app.wsgi import WSGIApplication, ControllerBase, route
from webob import Response

from realtime_framework.config import (
    STATS_POLL_INTERVAL, DETECTION_WINDOW_SEC, MIN_FLOWS_PER_WINDOW,
    ACTION_ALLOW, ACTION_MONITOR, ACTION_RATE_LIMIT, ACTION_BLOCK, ACTION_REROUTE,
    RATE_LIMIT_KBPS,
)
from realtime_framework.shared_state import STATE, StatsBundle
from realtime_framework.feature_extraction.flow_record import FlowTable
from realtime_framework.feature_extraction.extractor import extract_features
from realtime_framework.feature_extraction.preprocessor import (
    load_preprocessor, feature_dim,
)
from realtime_framework.agents.detection_agent import get_detection_agent
from realtime_framework.agents.mitigation_agent import get_mitigation_agent
from realtime_framework.evaluation.latency_tracker import get_latency_tracker
from realtime_framework.utils.logger import log_info, log_warn, log_event

REST_API_NAME = "lfa_rt_api"


class LFARealTimeController(app_manager.RyuApp):
    """
    Main Ryu controller for real-time LFA detection and mitigation.
    """

    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]
    _CONTEXTS = {"wsgi": WSGIApplication}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # MAC learning: {dpid: {mac: port}}
        self.mac_to_port = defaultdict(dict)

        # Flow table per switch: {dpid: FlowTable}
        self.flow_tables: dict = defaultdict(lambda: FlowTable(idle_timeout_sec=10.0))

        # Port stats for link utilization monitoring: {dpid: {port: {rx,tx bytes}}}
        self.port_stats   = defaultdict(dict)
        self.prev_port_stats = defaultdict(dict)

        # Active mitigation rules: {dpid: [flow_mod cookie, ...]}
        self.mitigation_rules: dict = defaultdict(list)

        # Meter IDs allocated: {dpid: next_meter_id}
        self._next_meter_id: dict = defaultdict(lambda: 1)

        # Detection window counter
        self._window_count = 0

        # Load preprocessor and models eagerly (before first window arrives)
        load_preprocessor()
        self._detector   = get_detection_agent()
        self._mitigator  = get_mitigation_agent()
        self._lat_tracker = get_latency_tracker()

        # Register REST API
        wsgi = kwargs["wsgi"]
        wsgi.register(LFARestAPI, {REST_API_NAME: self})

        # Start the monitoring loop (Ryu hub greenlet)
        self._monitor_thread = hub.spawn(self._monitor_loop)
        # Start the inference pipeline in a real OS thread (avoids GIL contention)
        self._pipeline_thread = threading.Thread(
            target=self._inference_pipeline_loop, daemon=True
        )
        self._pipeline_thread.start()

        log_info("[LFARealTimeController] Started. Waiting for switch connections.")

    # =========================================================================
    # OpenFlow event handlers
    # =========================================================================

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        dp     = ev.msg.datapath
        ofproto = dp.ofproto
        parser  = dp.ofproto_parser

        log_event("switch_connected", dpid=dp.id)

        # Delete existing flows
        self._del_all_flows(dp)

        # Table-miss: send to controller
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER,
                                          ofproto.OFPCML_NO_BUFFER)]
        self._add_flow(dp, 0, match, actions)

        # ARP: broadcast
        match_arp = parser.OFPMatch(eth_type=0x0806)
        actions_arp = [parser.OFPActionOutput(ofproto.OFPP_FLOOD)]
        self._add_flow(dp, 1, match_arp, actions_arp)

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def packet_in_handler(self, ev):
        """MAC learning + basic L2/L3 forwarding."""
        msg    = ev.msg
        dp     = msg.datapath
        ofproto= dp.ofproto
        parser = dp.ofproto_parser
        in_port= msg.match["in_port"]

        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocol(ethernet.ethernet)
        if eth is None:
            return

        dst = eth.dst
        src = eth.src
        dpid = dp.id

        self.mac_to_port[dpid][src] = in_port

        out_port = (self.mac_to_port[dpid].get(dst, ofproto.OFPP_FLOOD))

        actions = [parser.OFPActionOutput(out_port)]

        # Install a flow entry to avoid future packet-in for this pair
        if out_port != ofproto.OFPP_FLOOD:
            ip4 = pkt.get_protocol(ipv4.ipv4)
            if ip4:
                match = parser.OFPMatch(
                    in_port=in_port,
                    eth_type=0x0800,
                    ipv4_src=ip4.src,
                    ipv4_dst=ip4.dst,
                )
                if msg.buffer_id != ofproto.OFP_NO_BUFFER:
                    self._add_flow(dp, 10, match, actions, buffer_id=msg.buffer_id)
                    return
                else:
                    self._add_flow(dp, 10, match, actions)
            else:
                match = parser.OFPMatch(in_port=in_port, eth_dst=dst)
                self._add_flow(dp, 5, match, actions)

        data = msg.data if msg.buffer_id == ofproto.OFP_NO_BUFFER else None
        out = parser.OFPPacketOut(
            datapath=dp, buffer_id=msg.buffer_id,
            in_port=in_port, actions=actions, data=data,
        )
        dp.send_msg(out)

    # ── Flow stats reply ──────────────────────────────────────────────────

    @set_ev_cls(ofp_event.EventOFPFlowStatsReply, MAIN_DISPATCHER)
    def flow_stats_reply_handler(self, ev):
        ts  = time.time()
        dp  = ev.msg.datapath
        dpid = dp.id
        ft  = self.flow_tables[dpid]

        stats_arrival_ts = ts

        for stat in ev.msg.body:
            m = stat.match
            entry = {
                "proto":        m.get("ip_proto",   6),
                "ip_src":       m.get("ipv4_src", "0.0.0.0"),
                "ip_dst":       m.get("ipv4_dst", "0.0.0.0"),
                "port_src":     m.get("tcp_src",   m.get("udp_src", 0)),
                "port_dst":     m.get("tcp_dst",   m.get("udp_dst", 0)),
                "eth_type":     m.get("eth_type",  2048),
                "vlan_id":      m.get("vlan_vid",  0),
                "packet_count": stat.packet_count,
                "byte_count":   stat.byte_count,
                "duration_sec": stat.duration_sec,
                "duration_nsec":stat.duration_nsec,
            }
            ft.update(entry)

        # Post bundle to shared queue for the pipeline thread
        bundle = StatsBundle(
            dpid=dpid,
            timestamp=stats_arrival_ts,
            port_stats=[],
            flow_stats=[],
        )
        STATE.post_stats(bundle)
        self._lat_tracker.record("stats_arrival", dpid=dpid, ts=stats_arrival_ts)

    # ── Port stats reply ──────────────────────────────────────────────────

    @set_ev_cls(ofp_event.EventOFPPortStatsReply, MAIN_DISPATCHER)
    def port_stats_reply_handler(self, ev):
        dp   = ev.msg.datapath
        dpid = dp.id
        now  = time.time()
        for stat in ev.msg.body:
            self.port_stats[dpid][stat.port_no] = {
                "rx_bytes": stat.rx_bytes,
                "tx_bytes": stat.tx_bytes,
                "rx_pkts":  stat.rx_packets,
                "tx_pkts":  stat.tx_packets,
                "ts":       now,
            }

    # =========================================================================
    # Monitoring loop (Ryu hub greenlet — sends stat requests)
    # =========================================================================

    def _monitor_loop(self):
        """Poll all connected switches for flow and port stats periodically."""
        while True:
            hub.sleep(STATS_POLL_INTERVAL)
            for dp in self._get_datapaths():
                self._request_flow_stats(dp)
                self._request_port_stats(dp)

    def _get_datapaths(self):
        return [dp for dp in [
            app_manager.lookup_service_brick("ofp_event").datapath_list.get(dpid)
            for dpid in self.mac_to_port.keys()
        ] if dp is not None]

    def _request_flow_stats(self, dp):
        parser = dp.ofproto_parser
        req = parser.OFPFlowStatsRequest(dp)
        dp.send_msg(req)

    def _request_port_stats(self, dp):
        parser = dp.ofproto_parser
        ofproto = dp.ofproto
        req = parser.OFPPortStatsRequest(dp, 0, ofproto.OFPP_ANY)
        dp.send_msg(req)

    # =========================================================================
    # Inference pipeline (OS thread — runs Detection + Mitigation agents)
    # =========================================================================

    def _inference_pipeline_loop(self):
        """
        Continuously reads StatsBundle events, extracts features, runs the
        Detection Agent, and (if attack) invokes the DQN Mitigation Agent.
        This runs in a separate OS thread to avoid blocking Ryu's event loop.
        """
        import queue

        last_window_ts = time.time()

        while True:
            # Drain available stat bundles (non-blocking)
            try:
                STATE.stats_queue.get(timeout=DETECTION_WINDOW_SEC)
            except queue.Empty:
                pass

            # Trigger detection window if enough time has elapsed
            now = time.time()
            if now - last_window_ts < DETECTION_WINDOW_SEC:
                continue
            last_window_ts = now

            if not STATE.is_running():
                continue

            self._run_detection_window()

    def _run_detection_window(self):
        """Run one complete detection + mitigation cycle."""
        window_id  = STATE.next_window_id()
        lat        = self._lat_tracker
        feat_start = time.time()

        # Collect flow records from all switch FlowTables
        all_records = []
        for dpid, ft in self.flow_tables.items():
            all_records.extend(ft.snapshot())

        lat.record("feature_extract_start", window_id=window_id)

        if len(all_records) < MIN_FLOWS_PER_WINDOW:
            return

        # Feature extraction
        X = extract_features(all_records)
        feat_end = time.time()
        lat.record("feature_extract_end", window_id=window_id,
                   n_flows=len(all_records))

        if X is None or len(X) == 0:
            return

        # Detection
        lat.record("inference_start", window_id=window_id)
        det = self._detector.run_window(X, window_id)
        lat.record("inference_end", window_id=window_id,
                   pred_label=det["pred_label"],
                   mean_prob=det["mean_pred_prob"])

        mean_prob   = det["mean_pred_prob"]
        pred_label  = det["pred_label"]

        # Feed confidence back to the generation agent's bandit
        STATE.set_detection_confidence(mean_prob)

        # Congestion update (NORMAL flow → natural decay)
        is_malicious = pred_label == 1
        self._mitigator.update_congestion(ACTION_ALLOW, is_malicious)

        # Mitigation if attack detected
        if pred_label == 1:
            congestion    = self._mitigator.get_congestion()
            window_vec    = X.mean(axis=0)   # aggregate feature vector
            action, a_name = self._mitigator.select_action(
                mean_prob, window_vec, congestion
            )
            lat.record("mitigation_decision", window_id=window_id,
                       action=action, action_name=a_name)

            # Apply action to all connected switches
            for dpid in list(self.flow_tables.keys()):
                dp = self._lookup_datapath(dpid)
                if dp:
                    self._apply_mitigation(dp, action, all_records)

            # Update congestion after mitigation
            self._mitigator.update_congestion(action, is_malicious=True)
            lat.record("rule_installed", window_id=window_id)

            STATE.set_mitigation_action(action)

        lat.record("window_complete", window_id=window_id,
                   feature_latency_ms=(feat_end - feat_start) * 1000,
                   total_latency_ms=(time.time() - feat_start) * 1000)

    # =========================================================================
    # Mitigation rule installation
    # =========================================================================

    def _apply_mitigation(self, dp, action: int, flow_records: list) -> None:
        """Translate a DQN action into OpenFlow rule(s)."""
        if action == ACTION_ALLOW:
            return
        elif action == ACTION_MONITOR:
            self._install_monitoring_rule(dp, flow_records)
        elif action == ACTION_RATE_LIMIT:
            self._install_rate_limit(dp, flow_records)
        elif action == ACTION_BLOCK:
            self._install_drop_rules(dp, flow_records)
        elif action == ACTION_REROUTE:
            self._install_reroute_rules(dp, flow_records)

    def _install_drop_rules(self, dp, flow_records: list) -> None:
        """Install DROP rules for the top-probability suspicious flows."""
        parser  = dp.ofproto_parser
        ofproto = dp.ofproto

        # Target only flows predicted as ATTACK (heuristic: high bytps)
        top_records = sorted(
            flow_records,
            key=lambda r: r.get("bytps", 0),
            reverse=True,
        )[:10]

        for r in top_records:
            ip_src = r.get("ip_src", "")
            ip_dst = r.get("ip_dst", "")
            if not ip_src or ip_src == "0.0.0.0":
                continue
            try:
                match = parser.OFPMatch(
                    eth_type=0x0800,
                    ipv4_src=ip_src,
                    ipv4_dst=ip_dst,
                )
                self._add_flow(dp, 100, match, [],
                               idle_timeout=30, hard_timeout=60)
                log_event("rule_drop", dpid=dp.id, src=ip_src, dst=ip_dst)
            except Exception as exc:
                log_warn(f"Failed to install drop rule: {exc}")

    def _install_rate_limit(self, dp, flow_records: list) -> None:
        """Install meter-based rate-limiting rule (OpenFlow 1.3 meters)."""
        parser  = dp.ofproto_parser
        ofproto = dp.ofproto
        dpid    = dp.id

        meter_id = self._next_meter_id[dpid]
        self._next_meter_id[dpid] += 1

        rate_kbps = RATE_LIMIT_KBPS
        bands = [parser.OFPMeterBandDrop(rate=rate_kbps, burst_size=0)]
        meter_mod = parser.OFPMeterMod(
            datapath=dp,
            command=ofproto.OFPMC_ADD,
            flags=ofproto.OFPMF_KBPS,
            meter_id=meter_id,
            bands=bands,
        )
        dp.send_msg(meter_mod)

        # Apply meter to all ports (simplified)
        match = parser.OFPMatch(eth_type=0x0800)
        instructions = [
            parser.OFPInstructionMeter(meter_id),
            parser.OFPInstructionActions(
                ofproto.OFPIT_APPLY_ACTIONS,
                [parser.OFPActionOutput(ofproto.OFPP_NORMAL)],
            ),
        ]
        flow_mod = parser.OFPFlowMod(
            datapath=dp,
            priority=80,
            match=match,
            instructions=instructions,
            idle_timeout=60,
            hard_timeout=120,
        )
        dp.send_msg(flow_mod)
        log_event("rule_rate_limit", dpid=dpid, meter_id=meter_id,
                  rate_kbps=rate_kbps)

    def _install_monitoring_rule(self, dp, flow_records: list) -> None:
        """Install a high-priority match-and-continue rule for monitoring."""
        parser   = dp.ofproto_parser
        ofproto  = dp.ofproto
        match    = parser.OFPMatch(eth_type=0x0800)
        actions  = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER, 128)]
        self._add_flow(dp, 50, match, actions, idle_timeout=30)
        log_event("rule_monitor", dpid=dp.id)

    def _install_reroute_rules(self, dp, flow_records: list) -> None:
        """
        Reroute suspicious traffic to an alternate (less loaded) port.
        Uses OFPP_IN_PORT as a stub — replace with actual alternate port logic.
        """
        parser  = dp.ofproto_parser
        ofproto = dp.ofproto
        # Stub: in production, compute alternate_port from topology graph
        alternate_port = 2  # override with actual topology-aware routing
        match = parser.OFPMatch(eth_type=0x0800)
        actions = [parser.OFPActionOutput(alternate_port)]
        self._add_flow(dp, 90, match, actions, idle_timeout=60)
        log_event("rule_reroute", dpid=dp.id, out_port=alternate_port)

    # =========================================================================
    # OpenFlow flow-mod helpers
    # =========================================================================

    def _add_flow(self, dp, priority, match, actions,
                  idle_timeout=0, hard_timeout=0, buffer_id=None,
                  cookie: int = 0):
        ofproto = dp.ofproto
        parser  = dp.ofproto_parser
        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
        kwargs = dict(
            datapath=dp, priority=priority, match=match,
            instructions=inst, idle_timeout=idle_timeout,
            hard_timeout=hard_timeout, cookie=cookie,
        )
        if buffer_id is not None:
            kwargs["buffer_id"] = buffer_id
        dp.send_msg(parser.OFPFlowMod(**kwargs))

    def _del_all_flows(self, dp):
        parser  = dp.ofproto_parser
        ofproto = dp.ofproto
        match   = parser.OFPMatch()
        dp.send_msg(parser.OFPFlowMod(
            datapath=dp,
            command=ofproto.OFPFC_DELETE,
            out_port=ofproto.OFPP_ANY,
            out_group=ofproto.OFPG_ANY,
            match=match,
        ))

    def _lookup_datapath(self, dpid):
        """Retrieve a datapath object by dpid."""
        try:
            brick = app_manager.lookup_service_brick("ofp_event")
            return brick.datapath_list.get(dpid)
        except Exception:
            return None

    # =========================================================================
    # Public API for the experiment manager
    # =========================================================================

    def get_link_utilization(self) -> dict:
        """Return {dpid: {port: {rx_bps, tx_bps}}} snapshot."""
        util = {}
        for dpid, ports in self.port_stats.items():
            util[dpid] = {}
            prev = self.prev_port_stats.get(dpid, {})
            for port, cur in ports.items():
                p = prev.get(port, {})
                dt = cur["ts"] - p.get("ts", cur["ts"] - STATS_POLL_INTERVAL)
                if dt <= 0:
                    dt = STATS_POLL_INTERVAL
                rx_bps = (cur["rx_bytes"] - p.get("rx_bytes", 0)) * 8 / dt
                tx_bps = (cur["tx_bytes"] - p.get("tx_bytes", 0)) * 8 / dt
                util[dpid][port] = {"rx_bps": rx_bps, "tx_bps": tx_bps}
            self.prev_port_stats[dpid] = dict(ports)
        return util


# =============================================================================
# REST API
# =============================================================================

class LFARestAPI(ControllerBase):
    def __init__(self, req, link, data, **config):
        super().__init__(req, link, data, **config)
        self._ctrl: LFARealTimeController = data[REST_API_NAME]

    @route("lfa", "/lfa/status", methods=["GET"])
    def get_status(self, req, **kw):
        body = {
            "scenario":           STATE.get_scenario(),
            "is_running":         STATE.is_running(),
            "detection_conf":     STATE.get_detection_confidence(),
            "evasion_strength":   STATE.get_evasion_strength(),
            "congestion":         STATE.get_congestion(),
            "last_action":        STATE.get_mitigation_action(),
            "window_count":       STATE._window_id,
        }
        return Response(content_type="application/json",
                        body=json.dumps(body).encode())

    @route("lfa", "/lfa/utilization", methods=["GET"])
    def get_utilization(self, req, **kw):
        util = self._ctrl.get_link_utilization()
        return Response(content_type="application/json",
                        body=json.dumps(util, default=str).encode())
