"""
shared_state.py — Thread-safe shared state for inter-agent communication.

All agents (detection, generation, mitigation) and the Ryu controller
communicate exclusively through this module.  No direct inter-thread
object references; no queues shared outside this module.
"""

import queue
import threading
import time
from dataclasses import dataclass, field
from typing import Optional

from realtime_framework.config import SCENARIO_BENIGN


# ---------------------------------------------------------------------------
# Data classes (immutable message types)
# ---------------------------------------------------------------------------

@dataclass
class StatsBundle:
    """A batch of OpenFlow statistics collected in one poll cycle."""
    dpid: int
    timestamp: float
    port_stats: list   # list of dicts from EventOFPPortStatsReply
    flow_stats: list   # list of dicts from EventOFPFlowStatsReply


@dataclass
class DetectionResult:
    """Output of one detection inference window."""
    window_id: int
    timestamp: float
    pred_label: int           # 0=NORMAL, 1=ATTACK
    pred_prob: float          # sigmoid probability of ATTACK
    feature_vector: object    # numpy array, kept for latency logging
    n_flows: int              # number of flows in this window
    feature_extract_ts: float = 0.0
    inference_start_ts: float = 0.0
    inference_end_ts: float   = 0.0


@dataclass
class MitigationResult:
    """Output of one DQN mitigation decision."""
    window_id: int
    timestamp: float
    action: int
    action_name: str
    detection: "DetectionResult"


# ---------------------------------------------------------------------------
# Shared state singleton
# ---------------------------------------------------------------------------

class SharedState:
    """
    Singleton shared state.  All fields are protected by per-field locks
    or are queue objects (already thread-safe).

    Usage:
        from realtime_framework.shared_state import STATE
        STATE.set_detection_confidence(0.87)
        conf = STATE.get_detection_confidence()
    """

    def __init__(self):
        # -- Queues (bounded to prevent memory growth) --
        self.stats_queue      = queue.Queue(maxsize=10)   # StatsBundle
        self.detection_queue  = queue.Queue(maxsize=10)   # DetectionResult
        self.mitigation_queue = queue.Queue(maxsize=10)   # MitigationResult

        # -- Scalar state fields --
        self._lock = threading.Lock()

        self._detection_confidence: float = 0.0   # last ATTACK probability
        self._current_scenario: str = SCENARIO_BENIGN
        self._is_experiment_running: bool = False
        self._window_id: int = 0

        # Last mitigation action chosen by the DQN (Ryu installs it)
        self._last_mitigation_action: Optional[int] = None
        self._last_mitigation_ts: float = 0.0

        # Current evasion strength chosen by the bandit
        self._evasion_strength: float = 0.0

        # Running link-congestion estimate (updated by mitigation env)
        self._congestion_estimate: float = 0.0

        # Event used by Ryu rule-installer to signal rule was installed
        self.rule_installed_event = threading.Event()

    # -- Detection confidence (written by detector, read by bandit) --

    def set_detection_confidence(self, prob: float) -> None:
        with self._lock:
            self._detection_confidence = float(prob)

    def get_detection_confidence(self) -> float:
        with self._lock:
            return self._detection_confidence

    # -- Scenario --

    def set_scenario(self, scenario: str) -> None:
        with self._lock:
            self._current_scenario = scenario

    def get_scenario(self) -> str:
        with self._lock:
            return self._current_scenario

    # -- Experiment running flag --

    def start_experiment(self) -> None:
        with self._lock:
            self._is_experiment_running = True

    def stop_experiment(self) -> None:
        with self._lock:
            self._is_experiment_running = False

    def is_running(self) -> bool:
        with self._lock:
            return self._is_experiment_running

    # -- Window ID counter --

    def next_window_id(self) -> int:
        with self._lock:
            self._window_id += 1
            return self._window_id

    # -- Mitigation action --

    def set_mitigation_action(self, action: int) -> None:
        with self._lock:
            self._last_mitigation_action = action
            self._last_mitigation_ts = time.time()

    def get_mitigation_action(self) -> Optional[int]:
        with self._lock:
            return self._last_mitigation_action

    # -- Evasion strength (bandit output) --

    def set_evasion_strength(self, strength: float) -> None:
        with self._lock:
            self._evasion_strength = float(strength)

    def get_evasion_strength(self) -> float:
        with self._lock:
            return self._evasion_strength

    # -- Congestion estimate --

    def set_congestion(self, value: float) -> None:
        with self._lock:
            self._congestion_estimate = float(value)

    def get_congestion(self) -> float:
        with self._lock:
            return self._congestion_estimate

    # -- Convenience: post to queues without blocking experiment --

    def post_stats(self, bundle: StatsBundle) -> None:
        try:
            self.stats_queue.put_nowait(bundle)
        except queue.Full:
            pass  # drop oldest is handled by consumer; newest wins

    def post_detection(self, result: DetectionResult) -> None:
        try:
            self.detection_queue.put_nowait(result)
        except queue.Full:
            pass

    def post_mitigation(self, result: MitigationResult) -> None:
        try:
            self.mitigation_queue.put_nowait(result)
        except queue.Full:
            pass


# Module-level singleton — import this everywhere
STATE = SharedState()
