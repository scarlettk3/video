"""
traffic/traffic_generator.py — Generates controlled LFA traffic inside Mininet.

Translates a TrafficProfile into iperf3 / hping3 commands executed on Mininet
host objects.  All traffic stays within the isolated Mininet/OVS testbed.

Design constraints:
  - Uses only iperf3 (UDP/TCP) and hping3 (crafted packets) — both available
    in the standard Mininet VM image.
  - Each attack "flow" is a subprocess spawned via host.popen() so it can be
    killed when the scenario ends.
  - The generator is non-blocking: start() returns immediately; flows run in
    background; stop() kills all of them.
  - All traffic targets hosts within the Mininet experiment — no external IPs.
"""

import random
import subprocess
import threading
import time
from typing import Dict, List, Optional

from realtime_framework.config import RANDOM_SEED
from realtime_framework.traffic.profile_translator import TrafficProfile
from realtime_framework.utils.logger import log_event, log_info, log_warn


class TrafficGenerator:
    """
    Manages attack and benign traffic flows within a Mininet network.

    Usage:
        net  = Mininet(...)   # already started
        tgen = TrafficGenerator(net)

        # Start benign background traffic
        tgen.start_benign(flows=[("h1","h9",5), ("h2","h10",5)])

        # Start LFA traffic from a TrafficProfile
        tgen.start_lfa(profile)

        # Stop all LFA traffic (benign continues)
        tgen.stop_lfa()

        # Stop everything
        tgen.stop_all()
    """

    def __init__(self, net, seed: int = RANDOM_SEED):
        self._net   = net     # Mininet network object
        self._rng   = random.Random(seed)
        self._lock  = threading.Lock()

        # Active processes: {label: [popen, ...]}
        self._benign_procs: List = []
        self._lfa_procs:    List = []

        # iperf3 servers started on destination hosts (one per dst)
        self._iperf_servers: Dict[str, object] = {}

    # ------------------------------------------------------------------ #
    # Benign traffic                                                       #
    # ------------------------------------------------------------------ #

    def start_benign(
        self,
        flows: List[tuple],   # [(src_name, dst_name, rate_mbps), ...]
        duration_sec: int = 3600,
    ) -> None:
        """Start background benign UDP flows (iperf3)."""
        self._ensure_iperf_servers([dst for _, dst, _ in flows])
        with self._lock:
            for src_name, dst_name, rate_mbps in flows:
                src = self._net.get(src_name)
                dst = self._net.get(dst_name)
                if src is None or dst is None:
                    log_warn(f"Host not found: {src_name} or {dst_name}")
                    continue
                dst_ip = dst.IP()
                rate_kbps = int(rate_mbps * 1000)
                cmd = (
                    f"iperf3 -c {dst_ip} -u -b {rate_kbps}K "
                    f"-t {duration_sec} -p 5201 --foreman-bind-address {src.IP()} &"
                )
                proc = src.popen(cmd, shell=True)
                self._benign_procs.append(proc)
                log_event("benign_start", src=src_name, dst=dst_name,
                          rate_kbps=rate_kbps, duration=duration_sec)

    def stop_benign(self) -> None:
        with self._lock:
            self._kill_procs(self._benign_procs)
            self._benign_procs.clear()
        log_event("benign_stop")

    # ------------------------------------------------------------------ #
    # LFA traffic from a TrafficProfile                                    #
    # ------------------------------------------------------------------ #

    def start_lfa(self, profile: TrafficProfile) -> None:
        """
        Spawn LFA flows as described by the profile.
        Each flow is an iperf3 UDP/TCP stream or hping3 burst.
        Stops any previously running LFA flows first.
        """
        self.stop_lfa()

        dst_host_obj = self._net.get(profile.dst_host)
        if dst_host_obj is None:
            log_warn(f"LFA target host not found: {profile.dst_host}")
            return
        dst_ip = dst_host_obj.IP()

        # Ensure iperf3 server on target
        self._ensure_iperf_servers([profile.dst_host])

        src_hosts = profile.src_hosts or [profile.src_hosts[0]]
        flows_per_host = max(1, profile.n_flows // max(len(src_hosts), 1))

        with self._lock:
            for i, src_name in enumerate(src_hosts):
                src = self._net.get(src_name)
                if src is None:
                    continue
                for j in range(flows_per_host):
                    proc = self._spawn_lfa_flow(
                        src, dst_ip, profile, flow_idx=i * flows_per_host + j
                    )
                    if proc is not None:
                        self._lfa_procs.append(proc)

        log_event(
            "lfa_start",
            n_flows=profile.n_flows,
            rate_kbps=profile.rate_kbps,
            pkt_size=profile.pkt_size_bytes,
            duration=profile.duration_sec,
            protocol=profile.protocol,
            evasion=round(profile.evasion_strength, 2),
            dst=profile.dst_host,
        )

    def _spawn_lfa_flow(self, src, dst_ip: str, profile: TrafficProfile,
                        flow_idx: int):
        """Spawn a single iperf3 or hping3 attack flow."""
        rate_kbps   = profile.rate_kbps
        pkt_size    = profile.pkt_size_bytes
        duration    = profile.duration_sec

        if profile.use_random_dst_ports:
            dst_port = self._rng.randint(1024, 65535)
        else:
            dst_port = 5201 + (flow_idx % 10)

        if profile.protocol == "udp":
            # iperf3 UDP flood with fixed packet size
            cmd = (
                f"iperf3 -c {dst_ip} -u -b {rate_kbps}K "
                f"-l {pkt_size} -t {duration} -p 5201 --no-delay &"
            )
        elif profile.protocol == "tcp":
            # iperf3 TCP with parallel streams (mimics many low-and-slow flows)
            cmd = (
                f"iperf3 -c {dst_ip} -b {rate_kbps}K "
                f"-l {pkt_size} -t {duration} -p 5201 -P 2 --no-delay &"
            )
        else:
            cmd = (
                f"hping3 -S {dst_ip} -p {dst_port} "
                f"--flood --rand-source -d {pkt_size} &"
            )

        try:
            return src.popen(cmd, shell=True)
        except Exception as exc:
            log_warn(f"Failed to spawn flow on {src.name}: {exc}")
            return None

    def stop_lfa(self) -> None:
        """Kill all active LFA flows."""
        with self._lock:
            self._kill_procs(self._lfa_procs)
            self._lfa_procs.clear()
        log_event("lfa_stop")

    # ------------------------------------------------------------------ #
    # Benign-only background (iperf3 server management)                   #
    # ------------------------------------------------------------------ #

    def _ensure_iperf_servers(self, host_names: List[str]) -> None:
        """Start iperf3 servers on destination hosts if not already running."""
        for name in host_names:
            if name in self._iperf_servers:
                continue
            host = self._net.get(name)
            if host is None:
                continue
            proc = host.popen("iperf3 -s -D", shell=True)
            self._iperf_servers[name] = proc
            time.sleep(0.1)

    # ------------------------------------------------------------------ #
    # Cleanup                                                              #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _kill_procs(procs: List) -> None:
        for p in procs:
            try:
                p.kill()
            except Exception:
                pass

    def stop_all(self) -> None:
        self.stop_lfa()
        self.stop_benign()
        with self._lock:
            self._kill_procs(list(self._iperf_servers.values()))
            self._iperf_servers.clear()
        log_event("traffic_generator_stopped")
