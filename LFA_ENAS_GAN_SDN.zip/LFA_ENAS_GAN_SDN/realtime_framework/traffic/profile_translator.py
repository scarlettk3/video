"""
traffic/profile_translator.py — Converts GAN-generated feature vectors into
concrete Mininet traffic-generation parameters (iperf / hping3 arguments).

The GAN outputs a preprocessed feature vector (scaled + OHE).  Before
translation we must invert the preprocessing to recover interpretable values.
Since the GAN checkpoint stores X_min / X_max (of the TRAIN ATTACK subset
after log1p + RobustScaling), and the Generator's Tanh output lives in [-1,1],
we:
  1. Invert the GAN's [-1,1] normalization → get values in the original
     (log1p + RobustScaled) feature space.
  2. Read the rate-related numeric features (pktps, bytps, duration) to derive
     traffic-generation parameters.
  3. Clamp all parameters to safe hardware bounds defined in config.py.

NOTE: this is a best-effort approximation — the numeric magnitudes after
RobustScaling are relative, not absolute.  We use the median value of each
numeric feature from the ATTACK sub-cluster (stored in the LFA profile) as a
calibration anchor, then scale the GAN output accordingly.
"""

import numpy as np
from typing import Dict, List, Optional

from realtime_framework.config import (
    MIN_RATE_KBPS, MAX_RATE_KBPS,
    MIN_PKT_SIZE_BYTES, MAX_PKT_SIZE_BYTES,
    MIN_DURATION_SEC, MAX_DURATION_SEC,
    MAX_FLOWS_PER_BATCH,
    LFA_ATTACKER_HOSTS, LFA_TARGET_HOST,
)
from realtime_framework.utils.logger import log_event


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, float(v)))


# Indices of key numeric features in the PREPROCESSOR OUTPUT.
# The preprocessor output is: [OHE_cats | RobustScaled_nums | passthrough_flags]
# Numeric columns order: duration, pktsSnt, ..., pktps, bytps, pktAsm, bytAsm
# We use the feature_columns.json order if available, otherwise these fall-backs.
_NUM_FEATURE_NAMES = [
    "duration", "pktsSnt", "pktsRcvd", "padBytesSnt", "l7BytesSnt",
    "l7BytesRcvd", "minL7PktSz", "maxL7PktSz", "avgL7PktSz", "stdL7PktSz",
    "minIAT", "maxIAT", "avgIAT", "stdIAT", "pktps", "bytps",
    "pktAsm", "bytAsm",
]

# Index positions in the preprocessor output for the four features we care about.
# These will be populated by set_feature_index() when feature_columns.json loads.
_FEAT_INDEX: Dict[str, int] = {}


def set_feature_index(feature_columns: List[str]) -> None:
    """
    Called once after loading feature_columns.json to map feature names →
    column positions in the preprocessed array.
    """
    _FEAT_INDEX.clear()
    for i, name in enumerate(feature_columns):
        _FEAT_INDEX[name] = i


def _get_idx(name: str, default: Optional[int] = None) -> Optional[int]:
    return _FEAT_INDEX.get(name, default)


class TrafficProfile:
    """
    Traffic parameters for one LFA flow batch.
    Passed to TrafficGenerator to spawn actual traffic in Mininet.
    """
    __slots__ = [
        "n_flows", "rate_kbps", "pkt_size_bytes", "duration_sec",
        "protocol", "src_hosts", "dst_host", "evasion_strength",
        "use_random_dst_ports",
    ]

    def __init__(self):
        self.n_flows            = 5
        self.rate_kbps          = 100
        self.pkt_size_bytes     = 512
        self.duration_sec       = 10
        self.protocol           = "udp"
        self.src_hosts          = list(LFA_ATTACKER_HOSTS)
        self.dst_host           = LFA_TARGET_HOST
        self.evasion_strength   = 0.0
        self.use_random_dst_ports = False

    def __repr__(self):
        return (
            f"TrafficProfile(n_flows={self.n_flows}, rate={self.rate_kbps}kbps, "
            f"pkt={self.pkt_size_bytes}B, dur={self.duration_sec}s, "
            f"proto={self.protocol}, evasion={self.evasion_strength:.2f})"
        )


def translate(
    feature_vec: np.ndarray,
    evasion_strength: float = 0.0,
    lfa_profile: Optional[dict] = None,
    n_attacker_hosts: int = len(LFA_ATTACKER_HOSTS),
) -> TrafficProfile:
    """
    Convert a GAN-generated feature vector into a TrafficProfile.

    Args:
        feature_vec:       1-D numpy array (preprocessor output space).
        evasion_strength:  Bandit-selected evasion level [0, 1].
        lfa_profile:       Optional LFA sub-cluster profile dict for anchoring.

    Returns:
        TrafficProfile with clamped traffic parameters.
    """
    profile = TrafficProfile()
    profile.evasion_strength = evasion_strength

    # ------------------------------------------------------------------ #
    # Extract numeric features from the preprocessed vector               #
    # The GAN output lives in the pre-processed feature space (after      #
    # log1p + RobustScaling).  We interpret the relative magnitudes       #
    # to derive rate / size / duration, then map to Mbps / bytes / sec.  #
    # ------------------------------------------------------------------ #

    def _feat(name: str, fallback: float = 0.0) -> float:
        idx = _get_idx(name)
        if idx is not None and idx < len(feature_vec):
            return float(feature_vec[idx])
        return fallback

    pktps_scaled = _feat("pktps",   0.5)   # RobustScaled pktps (log-space)
    bytps_scaled = _feat("bytps",   0.5)   # RobustScaled bytps (log-space)
    dur_scaled   = _feat("duration", 0.5)
    avgpkt_scaled= _feat("avgL7PktSz", 0.3)

    # Map scaled values [−3, +3] → normalized [0, 1] via sigmoid, then scale
    def _to_norm(v: float) -> float:
        return 1.0 / (1.0 + np.exp(-float(v)))

    # Rate: higher pktps + bytps → higher attack rate
    rate_norm    = _to_norm((pktps_scaled + bytps_scaled) / 2.0)
    size_norm    = _to_norm(avgpkt_scaled)
    dur_norm     = _to_norm(dur_scaled)

    # Map to physical ranges
    rate_kbps    = MIN_RATE_KBPS + rate_norm * (MAX_RATE_KBPS - MIN_RATE_KBPS)
    pkt_bytes    = MIN_PKT_SIZE_BYTES + size_norm * (MAX_PKT_SIZE_BYTES - MIN_PKT_SIZE_BYTES)
    duration_sec = MIN_DURATION_SEC + dur_norm * (MAX_DURATION_SEC - MIN_DURATION_SEC)

    # LFA: many flows at moderate per-flow rate → scale rate down, up n_flows
    # evasion_strength=0 → few heavy flows; =1 → many light flows (harder to detect)
    base_n_flows = max(1, round(2 + evasion_strength * (MAX_FLOWS_PER_BATCH - 2)))
    rate_per_flow = rate_kbps / max(base_n_flows, 1)

    profile.n_flows         = int(_clamp(base_n_flows, 1, MAX_FLOWS_PER_BATCH))
    profile.rate_kbps       = int(_clamp(rate_per_flow, MIN_RATE_KBPS, MAX_RATE_KBPS))
    profile.pkt_size_bytes  = int(_clamp(pkt_bytes, MIN_PKT_SIZE_BYTES, MAX_PKT_SIZE_BYTES))
    profile.duration_sec    = int(_clamp(duration_sec, MIN_DURATION_SEC, MAX_DURATION_SEC))

    # Protocol selection based on evasion:
    #   low evasion → UDP (simple, high rate)
    #   high evasion → TCP (SYN floods look more legitimate individually)
    profile.protocol = "tcp" if evasion_strength > 0.6 else "udp"

    # High evasion → randomize destination ports to look like diverse legitimate traffic
    profile.use_random_dst_ports = evasion_strength > 0.5

    log_event(
        "profile_translate",
        n_flows=profile.n_flows,
        rate_kbps=profile.rate_kbps,
        pkt_size=profile.pkt_size_bytes,
        duration_sec=profile.duration_sec,
        protocol=profile.protocol,
        evasion=round(evasion_strength, 2),
    )
    return profile


def conventional_lfa_profile(duration_sec: int = 30) -> TrafficProfile:
    """
    Static TrafficProfile for the conventional (non-AI) LFA scenario.
    Direct iperf UDP flood at maximum rate — no GAN involved.
    """
    p = TrafficProfile()
    p.n_flows        = len(LFA_ATTACKER_HOSTS)
    p.rate_kbps      = MAX_RATE_KBPS
    p.pkt_size_bytes = 1400
    p.duration_sec   = duration_sec
    p.protocol       = "udp"
    p.evasion_strength = 0.0
    return p
