"""
utils/logger.py — Structured JSON-line logger shared by all framework components.

Each log record is a single JSON object written to a .jsonl file so that:
  - human-readable with `cat results/telemetry.jsonl | python -m json.tool`
  - machine-parseable by the plotter / metrics modules
  - append-only (safe under concurrent writes with per-write lock)
"""

import json
import logging
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional

from realtime_framework.config import LOG_DIR, TELEMETRY_LOG

# Standard Python logger for console output
_console = logging.getLogger("lfa_framework")
_console.setLevel(logging.INFO)
if not _console.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    ))
    _console.addHandler(_h)


class StructuredLogger:
    """
    Writes JSONL records to a file, thread-safe.
    One instance is created per log file; use the module-level helpers below.
    """

    def __init__(self, path: str):
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._fh = open(self._path, "a", buffering=1)  # line-buffered

    def write(self, record: Dict[str, Any]) -> None:
        record.setdefault("ts", time.time())
        with self._lock:
            self._fh.write(json.dumps(record, default=str) + "\n")

    def close(self) -> None:
        with self._lock:
            self._fh.flush()
            self._fh.close()


# Module-level singleton telemetry logger
_telemetry_logger: Optional[StructuredLogger] = None
_tlog_lock = threading.Lock()


def get_telemetry_logger() -> StructuredLogger:
    global _telemetry_logger
    if _telemetry_logger is None:
        with _tlog_lock:
            if _telemetry_logger is None:
                _telemetry_logger = StructuredLogger(TELEMETRY_LOG)
    return _telemetry_logger


def log_event(event_type: str, **kwargs) -> None:
    """Write a structured telemetry event and print to console."""
    record = {"event": event_type, "ts": time.time(), **kwargs}
    get_telemetry_logger().write(record)
    _console.info("[%s] %s", event_type, " | ".join(f"{k}={v}" for k, v in kwargs.items()))


def log_info(msg: str, **kwargs) -> None:
    record = {"event": "info", "msg": msg, "ts": time.time(), **kwargs}
    get_telemetry_logger().write(record)
    _console.info(msg)


def log_warn(msg: str, **kwargs) -> None:
    record = {"event": "warn", "msg": msg, "ts": time.time(), **kwargs}
    get_telemetry_logger().write(record)
    _console.warning(msg)


def log_error(msg: str, **kwargs) -> None:
    record = {"event": "error", "msg": msg, "ts": time.time(), **kwargs}
    get_telemetry_logger().write(record)
    _console.error(msg)
