"""
config.py — Central configuration for the real-time LFA framework.

All paths and hyperparameters live here.
After running the notebook (sdn-security-framework1-FIXED.ipynb), update the
INSERT_YOUR_... placeholders below with the artifact paths the notebook created.
"""

import os
import torch

# =============================================================================
# ★ INSERT YOUR MODEL ARTIFACT PATHS HERE (produced by the notebook) ★
# =============================================================================

# Root of the LFA_ENAS_GAN_SDN project folder
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Path to the notebook artifact directory (default assumes notebook cwd == PROJECT_ROOT)
ARTIFACTS_DIR = os.path.join(PROJECT_ROOT, "artifacts")

# Preprocessor (ColumnTransformer, fitted on TRAIN split only)
PREPROCESSOR_PATH = os.path.join(ARTIFACTS_DIR, "processed", "preprocessor.pkl")

# Ordered list of feature column names after preprocessing
FEATURE_COLUMNS_PATH = os.path.join(ARTIFACTS_DIR, "processed", "feature_columns.json")

# ENAS+GAN classifier checkpoint — prefer the GAN-augmented model
DETECTOR_MODEL_PATH = os.path.join(ARTIFACTS_DIR, "enas", "best_model_gan.pt")
# Fallback if GAN model not present:
DETECTOR_MODEL_FALLBACK = os.path.join(ARTIFACTS_DIR, "enas", "best_model_no_gan.pt")

# Frozen tabular GAN Generator checkpoint
GAN_GENERATOR_PATH = os.path.join(ARTIFACTS_DIR, "gan", "generator.pt")

# DQN Mitigation Agent checkpoint (produced by Part II of the notebook)
DQN_POLICY_PATH = os.path.join(ARTIFACTS_DIR, "dqn_mitigation", "mitigation_policy.pt")

# =============================================================================
# Hardware
# =============================================================================
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
RANDOM_SEED = 42

# =============================================================================
# Feature schema (must match the notebook exactly)
# =============================================================================
LOG_TRANSFORM_COLUMNS = [
    "duration", "pktsSnt", "pktsRcvd", "padBytesSnt", "l7BytesSnt",
    "l7BytesRcvd", "minL7PktSz", "maxL7PktSz", "avgL7PktSz", "stdL7PktSz",
    "minIAT", "maxIAT", "avgIAT", "stdIAT", "pktps", "bytps",
    "pktAsm", "bytAsm",
]

CATEGORICAL_COLUMNS = [
    "%dir", "flowStat", "ethType", "vlanID", "l4Proto",
    "srcPort_bucket", "dstPort_bucket",
]

OTHER_NUMERIC_COLUMNS = ["numHdrDesc", "numHdrs"]

PORT_COLUMNS = ["srcPort", "dstPort"]

# Well-known service ports that get binary flag features
SERVICE_PORTS = [
    20, 21, 22, 23, 25, 53, 67, 68, 69, 80, 110, 123, 135, 137, 138, 139,
    143, 161, 389, 443, 445, 993, 995, 1433, 3306, 3389, 5432, 5900, 8080,
]

# Columns dropped before training (do NOT include as detector inputs)
DROP_COLUMNS = [
    "flowInd", "srcIP", "dstIP", "srcMac", "dstMac",
    "srcIPCC", "dstIPCC", "srcIPOrg", "dstIPOrg",
    "timeFirst", "timeLast", "hdrDesc",
]

# =============================================================================
# Network / OpenFlow
# =============================================================================
CONTROLLER_IP   = "127.0.0.1"
CONTROLLER_PORT = 6633
OF_VERSION      = "OpenFlow13"

# How often the controller polls switch statistics (seconds)
STATS_POLL_INTERVAL = 2.0

# Detection window: feature extraction aggregates flows over this many seconds
DETECTION_WINDOW_SEC = 2.0

# Minimum number of flows required to form a detection window
MIN_FLOWS_PER_WINDOW = 1

# =============================================================================
# Fat-Tree topology parameters
# =============================================================================
TOPO_K            = 4          # fat-tree k parameter  (4 → 16 hosts, 20 switches)
TOPO_BW_HOST      = 100        # Mbps, host ↔ edge
TOPO_BW_EDGE      = 50         # Mbps, edge ↔ aggregate
TOPO_BW_AGG       = 100        # Mbps, aggregate ↔ core
TOPO_BW_CORE      = 200        # Mbps, core uplinks
TOPO_BOTTLENECK_BW = 10        # Mbps, chosen bottleneck link for LFA

# =============================================================================
# LFA Traffic Generation Agent (Agent 1)
# =============================================================================
# Epsilon-greedy bandit
BANDIT_EPSILON       = 0.20
BANDIT_EVASION_ARMS  = [0.0, 0.25, 0.50, 0.75, 1.00]  # evasion strength arms
BANDIT_ROUNDS        = 60

# Traffic-parameter clamp ranges (iperf/hping3 parameters)
MAX_FLOWS_PER_BATCH  = 30      # maximum simultaneous flows an LFA batch spawns
MIN_RATE_KBPS        = 10
MAX_RATE_KBPS        = 950     # stay below bottleneck_bw (10 Mbps = 10000 kbps)
MIN_PKT_SIZE_BYTES   = 64
MAX_PKT_SIZE_BYTES   = 1400
MIN_DURATION_SEC     = 2
MAX_DURATION_SEC     = 30

# LFA target link (aggregate → edge, bottleneck) — expressed as dpid pair
# Override with your actual switch DPIDs after the topology starts.
LFA_TARGET_LINK = ("a1", "e1")

# =============================================================================
# DQN Mitigation Agent (Agent 3)
# =============================================================================
ACTION_ALLOW    = 0
ACTION_MONITOR  = 1
ACTION_RATE_LIMIT = 2
ACTION_BLOCK    = 3   # install_blocking_rule
ACTION_REROUTE  = 4
ACTION_NAMES = ["allow", "monitor", "rate_limit", "install_blocking_rule", "reroute"]
N_ACTIONS    = 5

# Meter-based rate limit (Kbps) applied by the "rate_limit" action
RATE_LIMIT_KBPS = 500

# Congestion dynamics (must match notebook's training env)
CONGESTION_LFA_INCREMENT  = 0.08
CONGESTION_MITIGATE_DECAY = 0.85
CONGESTION_NORMAL_DECAY   = 0.98

# =============================================================================
# Experiment scenarios
# =============================================================================
SCENARIO_BENIGN       = "benign"
SCENARIO_CONV_LFA     = "conventional_lfa"
SCENARIO_GAN_LFA      = "gan_lfa"
SCENARIO_ADAPTIVE_LFA = "adaptive_lfa"

# Default experiment sequence (scenario, duration_seconds)
DEFAULT_EXPERIMENT_SEQUENCE = [
    (SCENARIO_BENIGN,       30),
    (SCENARIO_CONV_LFA,     60),
    (SCENARIO_BENIGN,       30),
    (SCENARIO_GAN_LFA,      60),
    (SCENARIO_BENIGN,       30),
    (SCENARIO_ADAPTIVE_LFA, 120),
    (SCENARIO_BENIGN,       30),
]

# Benign background traffic: list of (src_host, dst_host, rate_Mbps) tuples
# Adjust host names to match your Mininet topology.
BENIGN_FLOWS = [
    ("h1", "h9",  5),
    ("h2", "h10", 5),
    ("h3", "h11", 3),
    ("h4", "h12", 3),
    ("h5", "h13", 2),
    ("h6", "h14", 2),
]

# Conventional LFA: direct iperf flood toward the bottleneck
CONV_LFA_FLOWS = [
    ("h1", "h9",  9),
    ("h2", "h10", 9),
    ("h3", "h11", 9),
    ("h5", "h13", 9),
]

# LFA attacker hosts (used by the generation agent)
LFA_ATTACKER_HOSTS = ["h1", "h2", "h3", "h5"]
LFA_TARGET_HOST    = "h9"

# =============================================================================
# Evaluation / logging
# =============================================================================
RESULTS_DIR      = os.path.join(PROJECT_ROOT, "realtime_framework", "results")
LOG_DIR          = os.path.join(PROJECT_ROOT, "logs")
GROUND_TRUTH_LOG = os.path.join(RESULTS_DIR, "ground_truth.jsonl")
TELEMETRY_LOG    = os.path.join(RESULTS_DIR, "telemetry.jsonl")
LATENCY_LOG      = os.path.join(RESULTS_DIR, "latencies.jsonl")
METRICS_OUTPUT   = os.path.join(RESULTS_DIR, "metrics_summary.json")
PLOTS_DIR        = os.path.join(RESULTS_DIR, "plots")

for _d in [RESULTS_DIR, LOG_DIR, PLOTS_DIR]:
    os.makedirs(_d, exist_ok=True)
