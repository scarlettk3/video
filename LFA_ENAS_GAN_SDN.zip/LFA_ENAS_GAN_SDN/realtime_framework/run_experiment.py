"""
run_experiment.py — Main experiment orchestrator for the real-time LFA framework.

Execution flow:
  1. Load all frozen models (Detection Agent, GAN Generator, DQN Policy)
  2. Build the LFA profile from val split artifacts (for profile projection)
  3. Start Mininet with the selected topology
  4. Wait for the Ryu controller to connect
  5. Run the experiment sequence via ExperimentManager
  6. Stop Mininet
  7. Compute and print evaluation metrics
  8. Generate all plots

Usage (must run as root for Mininet):
    sudo python3 -m realtime_framework.run_experiment [OPTIONS]

Options:
    --topo     fat_tree | linear | ring     (default: fat_tree)
    --scenario benign|conv_lfa|gan_lfa|adaptive_lfa  (run single scenario)
    --eval-only  skip the experiment, only compute metrics + plots from logs
    --plot-only  skip experiment and metrics, only regenerate plots

Prerequisites:
    - Ryu controller must already be running:
        ryu-manager realtime_framework/ryu_app/lfa_controller.py \\
            --observe-links --ofp-tcp-listen-port 6633
    - Notebook artifacts must exist (run cells 0-18 of sdn-security-framework1-FIXED.ipynb)
    - Running on a Linux host with Mininet and Open vSwitch installed
"""

import argparse
import sys
import time
import os

# Ensure project root is on path
_PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJ not in sys.path:
    sys.path.insert(0, _PROJ)

from realtime_framework.config import (
    DEFAULT_EXPERIMENT_SEQUENCE, ARTIFACTS_DIR, RANDOM_SEED,
    SCENARIO_BENIGN, SCENARIO_CONV_LFA, SCENARIO_GAN_LFA, SCENARIO_ADAPTIVE_LFA,
)
from realtime_framework.shared_state import STATE
from realtime_framework.agents.detection_agent import get_detection_agent
from realtime_framework.agents.generation_agent import get_generation_agent
from realtime_framework.agents.mitigation_agent import get_mitigation_agent
from realtime_framework.feature_extraction.preprocessor import (
    load_preprocessor, get_feature_columns,
)
from realtime_framework.traffic.profile_translator import set_feature_index
from realtime_framework.evaluation.latency_tracker import get_latency_tracker
from realtime_framework.evaluation.metrics import compute_all_metrics
from realtime_framework.evaluation.plotter import plot_all
from realtime_framework.utils.logger import log_info, log_warn, log_error


# ---------------------------------------------------------------------------
# Model loading + val-split profile building
# ---------------------------------------------------------------------------

def load_all_models() -> bool:
    """Load all frozen models.  Returns True if all succeed."""
    ok = True
    log_info("Loading frozen models...")

    ok &= get_detection_agent().load()
    ok &= get_generation_agent().load()
    ok &= get_mitigation_agent().load()
    ok &= load_preprocessor()

    if not ok:
        log_error(
            "One or more models failed to load.  "
            "Ensure the notebook was run to completion and artifacts exist at "
            f"{ARTIFACTS_DIR}"
        )
    else:
        log_info("All models loaded successfully.")
    return ok


def build_lfa_profile_from_artifacts() -> None:
    """
    Load val split from disk and build LFA sub-cluster profile for
    the generation agent's profile-projection step.
    """
    import json
    import numpy as np
    from pathlib import Path

    val_path = Path(ARTIFACTS_DIR) / "processed" / "val.npz"
    if not val_path.exists():
        log_warn(
            f"val.npz not found at {val_path} — LFA profile projection disabled. "
            "The GAN will generate without profile blending."
        )
        return

    try:
        d = np.load(val_path)
        val_X = d["X"].astype(np.float32)
        val_y = d["y"].astype(int)
        feat_cols = get_feature_columns()
        set_feature_index(feat_cols)

        gen = get_generation_agent()
        gen.build_lfa_profile(val_X, val_y, feat_cols)
        log_info(
            f"LFA profile built from val split: {val_X.shape[0]} rows, "
            f"{(val_y == 1).sum()} ATTACK."
        )
    except Exception as exc:
        log_warn(f"Failed to build LFA profile: {exc}")


# ---------------------------------------------------------------------------
# Mininet experiment runner
# ---------------------------------------------------------------------------

def run_with_mininet(args) -> None:
    """Start Mininet, run experiment, clean up."""
    from realtime_framework.network.topology import build_network
    from realtime_framework.traffic.traffic_generator import TrafficGenerator
    from realtime_framework.experiment_manager import ExperimentManager

    try:
        from mininet.clean import Cleanup
        Cleanup.cleanup()
    except Exception:
        pass

    log_info(f"Building {args.topo} topology...")
    net = build_network(args.topo)
    net.build()

    log_info("Starting Mininet network...")
    net.start()

    # Wait for Ryu controller to see all switches
    log_info("Waiting 5s for Ryu to discover topology...")
    time.sleep(5)

    # Connectivity test
    log_info("Testing connectivity (pingAll)...")
    net.pingAll()

    tgen = TrafficGenerator(net)
    mgr  = ExperimentManager(tgen, net=net)

    sequence = _build_sequence(args)
    log_info(f"Experiment sequence: {sequence}")

    try:
        mgr.run(sequence=sequence)
    except KeyboardInterrupt:
        log_warn("Experiment interrupted by user.")
        mgr.stop()
    finally:
        log_info("Stopping Mininet...")
        tgen.stop_all()
        net.stop()


def _build_sequence(args):
    if getattr(args, "scenario", None):
        # Single-scenario mode: 90s duration
        return [(args.scenario, 90)]
    return DEFAULT_EXPERIMENT_SEQUENCE


# ---------------------------------------------------------------------------
# Generalization test runner
# ---------------------------------------------------------------------------

def run_generalization_tests() -> None:
    """
    Run the same adaptive-LFA scenario across multiple topology variants
    and different host counts to test generalization with frozen detector.
    """
    log_info("\n=== Generalization Tests ===")
    variants = [
        ("fat_tree", {"k": 4}),
        ("fat_tree", {"k": 6}),
        ("linear",   {"n": 8}),
        ("ring",     {"n": 6}),
    ]
    for topo_name, kwargs in variants:
        log_info(f"  Running generalization test: {topo_name} {kwargs}")
        # Each variant is a separate experiment; in practice run one at a time
        # to keep Mininet environment clean.
        # Log variant context for evaluation to distinguish results.
        from realtime_framework.utils.logger import log_event
        log_event(
            "generalization_test",
            topo=topo_name,
            topo_kwargs=kwargs,
            note="Run each variant by passing --topo and topology params to run_experiment.py",
        )
    log_info("Generalization test templates logged.  Run each variant separately.")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def parse_args():
    p = argparse.ArgumentParser(
        description="Real-time LFA multi-agent experiment runner"
    )
    p.add_argument(
        "--topo", choices=["fat_tree", "linear", "ring"],
        default="fat_tree",
        help="Network topology to use (default: fat_tree)",
    )
    p.add_argument(
        "--scenario",
        choices=[SCENARIO_BENIGN, SCENARIO_CONV_LFA,
                 SCENARIO_GAN_LFA, SCENARIO_ADAPTIVE_LFA],
        default=None,
        help="Run a single scenario (default: full DEFAULT_EXPERIMENT_SEQUENCE)",
    )
    p.add_argument(
        "--eval-only", action="store_true",
        help="Skip experiment; compute metrics + plots from existing logs",
    )
    p.add_argument(
        "--plot-only", action="store_true",
        help="Skip experiment and metrics; regenerate plots only",
    )
    p.add_argument(
        "--generalization", action="store_true",
        help="Log generalization test templates",
    )
    return p.parse_args()


def main():
    args = parse_args()

    if args.plot_only:
        log_info("Plot-only mode.")
        plot_all()
        return

    if args.eval_only:
        log_info("Evaluation-only mode.")
        compute_all_metrics()
        plot_all()
        return

    if args.generalization:
        run_generalization_tests()
        return

    # Verify we're root (Mininet requires root)
    if os.geteuid() != 0:
        print("ERROR: Mininet requires root privileges. Re-run with sudo.")
        sys.exit(1)

    # Load models
    if not load_all_models():
        sys.exit(1)

    # Build LFA profile from artifacts
    build_lfa_profile_from_artifacts()

    # Run experiment
    run_with_mininet(args)

    # Post-experiment evaluation
    log_info("\n=== Post-Experiment Evaluation ===")
    get_latency_tracker().flush_all()
    compute_all_metrics()
    plot_all()
    log_info("Done.")


if __name__ == "__main__":
    main()
