"""
agents/detection_agent.py — Frozen ENAS+GAN classifier wrapper for real-time use.

Loads the saved ConfigurableMLP checkpoint from the notebook.
Never modifies weights.  Thread-safe batch inference.

The Detection Agent receives ONLY features extracted from OpenFlow telemetry —
no ground-truth labels, no attack session IDs, no generator mode information.
"""

import threading
import time
from pathlib import Path
from typing import Optional, Tuple

import numpy as np
import torch
import torch.nn as nn

from realtime_framework.config import (
    DETECTOR_MODEL_PATH, DETECTOR_MODEL_FALLBACK, DEVICE, RANDOM_SEED,
)
from realtime_framework.utils.logger import log_info, log_warn, log_error, log_event


# ---------------------------------------------------------------------------
# ConfigurableMLP (identical to the notebook definition — must not change)
# ---------------------------------------------------------------------------

ACTIVATIONS = {
    "relu":       nn.ReLU,
    "leaky_relu": lambda: nn.LeakyReLU(0.01),
    "gelu":       nn.GELU,
}


class ConfigurableMLP(nn.Module):
    """ENAS architecture, reproduced exactly from the notebook."""

    def __init__(self, input_dim: int, arch: dict):
        super().__init__()
        self.arch = arch
        activation_cls = ACTIVATIONS[arch["activation"]]
        layers = []
        in_dim = input_dim
        for units in arch["units"][: arch["n_layers"]]:
            layers.append(nn.Linear(in_dim, units))
            layers.append(nn.BatchNorm1d(units))
            layers.append(activation_cls())
            if arch["dropout"] > 0:
                layers.append(nn.Dropout(arch["dropout"]))
            in_dim = units
        layers.append(nn.Linear(in_dim, 1))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x).squeeze(-1)


# ---------------------------------------------------------------------------
# DetectionAgent singleton
# ---------------------------------------------------------------------------

class DetectionAgent:
    """
    Frozen ENAS+GAN classifier for real-time LFA detection.

    Usage:
        agent = DetectionAgent()
        prob, label = agent.predict_single(feature_vector_1d)
        probs, labels = agent.predict_batch(feature_matrix_2d)
    """

    def __init__(self, device: Optional[torch.device] = None):
        self.device = device or DEVICE
        self._model: Optional[ConfigurableMLP] = None
        self._input_dim: int = 0
        self._lock = threading.Lock()
        self._loaded = False

    def load(self) -> bool:
        """Load the checkpoint.  Returns True on success."""
        with self._lock:
            if self._loaded:
                return True
            return self._load_checkpoint()

    def _load_checkpoint(self) -> bool:
        # Try GAN-augmented model first; fall back to no-GAN
        for path in [DETECTOR_MODEL_PATH, DETECTOR_MODEL_FALLBACK]:
            p = Path(path)
            if not p.exists():
                log_warn(f"Detector checkpoint not found: {p}")
                continue
            try:
                ckpt = torch.load(p, map_location=self.device, weights_only=False)
                self._input_dim = ckpt["input_dim"]
                arch = ckpt["architecture"]
                model = ConfigurableMLP(self._input_dim, arch).to(self.device)
                model.load_state_dict(ckpt["state_dict"])
                model.eval()
                for param in model.parameters():
                    param.requires_grad_(False)
                self._model = model
                self._loaded = True
                log_info(
                    f"[DetectionAgent] Loaded frozen ENAS+GAN classifier from {p.name}. "
                    f"input_dim={self._input_dim}, arch={arch}"
                )
                return True
            except Exception as exc:
                log_error(f"Failed to load checkpoint {p}: {exc}")
        return False

    @torch.no_grad()
    def predict_batch(
        self,
        X: np.ndarray,
        batch_size: int = 4096,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Run inference on a 2-D feature array.

        Returns:
            probs  (N,) — sigmoid probabilities of ATTACK class
            labels (N,) — 0/1 predictions (threshold 0.5)
        """
        if not self._loaded:
            if not self.load():
                n = len(X)
                return np.zeros(n), np.zeros(n, dtype=int)

        arr = np.asarray(X, dtype=np.float32)
        probs_list = []

        with self._lock:
            for i in range(0, len(arr), batch_size):
                xb = torch.tensor(
                    arr[i:i + batch_size], dtype=torch.float32, device=self.device
                )
                logits = self._model(xb)
                p = torch.sigmoid(logits).cpu().numpy().reshape(-1)
                probs_list.append(p)

        probs  = np.concatenate(probs_list)
        labels = (probs >= 0.5).astype(int)
        return probs, labels

    def predict_single(
        self, x: np.ndarray
    ) -> Tuple[float, int]:
        """Convenience wrapper for a single 1-D feature vector."""
        probs, labels = self.predict_batch(x[None, :])
        return float(probs[0]), int(labels[0])

    def run_window(
        self,
        X: np.ndarray,
        window_id: int,
    ) -> dict:
        """
        Run detection on a full window (N flows) and return a result dict
        with timing stamps.

        The window-level prediction is ATTACK if the mean predicted probability
        across all flows exceeds 0.5 (majority-vote style, robust to single
        noisy flows).
        """
        inference_start = time.time()
        probs, labels = self.predict_batch(X)
        inference_end  = time.time()

        mean_prob   = float(probs.mean())
        window_pred = int(mean_prob >= 0.5)
        max_prob    = float(probs.max())

        result = {
            "window_id":        window_id,
            "ts":               inference_start,
            "inference_start":  inference_start,
            "inference_end":    inference_end,
            "inference_latency_ms": (inference_end - inference_start) * 1000,
            "n_flows":          len(probs),
            "mean_pred_prob":   mean_prob,
            "max_pred_prob":    max_prob,
            "pred_label":       window_pred,
            "per_flow_probs":   probs.tolist(),
            "per_flow_labels":  labels.tolist(),
        }

        log_event(
            "detection",
            window_id=window_id,
            n_flows=len(probs),
            mean_prob=round(mean_prob, 4),
            pred_label=window_pred,
            latency_ms=round(result["inference_latency_ms"], 2),
        )
        return result


# Module-level singleton
_detection_agent: Optional[DetectionAgent] = None
_da_lock = threading.Lock()


def get_detection_agent() -> DetectionAgent:
    global _detection_agent
    if _detection_agent is None:
        with _da_lock:
            if _detection_agent is None:
                _detection_agent = DetectionAgent()
                _detection_agent.load()
    return _detection_agent
