"""
agents/mitigation_agent.py — Frozen DQN Mitigation Agent for real-time use.

Loads the DQN policy checkpoint saved by the notebook's §16 training cell
(mitigation_policy.pt).  Never retrains.  Thread-safe argmax inference.

State vector fed to the DQN:
    [detection_confidence, feature_dim floats, congestion_signal]
    → matches the state construction in the notebook's SDNMitigationEnv._state()
"""

import threading
import time
from pathlib import Path
from typing import Optional, Tuple

import numpy as np
import torch
import torch.nn as nn

from realtime_framework.config import (
    DQN_POLICY_PATH, DEVICE, N_ACTIONS, ACTION_NAMES,
    ACTION_BLOCK, ACTION_RATE_LIMIT, ACTION_REROUTE,
)
from realtime_framework.shared_state import STATE
from realtime_framework.utils.logger import log_info, log_warn, log_error, log_event

# Congestion dynamics constants (must match the notebook's training env)
_CONGESTION_LFA_INCREMENT  = 0.08
_CONGESTION_MITIGATE_DECAY = 0.85
_CONGESTION_NORMAL_DECAY   = 0.98


# ---------------------------------------------------------------------------
# QNetwork (identical to notebook definition)
# ---------------------------------------------------------------------------

class QNetwork(nn.Module):
    def __init__(self, state_dim: int, n_actions: int, hidden_dims=None):
        super().__init__()
        hidden_dims = hidden_dims or [128, 64]
        layers = []
        in_dim = state_dim
        for h in hidden_dims:
            layers.append(nn.Linear(in_dim, h))
            layers.append(nn.ReLU())
            in_dim = h
        layers.append(nn.Linear(in_dim, n_actions))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


# ---------------------------------------------------------------------------
# MitigationAgent
# ---------------------------------------------------------------------------

class MitigationAgent:
    """
    Frozen DQN policy for real-time mitigation action selection.

    Usage:
        agent = MitigationAgent()
        agent.load()
        action, name = agent.select_action(pred_prob, feature_vec, congestion)
    """

    def __init__(self, device: Optional[torch.device] = None):
        self.device    = device or DEVICE
        self._net: Optional[QNetwork] = None
        self._state_dim: int = 0
        self._n_actions: int = N_ACTIONS
        self._action_names = ACTION_NAMES
        self._lock   = threading.Lock()
        self._loaded = False

        # Running congestion estimate (updated after each decision)
        self._congestion: float = 0.0
        self._cong_lock  = threading.Lock()

    # ------------------------------------------------------------------ #
    # Loading                                                              #
    # ------------------------------------------------------------------ #

    def load(self) -> bool:
        with self._lock:
            if self._loaded:
                return True
            return self._load_checkpoint()

    def _load_checkpoint(self) -> bool:
        p = Path(DQN_POLICY_PATH)
        if not p.exists():
            log_warn(
                f"DQN policy checkpoint not found at {p}. "
                "Run the notebook Part II (§16) first, or the agent will "
                "fall back to a static threshold policy."
            )
            return False
        try:
            ckpt = torch.load(p, map_location=self.device, weights_only=False)
            state_dim   = ckpt["state_dim"]
            n_actions   = ckpt.get("n_actions", N_ACTIONS)
            hidden_dims = ckpt.get("hidden_dims", [128, 64])

            net = QNetwork(state_dim, n_actions, hidden_dims).to(self.device)
            net.load_state_dict(ckpt["state_dict"])
            net.eval()
            for param in net.parameters():
                param.requires_grad_(False)

            self._net       = net
            self._state_dim = state_dim
            self._n_actions = n_actions
            self._action_names = ckpt.get("action_names", ACTION_NAMES)
            self._loaded    = True
            log_info(
                f"[MitigationAgent] Loaded frozen DQN policy from {p.name}. "
                f"state_dim={state_dim}, n_actions={n_actions}"
            )
            return True
        except Exception as exc:
            log_error(f"Failed to load DQN policy: {exc}")
            return False

    # ------------------------------------------------------------------ #
    # Congestion model (mirrors notebook SDNMitigationEnv)                #
    # ------------------------------------------------------------------ #

    def update_congestion(self, action: int, is_malicious: bool) -> float:
        """Update the running congestion estimate and return new value."""
        MITIGATION_ACTIONS = {ACTION_RATE_LIMIT, ACTION_BLOCK, ACTION_REROUTE}

        with self._cong_lock:
            mitigated = action in MITIGATION_ACTIONS
            if is_malicious:
                if mitigated:
                    self._congestion *= _CONGESTION_MITIGATE_DECAY
                else:
                    self._congestion = min(1.0, self._congestion + _CONGESTION_LFA_INCREMENT)
            else:
                self._congestion *= _CONGESTION_NORMAL_DECAY
            STATE.set_congestion(self._congestion)
            return self._congestion

    def get_congestion(self) -> float:
        with self._cong_lock:
            return self._congestion

    def reset_congestion(self) -> None:
        with self._cong_lock:
            self._congestion = 0.0
            STATE.set_congestion(0.0)

    # ------------------------------------------------------------------ #
    # Inference                                                            #
    # ------------------------------------------------------------------ #

    def _build_state(self, pred_prob: float, feature_vec: np.ndarray,
                     congestion: float) -> np.ndarray:
        """Build the DQN state vector: [pred_prob, *features, congestion]."""
        return np.concatenate(
            [[float(pred_prob)],
             np.asarray(feature_vec, dtype=np.float32),
             [float(congestion)]]
        ).astype(np.float32)

    @torch.no_grad()
    def select_action(
        self,
        pred_prob: float,
        feature_vec: np.ndarray,
        congestion: Optional[float] = None,
    ) -> Tuple[int, str]:
        """
        Select the best mitigation action given the current network state.

        Args:
            pred_prob:    ATTACK probability from the Detection Agent.
            feature_vec:  Preprocessed feature vector (1-D).
            congestion:   Current congestion estimate (uses internal if None).

        Returns:
            (action_index, action_name)
        """
        if congestion is None:
            congestion = self.get_congestion()

        if not self._loaded:
            # Static fallback: block if confident, allow otherwise
            action = 3 if pred_prob > 0.5 else 0
            return action, self._action_names[action]

        state = self._build_state(pred_prob, feature_vec, congestion)
        s_tensor = torch.tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)

        with self._lock:
            q_values = self._net(s_tensor)
            action = int(q_values.argmax(dim=1).item())

        action_name = self._action_names[action] if action < len(self._action_names) else "unknown"

        log_event(
            "mitigation_select",
            action=action,
            action_name=action_name,
            pred_prob=round(pred_prob, 4),
            congestion=round(congestion, 4),
        )
        return action, action_name


# Module-level singleton
_mitigation_agent: Optional[MitigationAgent] = None
_ma_lock = threading.Lock()


def get_mitigation_agent() -> MitigationAgent:
    global _mitigation_agent
    if _mitigation_agent is None:
        with _ma_lock:
            if _mitigation_agent is None:
                _mitigation_agent = MitigationAgent()
                _mitigation_agent.load()
    return _mitigation_agent
