"""
agents/bandit.py — Epsilon-greedy bandit for controlling the LFA evasion mode.

The bandit selects an evasion_strength arm each generation round.
Reward = (1 - detection_confidence), updated after each detection window.
Converged arm is fed to the LFA Generator as the evasion parameter.

This is purely a Python object — no Ryu or Mininet dependency.
"""

import threading
import time
from typing import List, Optional, Tuple

import numpy as np

from realtime_framework.config import (
    BANDIT_EPSILON, BANDIT_EVASION_ARMS, RANDOM_SEED,
)
from realtime_framework.utils.logger import log_event


class EvasionBandit:
    """
    Epsilon-greedy multi-armed bandit over evasion_strength arms.

    Arm values are incremental sample-mean estimates:
        Q(a) += (reward - Q(a)) / N(a)

    Reward received from outside (caller provides it after a detection window):
        reward = 1.0 − detection_confidence    (high → detector is uncertain)

    Thread-safe: select_arm() / update() may be called from different threads.
    """

    def __init__(
        self,
        arms: List[float] = BANDIT_EVASION_ARMS,
        epsilon: float = BANDIT_EPSILON,
        seed: int = RANDOM_SEED,
    ):
        self.arms   = list(arms)
        self.n_arms = len(arms)
        self.epsilon = epsilon

        self._values = np.zeros(self.n_arms, dtype=np.float64)
        self._counts = np.zeros(self.n_arms, dtype=np.int64)
        self._rng    = np.random.RandomState(seed)
        self._lock   = threading.Lock()

        # History for logging / plotting
        self._history: list = []

    # ------------------------------------------------------------------ #
    # Core bandit interface                                                #
    # ------------------------------------------------------------------ #

    def select_arm(self) -> Tuple[int, float]:
        """
        Choose an arm (index, evasion_strength) using epsilon-greedy policy.
        Returns (arm_index, evasion_strength).
        """
        with self._lock:
            if self._rng.random() < self.epsilon:
                idx = self._rng.randint(0, self.n_arms)
            else:
                idx = int(np.argmax(self._values))
            return idx, self.arms[idx]

    def update(self, arm_idx: int, reward: float) -> None:
        """Update value estimate for the chosen arm with the observed reward."""
        with self._lock:
            self._counts[arm_idx] += 1
            n = self._counts[arm_idx]
            self._values[arm_idx] += (reward - self._values[arm_idx]) / n
            entry = {
                "ts": time.time(),
                "arm": arm_idx,
                "evasion_strength": self.arms[arm_idx],
                "reward": reward,
                "values": self._values.tolist(),
                "counts": self._counts.tolist(),
            }
            self._history.append(entry)

        log_event(
            "bandit_update",
            arm=arm_idx,
            evasion_strength=self.arms[arm_idx],
            reward=round(reward, 4),
            arm_values={str(self.arms[i]): round(float(self._values[i]), 4)
                        for i in range(self.n_arms)},
        )

    # ------------------------------------------------------------------ #
    # Convenience helpers                                                  #
    # ------------------------------------------------------------------ #

    def converged_arm(self) -> Tuple[int, float]:
        """Return the arm with the highest current value estimate."""
        with self._lock:
            idx = int(np.argmax(self._values))
            return idx, self.arms[idx]

    def arm_values(self) -> dict:
        with self._lock:
            return {str(self.arms[i]): float(self._values[i])
                    for i in range(self.n_arms)}

    def get_history(self) -> list:
        with self._lock:
            return list(self._history)

    def reset(self) -> None:
        with self._lock:
            self._values[:] = 0.0
            self._counts[:] = 0
            self._history.clear()
