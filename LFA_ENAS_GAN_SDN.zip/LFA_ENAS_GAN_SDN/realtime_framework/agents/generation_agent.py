"""
agents/generation_agent.py — Frozen GAN Generator + epsilon-greedy bandit.

Agent 1 reuses the tabular GAN Generator trained in the notebook (frozen,
never retrained here).  At each generation step:

  1. The bandit selects an evasion_strength arm.
  2. The Generator produces a batch of synthetic feature vectors.
  3. Each feature vector is "projected" toward a real LFA sub-cluster profile
     with blend factor = evasion_strength.
  4. The profile_translator module converts feature vectors into traffic
     parameters (rate, pkt_size, n_flows, protocol, dst) sent to Mininet.
  5. After the next detection window completes, the bandit receives:
         reward = 1 − detection_confidence
     and updates its arm estimate.

The Generator weights are NEVER modified.  No gradient computation occurs.
"""

import os
import threading
import time
from pathlib import Path
from typing import Optional, Tuple

import numpy as np
import torch
import torch.nn as nn

from realtime_framework.config import (
    GAN_GENERATOR_PATH, DEVICE, RANDOM_SEED,
    BANDIT_EVASION_ARMS, BANDIT_EPSILON,
)
from realtime_framework.agents.bandit import EvasionBandit
from realtime_framework.shared_state import STATE
from realtime_framework.utils.logger import log_info, log_warn, log_error, log_event


# ---------------------------------------------------------------------------
# Generator (identical to notebook definition — must not change)
# ---------------------------------------------------------------------------

class Generator(nn.Module):
    def __init__(self, noise_dim: int, output_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(noise_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim * 2),
            nn.BatchNorm1d(hidden_dim * 2),
            nn.ReLU(),
            nn.Linear(hidden_dim * 2, output_dim),
            nn.Tanh(),
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        return self.net(z)


def _from_unit_range(X_unit: np.ndarray, X_min: np.ndarray, X_max: np.ndarray) -> np.ndarray:
    """Invert the [-1,1] normalization used during GAN training."""
    return ((X_unit + 1) / 2) * (X_max - X_min) + X_min


# ---------------------------------------------------------------------------
# GenerationAgent
# ---------------------------------------------------------------------------

class GenerationAgent:
    """
    Frozen GAN Generator + epsilon-greedy evasion bandit.

    Call flow:
        agent.load()                          → loads Generator weights
        profile = agent.generate(batch_size)  → returns (batch_size, feature_dim) array
        agent.receive_reward(arm_idx, confidence) → updates bandit
    """

    def __init__(self, device: Optional[torch.device] = None):
        self.device    = device or DEVICE
        self._gen: Optional[Generator] = None
        self._noise_dim: int = 0
        self._feature_dim: int = 0
        self._X_min: Optional[np.ndarray] = None
        self._X_max: Optional[np.ndarray] = None
        self._lock   = threading.Lock()
        self._loaded = False

        self.bandit  = EvasionBandit(
            arms=BANDIT_EVASION_ARMS, epsilon=BANDIT_EPSILON, seed=RANDOM_SEED
        )

        # LFA sub-cluster profile (built from val split via notebook artifacts)
        self._lfa_profile: Optional[dict] = None

        # Track last chosen arm so the caller can supply a delayed reward
        self._last_arm_idx: int = 0
        self._last_evasion: float = 0.0

        self._rng = np.random.RandomState(RANDOM_SEED)

    # ------------------------------------------------------------------ #
    # Loading                                                              #
    # ------------------------------------------------------------------ #

    def load(self) -> bool:
        with self._lock:
            if self._loaded:
                return True
            return self._load_checkpoint()

    def _load_checkpoint(self) -> bool:
        p = Path(GAN_GENERATOR_PATH)
        if not p.exists():
            log_error(
                f"GAN generator checkpoint not found at {p}. "
                "Run the notebook first (GAN training section)."
            )
            return False
        try:
            ckpt = torch.load(p, map_location=self.device, weights_only=False)
            noise_dim   = ckpt["noise_dim"]
            feature_dim = ckpt["feature_dim"]
            self._X_min = np.asarray(ckpt["X_min"], dtype=np.float32)
            self._X_max = np.asarray(ckpt["X_max"], dtype=np.float32)

            gen = Generator(noise_dim, feature_dim).to(self.device)
            gen.load_state_dict(ckpt["generator_state_dict"])
            gen.eval()
            for param in gen.parameters():
                param.requires_grad_(False)

            self._gen         = gen
            self._noise_dim   = noise_dim
            self._feature_dim = feature_dim
            self._loaded      = True
            log_info(
                f"[GenerationAgent] Loaded frozen GAN Generator from {p.name}. "
                f"noise_dim={noise_dim}, feature_dim={feature_dim}"
            )
            return True
        except Exception as exc:
            log_error(f"Failed to load GAN generator: {exc}")
            return False

    # ------------------------------------------------------------------ #
    # Profile building (called once at experiment start)                   #
    # ------------------------------------------------------------------ #

    def build_lfa_profile(self, val_X: np.ndarray, val_y: np.ndarray,
                          feature_names: list) -> None:
        """
        Compute per-feature statistics from the real ATTACK sub-cluster of the
        val split to ground profile projection.
        """
        Xa = val_X[val_y == 1]
        if len(Xa) == 0:
            log_warn("[GenerationAgent] No ATTACK rows in val split — LFA profile skipped.")
            return

        # Sub-cluster: top 30% by combined rate features (pktps + bytps proxies)
        feat_idx = {name: i for i, name in enumerate(feature_names)}
        rate_idx = [feat_idx[f] for f in ["pktps", "bytps"] if f in feat_idx]

        score = np.zeros(len(Xa))
        for idx in rate_idx:
            col = Xa[:, idx]
            score += (col - col.mean()) / (col.std() + 1e-8)

        k = max(50, int(0.30 * len(Xa)))
        sub_idx = np.argsort(score)[-k:]
        Xsub = Xa[sub_idx]

        lfa_feats = [f for f in ["pktps", "bytps", "pktAsm", "bytAsm", "duration"]
                     if f in feat_idx]
        indices   = [feat_idx[f] for f in lfa_feats]

        self._lfa_profile = {
            "features":    lfa_feats,
            "indices":     indices,
            "target_mean": {f: float(Xsub[:, feat_idx[f]].mean()) for f in lfa_feats},
            "target_std":  {f: float(Xsub[:, feat_idx[f]].std())  for f in lfa_feats},
        }
        log_info(
            f"[GenerationAgent] LFA profile built on {len(Xsub)} real-attack sub-cluster rows. "
            f"Features: {lfa_feats}"
        )

    # ------------------------------------------------------------------ #
    # Generation                                                           #
    # ------------------------------------------------------------------ #

    def _project_to_lfa_profile(self, X: np.ndarray) -> np.ndarray:
        """Blend each feature vector toward the LFA sub-cluster centroid."""
        if self._lfa_profile is None:
            return X
        X_out = X.copy()
        for fi, fname in zip(self._lfa_profile["indices"], self._lfa_profile["features"]):
            if fi < X.shape[1]:
                target = self._lfa_profile["target_mean"][fname]
                X_out[:, fi] = target
        return X_out

    @torch.no_grad()
    def generate(
        self,
        batch_size: int = 64,
        evasion_strength: Optional[float] = None,
    ) -> np.ndarray:
        """
        Generate a batch of synthetic LFA feature vectors.

        evasion_strength in [0, 1]:
          0.0 → pure GAN output (maximally evasive / natural-looking)
          1.0 → fully projected to LFA profile (maximally attack-like)
          intermediate → linear blend

        Returns np.ndarray of shape (batch_size, feature_dim).
        """
        if not self._loaded:
            if not self.load():
                return np.zeros((batch_size, max(self._feature_dim, 1)), dtype=np.float32)

        if evasion_strength is None:
            evasion_strength = STATE.get_evasion_strength()

        with self._lock:
            z = torch.randn(batch_size, self._noise_dim,
                            device=self.device, generator=None)
            x_unit = self._gen(z).cpu().numpy()          # shape (B, feature_dim) in [-1,1]

        # Invert the GAN's internal normalization
        x_raw = _from_unit_range(x_unit, self._X_min, self._X_max)

        # Blend toward LFA sub-cluster profile
        x_lfa = self._project_to_lfa_profile(x_raw)
        alpha  = float(evasion_strength)
        output = (1.0 - alpha) * x_raw + alpha * x_lfa

        return output.astype(np.float32)

    # ------------------------------------------------------------------ #
    # Bandit integration                                                   #
    # ------------------------------------------------------------------ #

    def select_evasion_mode(self) -> Tuple[int, float]:
        """
        Ask the bandit for the next evasion_strength.
        Stores the chosen arm for later reward attribution.
        """
        arm_idx, strength = self.bandit.select_arm()
        self._last_arm_idx = arm_idx
        self._last_evasion = strength
        STATE.set_evasion_strength(strength)

        log_event(
            "bandit_select",
            arm=arm_idx,
            evasion_strength=strength,
            bandit_values=self.bandit.arm_values(),
        )
        return arm_idx, strength

    def receive_reward(self, detection_confidence: float) -> None:
        """
        Feed detection confidence back to the bandit.
        reward = 1 − confidence  (high when detector is uncertain)
        """
        reward = 1.0 - float(detection_confidence)
        self.bandit.update(self._last_arm_idx, reward)

        log_event(
            "bandit_reward",
            arm=self._last_arm_idx,
            evasion_strength=self._last_evasion,
            detection_confidence=round(detection_confidence, 4),
            reward=round(reward, 4),
        )


# Module-level singleton
_generation_agent: Optional[GenerationAgent] = None
_ga_lock = threading.Lock()


def get_generation_agent() -> GenerationAgent:
    global _generation_agent
    if _generation_agent is None:
        with _ga_lock:
            if _generation_agent is None:
                _generation_agent = GenerationAgent()
                _generation_agent.load()
    return _generation_agent
