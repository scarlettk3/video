"""
flow_record.py — Accumulates OpenFlow statistics into bidirectional flow records.

OpenFlow gives per-(match, dpid) counters.  This module:
  1. Receives raw OFP flow stat entries (as dicts) from the Ryu controller.
  2. Groups them into bidirectional flows keyed by the 5-tuple.
  3. Computes rate-based metrics (pktps, bytps, IAT approximations).
  4. Produces a list of dicts ready for feature extraction.

NOTE: CICFlowMeter computes features from full packet captures.  We reproduce
the same column names from OpenFlow flow statistics, using well-defined
approximations for fields that OFP does not expose directly (e.g. stdIAT).
All approximations are documented inline.
"""

import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


# Canonical 5-tuple key: (ip_proto, ip_src, ip_dst, port_src, port_dst)
# The "forward" direction is the one with the smaller (ip_src, port_src).
FlowKey = Tuple[int, str, str, int, int]


def _canonical_key(proto: int, ip_src: str, ip_dst: str,
                   port_src: int, port_dst: int) -> Tuple[FlowKey, bool]:
    """Return (canonical_key, is_forward).

    Forward direction: (src, dst) in lexicographic order so bidirectional
    flows always map to the same key regardless of which direction we see first.
    """
    fwd = (ip_src, port_src) <= (ip_dst, port_dst)
    if fwd:
        return (proto, ip_src, ip_dst, port_src, port_dst), True
    else:
        return (proto, ip_dst, ip_src, port_dst, port_src), False


@dataclass
class BidiFlow:
    """Bidirectional flow record accumulated from OFP stat entries."""
    key: FlowKey
    first_seen: float = field(default_factory=time.time)
    last_seen: float  = field(default_factory=time.time)

    # Forward direction
    fwd_pkts:  int = 0
    fwd_bytes: int = 0
    fwd_dur:   float = 0.0   # duration_sec + duration_nsec/1e9

    # Reverse direction
    rev_pkts:  int = 0
    rev_bytes: int = 0
    rev_dur:   float = 0.0

    # Additional packet-level metadata (best-effort from OFP match)
    ip_proto:  int = 6      # TCP default
    src_port:  int = 0
    dst_port:  int = 0
    eth_type:  int = 2048   # 0x0800 = IPv4
    vlan_id:   int = 0

    # Flow completeness marker (True once idle/hard timeout fires)
    terminated: bool = False

    def update_fwd(self, pkts: int, byt: int, dur: float) -> None:
        self.fwd_pkts  = pkts
        self.fwd_bytes = byt
        self.fwd_dur   = dur
        self.last_seen = time.time()

    def update_rev(self, pkts: int, byt: int, dur: float) -> None:
        self.rev_pkts  = pkts
        self.rev_bytes = byt
        self.rev_dur   = dur
        self.last_seen = time.time()

    @property
    def duration(self) -> float:
        return max(self.fwd_dur, self.rev_dur, 1e-6)

    @property
    def total_pkts(self) -> int:
        return self.fwd_pkts + self.rev_pkts

    @property
    def total_bytes(self) -> int:
        return self.fwd_bytes + self.rev_bytes

    def to_feature_dict(self) -> dict:
        """
        Produce a dict with the same column names as the training dataset.
        Approximations for OFP-unavailable fields are documented below.
        """
        dur     = self.duration
        fwd_p   = max(self.fwd_pkts,  1)
        rev_p   = max(self.rev_pkts,  0)
        fwd_b   = max(self.fwd_bytes, 0)
        rev_b   = max(self.rev_bytes, 0)
        tot_p   = fwd_p + rev_p
        tot_b   = fwd_b + rev_b

        # Average L7 payload estimate: OFP byte_count includes headers (~40 bytes
        # for TCP/IP).  We approximate L7 bytes = total_bytes − 40*pkts.
        hdr_overhead = 40
        l7_bytes_snt = max(fwd_b - hdr_overhead * fwd_p, 0)
        l7_bytes_rcv = max(rev_b - hdr_overhead * rev_p, 0)
        avg_l7_pkt   = l7_bytes_snt / fwd_p

        # Inter-arrival time: OFP gives total duration but not per-packet IATs.
        # Approximation: avgIAT = duration / pkts.  min/max/std are estimated as
        # fractions of avgIAT (conservative, keeps relative ordering intact).
        avg_iat = dur / fwd_p
        min_iat = avg_iat * 0.1          # LFA flows tend to be bursty → small min
        max_iat = avg_iat * 5.0          # tail inter-arrivals
        std_iat = avg_iat * 0.6          # rough CoV for flow traffic

        # Pad bytes: not available from OFP; set 0 (will be log1p-transformed)
        pad_bytes = 0

        # pktAsm: packet asymmetry index (−1 to +1)
        pkt_asm = (fwd_p - rev_p) / max(fwd_p + rev_p, 1)
        byt_asm = (fwd_b - rev_b) / max(fwd_b + rev_b, 1)

        # Packet/byte rates
        pktps = fwd_p / dur
        bytps = tot_b / dur

        # L7 packet sizes (std estimated as 30% of avg)
        min_l7 = max(20, avg_l7_pkt * 0.5)
        max_l7 = min(avg_l7_pkt * 2.0, 1500)
        std_l7 = avg_l7_pkt * 0.3

        # Number of headers (TCP/UDP has 1 or 2 header layers; approximate as 2)
        num_hdrs     = 2
        num_hdr_desc = 1

        # Port bucket
        src_bucket = _port_bucket(self.src_port)
        dst_bucket = _port_bucket(self.dst_port)

        # Direction encoding: 0=fwd dominant, 1=rev dominant
        pct_dir = 0 if fwd_p >= rev_p else 1

        # flowStat: 1=active, 0=terminated
        flow_stat = 0 if self.terminated else 1

        return {
            # -- Numeric (log-transformed in preprocessor) --
            "duration":    dur,
            "pktsSnt":     float(fwd_p),
            "pktsRcvd":    float(rev_p),
            "padBytesSnt": float(pad_bytes),
            "l7BytesSnt":  float(l7_bytes_snt),
            "l7BytesRcvd": float(l7_bytes_rcv),
            "minL7PktSz":  min_l7,
            "maxL7PktSz":  max_l7,
            "avgL7PktSz":  avg_l7_pkt,
            "stdL7PktSz":  std_l7,
            "minIAT":      min_iat,
            "maxIAT":      max_iat,
            "avgIAT":      avg_iat,
            "stdIAT":      std_iat,
            "pktps":       pktps,
            "bytps":       bytps,
            "pktAsm":      pkt_asm,
            "bytAsm":      byt_asm,
            # -- Other numeric --
            "numHdrDesc":  float(num_hdr_desc),
            "numHdrs":     float(num_hdrs),
            # -- Categorical --
            "%dir":        str(pct_dir),
            "flowStat":    str(flow_stat),
            "ethType":     str(self.eth_type),
            "vlanID":      str(self.vlan_id),
            "l4Proto":     str(self.ip_proto),
            "srcPort":     self.src_port,
            "dstPort":     self.dst_port,
            "srcPort_bucket": src_bucket,
            "dstPort_bucket": dst_bucket,
        }


def _port_bucket(port: int) -> str:
    """Map port number to coarse bucket (mirrors notebook's _bucket_single_port)."""
    if port <= 0:
        return "missing"
    if 0 <= port <= 1023:
        return "well_known"
    if 1024 <= port <= 49151:
        return "registered"
    return "ephemeral"


# ---------------------------------------------------------------------------
# FlowTable — stateful accumulator used by the Ryu controller
# ---------------------------------------------------------------------------

class FlowTable:
    """
    Stateful flow table updated on each OFP stats reply.
    Thread-safe: the controller's hub (greenlet) calls update(); the
    feature-extraction thread calls snapshot() to drain completed flows.
    """

    def __init__(self, idle_timeout_sec: float = 10.0):
        self._flows: Dict[FlowKey, BidiFlow] = {}
        self._idle_timeout = idle_timeout_sec
        import threading
        self._lock = threading.Lock()

    def update(self, stat_entry: dict) -> None:
        """
        Ingest one OFPFlowStats entry (as a dict produced by the controller).
        Expected keys: proto, ip_src, ip_dst, port_src, port_dst,
                       packet_count, byte_count, duration_sec, duration_nsec,
                       eth_type, vlan_id.
        """
        proto    = stat_entry.get("proto", 6)
        ip_src   = stat_entry.get("ip_src", "0.0.0.0")
        ip_dst   = stat_entry.get("ip_dst", "0.0.0.0")
        port_src = stat_entry.get("port_src", 0)
        port_dst = stat_entry.get("port_dst", 0)

        key, is_fwd = _canonical_key(proto, ip_src, ip_dst, port_src, port_dst)
        dur = (stat_entry.get("duration_sec", 0) +
               stat_entry.get("duration_nsec", 0) / 1e9)
        pkts = stat_entry.get("packet_count", 0)
        byt  = stat_entry.get("byte_count",  0)

        with self._lock:
            if key not in self._flows:
                flow = BidiFlow(
                    key=key,
                    ip_proto=proto,
                    src_port=key[3],
                    dst_port=key[4],
                    eth_type=stat_entry.get("eth_type", 2048),
                    vlan_id=stat_entry.get("vlan_id", 0),
                )
                self._flows[key] = flow
            else:
                flow = self._flows[key]

            if is_fwd:
                flow.update_fwd(pkts, byt, dur)
            else:
                flow.update_rev(pkts, byt, dur)

    def snapshot(self) -> List[dict]:
        """
        Return feature dicts for all current flows and remove stale/idle ones.
        Called by the feature extraction thread every detection window.
        """
        now = time.time()
        results = []
        stale_keys = []

        with self._lock:
            for key, flow in self._flows.items():
                if now - flow.last_seen > self._idle_timeout:
                    flow.terminated = True
                    stale_keys.append(key)
                results.append(flow.to_feature_dict())
            for k in stale_keys:
                del self._flows[k]

        return results

    def __len__(self) -> int:
        with self._lock:
            return len(self._flows)
