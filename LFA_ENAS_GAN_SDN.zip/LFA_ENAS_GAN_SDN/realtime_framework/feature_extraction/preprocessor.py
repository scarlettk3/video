"""
feature_extraction/preprocessor.py — Loads the fitted ColumnTransformer
(preprocessor.pkl) and feature column list (feature_columns.json) produced
by the notebook, exposes a thread-safe singleton.

Never retrain the preprocessor here — it must be identical to what the
Detection Agent was trained with.
"""

import json
import threading
from pathlib import Path
from typing import List, Optional

import joblib

from realtime_framework.config import PREPROCESSOR_PATH, FEATURE_COLUMNS_PATH
from realtime_framework.utils.logger import log_info, log_warn, log_error

# Thread-safe lazy singleton
_preproc   = None
_feat_cols: List[str] = []
_lock      = threading.Lock()


def load_preprocessor() -> bool:
    """
    Load preprocessor.pkl and feature_columns.json from disk.
    Returns True on success.  Safe to call multiple times.
    """
    global _preproc, _feat_cols

    if _preproc is not None:
        return True

    with _lock:
        if _preproc is not None:
            return True

        # Load ColumnTransformer
        p = Path(PREPROCESSOR_PATH)
        if not p.exists():
            log_error(
                f"preprocessor.pkl not found at {PREPROCESSOR_PATH}. "
                "Run the notebook first (cells 0-10) to generate artifacts."
            )
            return False

        try:
            _preproc = joblib.load(p)
            log_info(f"Loaded preprocessor from {p}")
        except Exception as exc:
            log_error(f"Failed to load preprocessor: {exc}")
            return False

        # Load feature column names
        fc = Path(FEATURE_COLUMNS_PATH)
        if fc.exists():
            with open(fc) as f:
                _feat_cols = json.load(f)
            log_info(f"Loaded {len(_feat_cols)} feature column names.")
        else:
            log_warn(f"feature_columns.json not found at {FEATURE_COLUMNS_PATH}.")

    return True


def get_preprocessor():
    """Return the loaded ColumnTransformer, loading lazily if needed."""
    if _preproc is None:
        load_preprocessor()
    return _preproc


def get_feature_columns() -> List[str]:
    """Return the ordered list of output feature column names."""
    if not _feat_cols:
        load_preprocessor()
    return _feat_cols


def feature_dim() -> int:
    """Return number of features after preprocessing (0 if not loaded yet)."""
    cols = get_feature_columns()
    return len(cols)
