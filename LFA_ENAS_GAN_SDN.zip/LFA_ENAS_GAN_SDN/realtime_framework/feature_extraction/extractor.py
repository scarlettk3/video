"""
feature_extraction/extractor.py — Converts a list of flow-record dicts
(from FlowTable.snapshot()) into a preprocessed numpy array ready for
the ENAS+GAN Detection Agent.

Replicates the notebook's engineer_features() pipeline:
  1. Add binary service-port flag columns
  2. Apply log1p transform to skewed numeric columns
  3. Apply the fitted ColumnTransformer (preprocessor.pkl) to get
     the same scaled + OHE feature vector the model was trained on.
"""

import time
import warnings
from typing import List, Optional, Tuple

import numpy as np
import pandas as pd

from realtime_framework.config import (
    LOG_TRANSFORM_COLUMNS, SERVICE_PORTS, PORT_COLUMNS,
)
from realtime_framework.feature_extraction.preprocessor import get_preprocessor
from realtime_framework.utils.logger import log_warn


def _add_service_flags(df: pd.DataFrame) -> pd.DataFrame:
    """Add binary srcPort_svc_N / dstPort_svc_N columns (mirror of notebook)."""
    for col in PORT_COLUMNS:
        if col not in df.columns:
            continue
        numeric_col = pd.to_numeric(df[col], errors="coerce")
        for svc_port in SERVICE_PORTS:
            df[f"{col}_svc_{svc_port}"] = (numeric_col == svc_port).astype(int)
    return df


def _apply_log_transform(df: pd.DataFrame) -> pd.DataFrame:
    """Apply log1p to known heavy-tailed numeric columns (mirror of notebook)."""
    for col in LOG_TRANSFORM_COLUMNS:
        if col in df.columns:
            numeric_col = pd.to_numeric(df[col], errors="coerce").fillna(0)
            df[col] = np.log1p(numeric_col.clip(lower=0))
    return df


def extract_features(flow_records: List[dict]) -> Optional[np.ndarray]:
    """
    Convert a list of flow-record dicts to a preprocessed feature matrix.

    Returns:
        numpy array of shape (n_flows, feature_dim)  or None if pipeline fails.

    The preprocessor is loaded lazily on first call (thread-safe singleton).
    """
    if not flow_records:
        return None

    preproc = get_preprocessor()
    if preproc is None:
        log_warn("Preprocessor not loaded — cannot extract features.")
        return None

    try:
        df = pd.DataFrame(flow_records)

        # 1. Add service-port binary flags
        df = _add_service_flags(df)

        # 2. Log1p transform heavy-tailed columns
        df = _apply_log_transform(df)

        # 3. Drop raw port numbers (model was trained without them)
        for col in PORT_COLUMNS:
            if col in df.columns:
                df = df.drop(columns=[col])

        # 4. Apply the fitted ColumnTransformer
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            X = preproc.transform(df)

        return X.astype(np.float32)

    except Exception as exc:
        log_warn(f"Feature extraction failed: {exc}")
        return None


def extract_window(flow_records: List[dict],
                   aggregate: str = "mean") -> Optional[np.ndarray]:
    """
    Produce a single 1-D feature vector representing the current window
    by aggregating across all flows (default: mean per feature).

    The Detection Agent can run per-flow (one row at a time) or per-window
    (one aggregate row).  Using mean aggregation mirrors the batch-inference
    mode used during evaluation.

    Args:
        flow_records: output of FlowTable.snapshot()
        aggregate:    "mean" | "max" | "median"

    Returns:
        1-D numpy array of shape (feature_dim,)  or None
    """
    X = extract_features(flow_records)
    if X is None or len(X) == 0:
        return None

    fn = {"mean": np.mean, "max": np.max, "median": np.median}.get(aggregate, np.mean)
    return fn(X, axis=0).astype(np.float32)
