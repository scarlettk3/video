"""
evaluation/latency_tracker.py — Thread-safe timestamp recording and latency calculation.

Records named timestamps for each detection window and computes:
  - generation_latency_ms       (ts_gen_decision → ts_traffic_start)
  - observation_latency_ms      (ts_traffic_start → stats_arrival)
  - feature_extraction_latency_ms
  - model_inference_latency_ms
  - end_to_end_detection_ms     (stats_arrival → inference_end)
  - mitigation_latency_ms       (inference_end → rule_installed)
  - total_response_ms           (ts_traffic_start → rule_installed)
  - network_recovery_time_ms    (rule_installed → congestion < threshold)

All timestamps are Unix epoch floats (time.time()).
Records are serialized to LATENCY_LOG as JSONL.
"""

import json
import threading
import time
from collections import defaultdict
from pathlib import Path
from typing import Dict, Optional

from realtime_framework.config import LATENCY_LOG

_LAT_PATH = Path(LATENCY_LOG)
_LAT_PATH.parent.mkdir(parents=True, exist_ok=True)


class LatencyTracker:
    """
    Records per-window timestamps and derives latency breakdowns.
    Thread-safe; writes completed records to JSONL immediately.
    """

    def __init__(self):
        self._lock       = threading.Lock()
        self._windows: Dict[int, dict]    = {}
        self._global: dict                = defaultdict(list)
        self._fh = open(_LAT_PATH, "a", buffering=1)

    # ------------------------------------------------------------------ #
    # Timestamp recording API (called from controller and agents)          #
    # ------------------------------------------------------------------ #

    def record(self, event: str, window_id: Optional[int] = None, **kwargs) -> None:
        """
        Record a named timestamp for a given window.

        event examples:
          stats_arrival, feature_extract_start, feature_extract_end,
          inference_start, inference_end, mitigation_decision, rule_installed,
          window_complete, recovery_detected
        """
        ts = time.time()
        with self._lock:
            if window_id is not None:
                if window_id not in self._windows:
                    self._windows[window_id] = {"window_id": window_id}
                self._windows[window_id][event + "_ts"] = ts
                self._windows[window_id].update(kwargs)

                # Flush completed windows
                self._try_flush(window_id)
            else:
                self._global[event].append({"ts": ts, **kwargs})

    # ------------------------------------------------------------------ #
    # Derived latencies                                                    #
    # ------------------------------------------------------------------ #

    def _compute_latencies(self, rec: dict) -> dict:
        """Compute all latency fields from recorded timestamps."""
        def ms(t1_key, t2_key) -> Optional[float]:
            t1 = rec.get(t1_key + "_ts")
            t2 = rec.get(t2_key + "_ts")
            if t1 and t2 and t2 > t1:
                return round((t2 - t1) * 1000, 3)
            return None

        return {
            "feature_extraction_latency_ms": ms("feature_extract_start", "feature_extract_end"),
            "inference_latency_ms":          ms("inference_start", "inference_end"),
            "end_to_end_detection_ms":       ms("stats_arrival", "inference_end"),
            "mitigation_latency_ms":         ms("inference_end", "rule_installed"),
            "total_response_ms":             ms("stats_arrival", "rule_installed"),
            "window_complete_latency_ms":    ms("feature_extract_start", "window_complete"),
        }

    def record_generation_latency(
        self, ts_decision: float, ts_traffic_start: float
    ) -> float:
        """Record and return generation latency in ms."""
        lat = (ts_traffic_start - ts_decision) * 1000
        with self._lock:
            self._global["generation_latency_ms"].append(
                {"ts": ts_traffic_start, "value": lat}
            )
        return lat

    def record_recovery(self, rule_installed_ts: float, recovery_ts: float) -> float:
        """Record and return network recovery time in ms."""
        lat = (recovery_ts - rule_installed_ts) * 1000
        with self._lock:
            self._global["network_recovery_ms"].append(
                {"ts": recovery_ts, "value": lat}
            )
        return lat

    # ------------------------------------------------------------------ #
    # JSONL flush                                                          #
    # ------------------------------------------------------------------ #

    def _try_flush(self, window_id: int) -> None:
        """Write a window record when it's sufficiently complete."""
        rec = self._windows.get(window_id, {})
        if "window_complete_ts" not in rec:
            return
        rec.update(self._compute_latencies(rec))
        self._fh.write(json.dumps(rec) + "\n")
        self._windows.pop(window_id, None)

    def flush_all(self) -> None:
        """Force-flush any remaining incomplete windows at experiment end."""
        with self._lock:
            for wid, rec in list(self._windows.items()):
                rec.update(self._compute_latencies(rec))
                self._fh.write(json.dumps(rec) + "\n")
            self._windows.clear()
            self._fh.flush()

    # ------------------------------------------------------------------ #
    # Summary statistics                                                   #
    # ------------------------------------------------------------------ #

    def summary(self) -> dict:
        """
        Return mean / median / p95 / p99 / max of key latencies
        across all completed windows.
        """
        import numpy as np

        self.flush_all()
        records = []
        with open(_LAT_PATH) as f:
            for line in f:
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    pass

        if not records:
            return {}

        def stats(key):
            vals = [r[key] for r in records if isinstance(r.get(key), (int, float))]
            if not vals:
                return {}
            a = np.array(vals)
            return {
                "mean_ms":   round(float(a.mean()), 3),
                "median_ms": round(float(np.median(a)), 3),
                "p95_ms":    round(float(np.percentile(a, 95)), 3),
                "p99_ms":    round(float(np.percentile(a, 99)), 3),
                "max_ms":    round(float(a.max()), 3),
                "n":         len(vals),
            }

        return {
            "feature_extraction": stats("feature_extraction_latency_ms"),
            "model_inference":    stats("inference_latency_ms"),
            "end_to_end_detection": stats("end_to_end_detection_ms"),
            "mitigation":         stats("mitigation_latency_ms"),
            "total_response":     stats("total_response_ms"),
        }

    def close(self) -> None:
        self.flush_all()
        self._fh.close()


# Module-level singleton
_tracker: Optional[LatencyTracker] = None
_tracker_lock = threading.Lock()


def get_latency_tracker() -> LatencyTracker:
    global _tracker
    if _tracker is None:
        with _tracker_lock:
            if _tracker is None:
                _tracker = LatencyTracker()
    return _tracker
