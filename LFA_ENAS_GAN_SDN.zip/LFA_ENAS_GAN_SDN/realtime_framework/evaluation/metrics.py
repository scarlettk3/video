"""
evaluation/metrics.py — All evaluation metrics for all three agents and scenarios.

Reads from:
  - LATENCY_LOG (latencies.jsonl)
  - GROUND_TRUTH_LOG (ground_truth.jsonl)
  - TELEMETRY_LOG (telemetry.jsonl)

Produces:
  - Detection Agent metrics (accuracy, precision, recall, F1, AUC, FPR, FNR)
  - Generation Agent metrics (evasion success rate, congestion achieved, etc.)
  - Mitigation Agent metrics (congestion reduction, recovery time, etc.)
  - Per-scenario breakdowns
  - METRICS_OUTPUT (metrics_summary.json)
"""

import json
from collections import defaultdict
from pathlib import Path
from typing import List, Optional

import numpy as np

from realtime_framework.config import (
    GROUND_TRUTH_LOG, LATENCY_LOG, TELEMETRY_LOG, METRICS_OUTPUT,
    SCENARIO_BENIGN, SCENARIO_CONV_LFA, SCENARIO_GAN_LFA, SCENARIO_ADAPTIVE_LFA,
    ACTION_NAMES,
)


# ---------------------------------------------------------------------------
# Helpers to load JSONL logs
# ---------------------------------------------------------------------------

def _load_jsonl(path: str) -> List[dict]:
    records = []
    p = Path(path)
    if not p.exists():
        return records
    with open(p) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return records


def _filter(records: List[dict], event: str) -> List[dict]:
    return [r for r in records if r.get("event") == event or r.get("gt_event") == event]


# ---------------------------------------------------------------------------
# Detection Agent metrics
# ---------------------------------------------------------------------------

def compute_detection_metrics(
    ground_truth_log: str = GROUND_TRUTH_LOG,
    telemetry_log:    str = TELEMETRY_LOG,
) -> dict:
    """
    Compute accuracy, precision, recall, F1, AUC, FPR, FNR for the Detection Agent.

    Ground truth labels are derived from the ground_truth.jsonl scenario timeline.
    Detection predictions come from 'detection' events in telemetry.jsonl.
    """
    gt_records  = _load_jsonl(ground_truth_log)
    tel_records = _load_jsonl(telemetry_log)

    # Build ground-truth attack timeline {ts: 0/1}
    attack_on = False
    gt_timeline = []   # [(ts, label)]
    for r in sorted(gt_records, key=lambda x: x.get("ts", 0)):
        ev = r.get("gt_event", "")
        if ev == "attack_start":
            attack_on = True
        elif ev == "attack_stop" or ev == "scenario_start" and r.get("scenario") == SCENARIO_BENIGN:
            attack_on = False
        gt_timeline.append((r.get("ts", 0), 1 if attack_on else 0))

    def _gt_label(ts: float) -> int:
        """Interpolate ground truth at detection timestamp."""
        label = 0
        for t, l in gt_timeline:
            if t <= ts:
                label = l
            else:
                break
        return label

    # Detection events
    det_events = _filter(tel_records, "detection")
    if not det_events:
        return {"error": "No detection events found in telemetry log."}

    y_true, y_pred, y_prob = [], [], []
    for ev in det_events:
        ts    = ev.get("ts", 0)
        prob  = ev.get("mean_prob", 0.5)
        pred  = ev.get("pred_label", int(prob >= 0.5))
        true  = _gt_label(ts)
        y_true.append(true)
        y_pred.append(pred)
        y_prob.append(prob)

    y_true = np.array(y_true)
    y_pred = np.array(y_pred)
    y_prob = np.array(y_prob)

    tp = int(((y_pred == 1) & (y_true == 1)).sum())
    tn = int(((y_pred == 0) & (y_true == 0)).sum())
    fp = int(((y_pred == 1) & (y_true == 0)).sum())
    fn = int(((y_pred == 0) & (y_true == 1)).sum())

    precision = tp / max(tp + fp, 1)
    recall    = tp / max(tp + fn, 1)
    f1        = 2 * precision * recall / max(precision + recall, 1e-9)
    accuracy  = (tp + tn) / max(len(y_true), 1)
    fpr       = fp / max(fp + tn, 1)
    fnr       = fn / max(fn + tp, 1)

    # AUC (trapezoidal)
    try:
        from sklearn.metrics import roc_auc_score
        auc = float(roc_auc_score(y_true, y_prob))
    except Exception:
        auc = _manual_auc(y_true, y_prob)

    return {
        "accuracy":   round(accuracy,  4),
        "precision":  round(precision, 4),
        "recall":     round(recall,    4),
        "f1_score":   round(f1,        4),
        "roc_auc":    round(auc,       4),
        "fpr":        round(fpr,       4),
        "fnr":        round(fnr,       4),
        "tp": tp, "tn": tn, "fp": fp, "fn": fn,
        "n_windows":  len(y_true),
    }


def _manual_auc(y_true, y_score) -> float:
    thresholds = np.sort(np.unique(y_score))[::-1]
    tpr_list, fpr_list = [0.0], [0.0]
    P = y_true.sum(); N = (1 - y_true).sum()
    if P == 0 or N == 0:
        return 0.5
    for t in thresholds:
        pred = (y_score >= t).astype(int)
        tpr_list.append(((pred == 1) & (y_true == 1)).sum() / P)
        fpr_list.append(((pred == 1) & (y_true == 0)).sum() / N)
    tpr_list.append(1.0); fpr_list.append(1.0)
    return float(np.trapz(tpr_list, fpr_list))


# ---------------------------------------------------------------------------
# Generation Agent metrics
# ---------------------------------------------------------------------------

def compute_generation_metrics(
    ground_truth_log: str = GROUND_TRUTH_LOG,
    telemetry_log:    str = TELEMETRY_LOG,
) -> dict:
    """
    Evasion success rate, congestion achieved, detector confidence over time,
    selected arm distribution.
    """
    gt_records  = _load_jsonl(ground_truth_log)
    tel_records = _load_jsonl(telemetry_log)

    bandit_updates = _filter(tel_records, "bandit_update")
    bandit_selects = _filter(tel_records, "bandit_select")
    det_events     = _filter(tel_records, "detection")

    # Evasion success rate: fraction of detection windows during attack where
    # pred_label == 0 (detector fooled)
    gt_rounds = [r for r in gt_records if r.get("gt_event") == "generation_round"]
    attack_windows = [
        ev for ev in det_events
        if any(r["ts"] <= ev.get("ts", 0) <= r.get("ts", 0) + 30
               for r in gt_rounds)
    ]
    if attack_windows:
        evasion_success = sum(1 for w in attack_windows if w.get("pred_label") == 0) / len(attack_windows)
    else:
        evasion_success = 0.0

    # Mean detector confidence during attack
    attack_confidences = [w.get("mean_prob", 0.5) for w in attack_windows]

    # Arm selection distribution
    arm_counts: dict = defaultdict(int)
    for ev in bandit_selects:
        arm_counts[str(ev.get("evasion_strength", 0.0))] += 1

    # Converged arm (highest arm value from last bandit_update)
    converged_arm = None
    if bandit_updates:
        last = bandit_updates[-1]
        arm_vals = last.get("arm_values", {})
        if arm_vals:
            converged_arm = max(arm_vals, key=lambda k: arm_vals[k])

    return {
        "evasion_success_rate":      round(evasion_success, 4),
        "n_attack_windows":          len(attack_windows),
        "mean_detector_confidence":  round(float(np.mean(attack_confidences)) if attack_confidences else 0.0, 4),
        "std_detector_confidence":   round(float(np.std(attack_confidences))  if attack_confidences else 0.0, 4),
        "arm_selection_counts":      dict(arm_counts),
        "converged_evasion_strength": converged_arm,
        "total_bandit_rounds":       len(bandit_updates),
    }


# ---------------------------------------------------------------------------
# Mitigation Agent metrics
# ---------------------------------------------------------------------------

def compute_mitigation_metrics(
    ground_truth_log: str = GROUND_TRUTH_LOG,
    telemetry_log:    str = TELEMETRY_LOG,
    latency_log:      str = LATENCY_LOG,
) -> dict:
    """
    Congestion reduction, recovery time, false mitigation rate, action distribution.
    """
    tel_records = _load_jsonl(telemetry_log)
    lat_records = _load_jsonl(latency_log)

    mit_events = _filter(tel_records, "mitigation_select")
    det_events = _filter(tel_records, "detection")

    # Action distribution
    action_counts: dict = defaultdict(int)
    for ev in mit_events:
        action_counts[ev.get("action_name", "unknown")] += 1
    total_actions = max(sum(action_counts.values()), 1)
    action_dist = {k: round(v / total_actions, 4) for k, v in action_counts.items()}

    # Recovery time from latency log
    recovery_vals = [
        r.get("network_recovery_ms", {}).get("value")
        for r in lat_records
        if isinstance(r.get("network_recovery_ms"), dict)
    ]
    recovery_vals = [v for v in recovery_vals if v is not None]

    # Mitigation latency distribution
    mit_lat_vals = [
        r.get("mitigation_latency_ms")
        for r in lat_records
        if isinstance(r.get("mitigation_latency_ms"), (int, float))
    ]

    # False mitigation rate: mitigations during benign periods
    benign_mit = sum(
        1 for ev in mit_events
        if ev.get("action_name") != "allow"
        # Heuristic: benign periods have low detection confidence
        and ev.get("pred_prob", 1.0) < 0.3
    )
    total_mit = sum(1 for ev in mit_events if ev.get("action_name") != "allow")

    return {
        "action_distribution":          action_dist,
        "n_mitigation_decisions":        len(mit_events),
        "unnecessary_mitigation_rate":   round(benign_mit / max(len(mit_events), 1), 4),
        "mean_recovery_time_ms":         round(float(np.mean(recovery_vals)) if recovery_vals else 0, 3),
        "p95_recovery_time_ms":          round(float(np.percentile(recovery_vals, 95)) if recovery_vals else 0, 3),
        "mean_mitigation_latency_ms":    round(float(np.mean(mit_lat_vals)) if mit_lat_vals else 0, 3),
        "p95_mitigation_latency_ms":     round(float(np.percentile(mit_lat_vals, 95)) if mit_lat_vals else 0, 3),
    }


# ---------------------------------------------------------------------------
# Full summary (combines all three agents)
# ---------------------------------------------------------------------------

def compute_all_metrics() -> dict:
    """Compute and save the complete metrics summary."""
    results = {
        "detection_agent":   compute_detection_metrics(),
        "generation_agent":  compute_generation_metrics(),
        "mitigation_agent":  compute_mitigation_metrics(),
    }

    output = Path(METRICS_OUTPUT)
    output.parent.mkdir(parents=True, exist_ok=True)
    with open(output, "w") as f:
        json.dump(results, f, indent=2)

    print(f"\n=== Metrics Summary ===")
    for agent, m in results.items():
        print(f"\n[{agent}]")
        for k, v in m.items():
            print(f"  {k:45s}: {v}")
    print(f"\nSaved → {output}")
    return results
