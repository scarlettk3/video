"""
evaluation/plotter.py — Synchronized time-series plots for the LFA experiment.

Generates the following figures:
  Fig 1: Ground-truth attack state + link utilization + detector confidence
  Fig 2: Predicted class over time + Agent 1 evasion mode
  Fig 3: Mitigation actions over time + congestion signal
  Fig 4: Network recovery trajectory
  Fig 5: Bandit arm value estimates over rounds
  Fig 6: Latency breakdown box plots

All figures read from:
  - GROUND_TRUTH_LOG  → attack periods
  - TELEMETRY_LOG     → detections, mitigation actions, bandit rounds
  - LATENCY_LOG       → latency distributions
"""

import json
from pathlib import Path
from typing import List, Optional

import numpy as np

from realtime_framework.config import (
    GROUND_TRUTH_LOG, TELEMETRY_LOG, LATENCY_LOG, PLOTS_DIR,
    BANDIT_EVASION_ARMS, ACTION_NAMES,
)

_DPI   = 150
_FIG_W = 14


def _load_jsonl(path: str) -> List[dict]:
    records = []
    p = Path(path)
    if not p.exists():
        return records
    with open(p) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return records


def _filter(records, *events):
    return [r for r in records if r.get("event") in events or r.get("gt_event") in events]


def _attack_spans(gt_records) -> List[tuple]:
    """Return list of (start_ts, end_ts, attack_type) from ground truth."""
    spans = []
    on = False; start = 0; atype = ""
    for r in sorted(gt_records, key=lambda x: x.get("ts", 0)):
        ev = r.get("gt_event", "")
        if ev == "attack_start":
            on = True; start = r["ts"]; atype = r.get("attack_type", "lfa")
        elif ev == "attack_stop" and on:
            spans.append((start, r["ts"], atype)); on = False
    return spans


def _shade_attacks(ax, spans, ts_min, ts_max, colors=None):
    """Add shaded attack windows to an axes."""
    _colors = {
        "conventional_lfa": "#FF9999",
        "gan_lfa":           "#FFB347",
        "adaptive_lfa":      "#FF6666",
    }
    for s, e, atype in spans:
        c = (_colors if colors is None else colors).get(atype, "#FFAAAA")
        ax.axvspan(max(s, ts_min), min(e, ts_max), alpha=0.25, color=c,
                   label=atype)


def plot_all() -> None:
    """Generate all figures and save to PLOTS_DIR."""
    import matplotlib
    matplotlib.use("Agg")  # headless
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches

    gt_records  = _load_jsonl(GROUND_TRUTH_LOG)
    tel_records = _load_jsonl(TELEMETRY_LOG)
    lat_records = _load_jsonl(LATENCY_LOG)

    Path(PLOTS_DIR).mkdir(parents=True, exist_ok=True)

    det_events = _filter(tel_records, "detection")
    mit_events = _filter(tel_records, "mitigation_select")
    ban_events = _filter(tel_records, "bandit_update")
    bsel_events= _filter(tel_records, "bandit_select")

    spans = _attack_spans(gt_records)
    if not det_events:
        print("[plotter] No detection events found — plots will be empty.")
        return

    ts_all = [r["ts"] for r in det_events]
    ts_min, ts_max = min(ts_all), max(ts_all)
    t_norm = lambda t: t - ts_min      # relative seconds

    # ─────────────────────────────────────────────────────────────────────
    # Fig 1: Ground-truth attack state / detection confidence / link util
    # ─────────────────────────────────────────────────────────────────────
    fig1, axes1 = plt.subplots(3, 1, figsize=(_FIG_W, 9), sharex=True)
    fig1.suptitle("Real-Time LFA Multi-Agent Framework — Detection Overview",
                  fontweight="bold", fontsize=12)

    # Panel A: Attack state (ground truth)
    ax = axes1[0]
    gt_ts = []; gt_lbl = []; at_on = 0
    for r in sorted(gt_records, key=lambda x: x.get("ts", 0)):
        ev = r.get("gt_event", "")
        if ev == "attack_start": at_on = 1
        elif ev == "attack_stop": at_on = 0
        gt_ts.append(t_norm(r.get("ts", ts_min)))
        gt_lbl.append(at_on)
    if gt_ts:
        ax.step(gt_ts, gt_lbl, where="post", color="#C44E52", linewidth=2)
    _shade_attacks(ax, [(t_norm(s), t_norm(e), a) for s, e, a in spans], 0, t_norm(ts_max))
    ax.set_ylabel("Attack Active"); ax.set_yticks([0, 1])
    ax.set_yticklabels(["Benign", "Attack"]); ax.grid(alpha=0.3)

    # Panel B: Detector confidence
    ax = axes1[1]
    det_ts   = [t_norm(r["ts"]) for r in det_events]
    det_prob = [r.get("mean_prob", 0.5) for r in det_events]
    ax.plot(det_ts, det_prob, color="#4C72B0", linewidth=1.4, label="ATTACK confidence")
    ax.axhline(0.5, linestyle="--", color="black", linewidth=0.9, label="threshold (0.5)")
    _shade_attacks(ax, [(t_norm(s), t_norm(e), a) for s, e, a in spans], 0, t_norm(ts_max))
    ax.set_ylabel("Detector Confidence"); ax.set_ylim(0, 1); ax.legend(fontsize=8)
    ax.grid(alpha=0.3)

    # Panel C: Predicted label
    ax = axes1[2]
    det_lbl = [r.get("pred_label", 0) for r in det_events]
    ax.step(det_ts, det_lbl, where="post", color="#55A868", linewidth=1.6)
    ax.set_ylabel("Predicted Label"); ax.set_yticks([0, 1])
    ax.set_yticklabels(["NORMAL", "ATTACK"]); ax.set_xlabel("Time (s)")
    ax.grid(alpha=0.3)

    plt.tight_layout()
    _save(fig1, "fig1_detection_overview.png")

    # ─────────────────────────────────────────────────────────────────────
    # Fig 2: Agent 1 — Evasion mode over time + bandit arm values
    # ─────────────────────────────────────────────────────────────────────
    fig2, axes2 = plt.subplots(2, 1, figsize=(_FIG_W, 6), sharex=False)
    fig2.suptitle("Agent 1 — LFA Generation Bandit", fontweight="bold", fontsize=12)

    # Panel A: Evasion strength selected over rounds
    ax = axes2[0]
    if bsel_events:
        rounds_ts = list(range(1, len(bsel_events) + 1))
        sel_e     = [r.get("evasion_strength", 0.0) for r in bsel_events]
        ax.step(rounds_ts, sel_e, where="post", color="#937860", linewidth=1.8)
        ax.set_ylabel("Evasion Strength Selected"); ax.set_xlabel("Bandit Round")
        ax.set_yticks(BANDIT_EVASION_ARMS); ax.grid(alpha=0.3)

    # Panel B: Per-arm value estimates over rounds
    ax = axes2[1]
    if ban_events:
        rounds = list(range(1, len(ban_events) + 1))
        for arm in BANDIT_EVASION_ARMS:
            vals = [r.get("arm_values", {}).get(str(arm), 0.0) for r in ban_events]
            ax.plot(rounds, vals, linewidth=1.6, label=f"e={arm}")
        ax.set_ylabel("Arm Value Estimate (1 − confidence)")
        ax.set_xlabel("Bandit Round")
        ax.legend(title="evasion_strength", fontsize=8); ax.grid(alpha=0.3)

    plt.tight_layout()
    _save(fig2, "fig2_bandit_arm_values.png")

    # ─────────────────────────────────────────────────────────────────────
    # Fig 3: Mitigation actions + congestion signal
    # ─────────────────────────────────────────────────────────────────────
    fig3, axes3 = plt.subplots(2, 1, figsize=(_FIG_W, 6), sharex=True)
    fig3.suptitle("Agent 3 — DQN Mitigation Actions & Congestion", fontweight="bold")

    # Panel A: Action chosen at each detection window
    ax = axes3[0]
    if mit_events:
        mit_ts  = [t_norm(r["ts"]) for r in mit_events]
        actions = [r.get("action", 0) for r in mit_events]
        sc = ax.scatter(mit_ts, actions, c=actions, cmap="Set2",
                        s=50, zorder=5)
        ax.set_yticks(list(range(5)))
        ax.set_yticklabels(ACTION_NAMES, fontsize=8)
        ax.set_ylabel("DQN Action"); ax.grid(alpha=0.3)
        _shade_attacks(ax, [(t_norm(s), t_norm(e), a) for s, e, a in spans], 0, t_norm(ts_max))

    # Panel B: Congestion signal (from mitigation events)
    ax = axes3[1]
    cong_ts   = [t_norm(r["ts"]) for r in mit_events if "congestion" in r]
    cong_vals = [r.get("congestion", 0.0) for r in mit_events if "congestion" in r]
    if cong_ts:
        ax.plot(cong_ts, cong_vals, color="#C44E52", linewidth=1.8, label="Congestion")
        ax.axhline(0.2, linestyle="--", color="grey", linewidth=0.9, label="Recovery threshold")
        ax.set_ylabel("Congestion Signal"); ax.set_ylim(0, 1.05)
        ax.set_xlabel("Time (s)"); ax.legend(fontsize=8); ax.grid(alpha=0.3)

    plt.tight_layout()
    _save(fig3, "fig3_mitigation_and_congestion.png")

    # ─────────────────────────────────────────────────────────────────────
    # Fig 4: Latency box plots
    # ─────────────────────────────────────────────────────────────────────
    fig4, ax4 = plt.subplots(1, 1, figsize=(10, 5))
    fig4.suptitle("Latency Breakdown (all detection windows)", fontweight="bold")

    lat_keys  = [
        ("feature_extraction_latency_ms", "Feature\nExtraction"),
        ("inference_latency_ms",          "Model\nInference"),
        ("end_to_end_detection_ms",       "End-to-End\nDetection"),
        ("mitigation_latency_ms",         "Mitigation\nDecision"),
        ("total_response_ms",             "Total\nResponse"),
    ]
    data = []
    labels = []
    for k, lbl in lat_keys:
        vals = [r[k] for r in lat_records if isinstance(r.get(k), (int, float)) and r[k] > 0]
        if vals:
            data.append(vals)
            labels.append(lbl)

    if data:
        bp = ax4.boxplot(data, labels=labels, patch_artist=True,
                         medianprops=dict(color="black", linewidth=2))
        for patch in bp["boxes"]:
            patch.set_facecolor("#4C72B0")
            patch.set_alpha(0.6)
        ax4.set_ylabel("Latency (ms)"); ax4.grid(axis="y", alpha=0.3)
        # Mark real-time threshold (stats poll interval)
        from realtime_framework.config import STATS_POLL_INTERVAL
        ax4.axhline(STATS_POLL_INTERVAL * 1000, linestyle="--", color="red",
                    linewidth=1.2, label=f"Poll interval ({STATS_POLL_INTERVAL}s)")
        ax4.legend(fontsize=9)

    plt.tight_layout()
    _save(fig4, "fig4_latency_breakdown.png")

    print(f"\n[plotter] Saved all figures → {PLOTS_DIR}/")


def _save(fig, filename: str) -> None:
    p = Path(PLOTS_DIR) / filename
    fig.savefig(p, dpi=_DPI, bbox_inches="tight")
    import matplotlib.pyplot as plt
    plt.close(fig)
    print(f"  Saved → {p}")
