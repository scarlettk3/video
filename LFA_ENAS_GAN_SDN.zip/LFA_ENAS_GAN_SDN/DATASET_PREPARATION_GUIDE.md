# Dataset Preparation Guide for ENAS+GAN+SDN LFA Detection

## Overview
This guide explains how to use the dataset merger and preprocessor for preparing CICFlowMeter data for ENAS+GAN+SDN training.

## Prerequisites

Install required packages in your virtual environment:

```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install pandas numpy scikit-learn
```

## Input Files

The script expects two CICFlowMeter CSV files in the same directory:

1. **attack3_microflow_100ms.csv** - First CICFlowMeter output
2. **final_merged.csv** - Second CICFlowMeter output

Both files will be automatically merged and processed.

## Running the Script

```bash
cd /Users/dp8407/Downloads/temp/LFA_ENAS_GAN_SDN
python3 merge_and_prepare_dataset.py
```

## What the Script Does

### Step 1: Load CSV Files
- Loads both CICFlowMeter CSV files
- Reports row and column counts

### Step 2: Feature Mapping & Standardization
- Standardizes column names between different CICFlowMeter formats
- Maps microflow features to standard CICFlowMeter names

### Step 3: Feature Selection
Selects 69+ critical features for LFA detection:
- **Flow statistics**: Duration, packet counts, byte counts
- **Packet length metrics**: Mean, std, min, max for forward/backward
- **Flow rates**: Bytes/s, Packets/s
- **Inter-arrival times**: IAT statistics (critical for timing attacks)
- **TCP flags**: SYN, ACK, FIN, RST, PSH, URG counts
- **Header lengths**: Forward and backward
- **Communication patterns**: Down/Up ratio, packet size avg
- **Subflow features**: Forward/backward subflow metrics
- **Window sizes**: Initial window sizes
- **Active/Idle times**: Burst detection metrics
- **Protocol info**: Protocol number, destination port

### Step 4: Merge Datasets
- Aligns columns between both files
- Concatenates all rows
- Removes duplicate header rows

### Step 5: Assign Labels
Intelligently assigns LFA attack labels based on traffic characteristics:

| Label | Detection Heuristic |
|-------|-------------------|
| **Normal** | Default or explicitly labeled normal traffic |
| **Traditional LFA** | Coordinated flooding patterns |
| **Flow-Rule Saturation** | Very high packet rate (>10K pkts/s) |
| **Topology Poisoning** | High SYN count (LLDP injection pattern) |
| **Telemetry Evasion** | High IAT variance (burst timing) |
| **Slice-Aware** | Highly asymmetric traffic (Down/Up ratio) |
| **Quantum-Inspired LFA** | High burst characteristics (Active/Idle ratio) |

### Step 6: Data Preprocessing
1. **Replace infinite values** with NaN
2. **Remove constant columns** (no variation)
3. **Remove high-missing columns** (>50% missing)
4. **Fill missing values** with median
5. **Remove duplicate rows**
6. **Cap outliers** at 1st and 99th percentiles
7. **Normalize features** using StandardScaler (zero mean, unit variance)

### Step 7: Save Dataset
Generates multiple output files for different use cases

### Step 8: Generate Report
Comprehensive statistics and quality metrics

## Output Files

### 1. ENAS_GAN_SDN_LFA_Dataset.csv
Main dataset with text labels and encoded labels.

**Columns:**
- All selected features (normalized)
- `Label` - Text label (Normal, Traditional LFA, etc.)
- `Label_Encoded` - Numeric label (0, 1, 2, ...)

**Usage:**
```python
import pandas as pd
df = pd.read_csv('ENAS_GAN_SDN_LFA_Dataset.csv')
X = df.drop(['Label', 'Label_Encoded'], axis=1)
y_text = df['Label']
y_encoded = df['Label_Encoded']
```

### 2. ENAS_GAN_SDN_LFA_Dataset_Encoded.csv
Dataset ready for direct training (numeric labels only).

**Columns:**
- All selected features (normalized)
- `Label` - Numeric label (0-6)

**Usage:**
```python
df = pd.read_csv('ENAS_GAN_SDN_LFA_Dataset_Encoded.csv')
X = df.drop('Label', axis=1).values
y = df['Label'].values

# Ready for train/test split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y)
```

### 3. scaler.pkl
StandardScaler object fitted on the training data.

**Usage:**
```python
import pickle

# Load scaler
with open('scaler.pkl', 'rb') as f:
    scaler = pickle.load(f)

# Transform new data during inference
X_new_scaled = scaler.transform(X_new)
```

### 4. label_encoder.pkl
LabelEncoder object for converting between text and numeric labels.

**Usage:**
```python
# Load encoder
with open('label_encoder.pkl', 'rb') as f:
    label_encoder = pickle.load(f)

# Convert predictions back to text
predictions_text = label_encoder.inverse_transform(predictions_numeric)

# Get all class names
classes = label_encoder.classes_
# ['Flow-Rule Saturation', 'Normal', 'Quantum-Inspired LFA', ...]
```

### 5. selected_features.txt
List of all features in the final dataset.

### 6. label_mapping.txt
Mapping between numeric codes and text labels with sample counts.

## Expected Output Report

```
================================================================================
  DATASET PROCESSING REPORT
================================================================================

📊 SAMPLE COUNTS:
  Before processing : 2,262,795 rows
  After merge       : 2,262,795 rows
  After cleaning    : 2,100,000 rows
  Removed           : 162,795 rows

📊 FEATURE COUNTS:
  Initial features  : 69 (target)
  After selection   : 65 (available)
  After cleaning    : 62 (final)

📊 CLASS DISTRIBUTION:
  Normal                        : 1,200,000 (57.14%) [Code: 0]
  Traditional LFA               : 400,000 (19.05%) [Code: 1]
  Flow-Rule Saturation          : 200,000 (9.52%) [Code: 2]
  Topology Poisoning            : 150,000 (7.14%) [Code: 3]
  Telemetry Evasion             : 80,000 (3.81%) [Code: 4]
  Slice-Aware                   : 50,000 (2.38%) [Code: 5]
  Quantum-Inspired LFA          : 20,000 (0.95%) [Code: 6]

📊 DATA QUALITY:
  Missing values    : 0
  Infinite values   : 0
  Duplicate rows    : 0
```

## Using with ENAS+GAN+SDN Training

### For ENAS (Architecture Search)

```python
import pandas as pd
import torch
from torch.utils.data import TensorDataset, DataLoader

# Load data
df = pd.read_csv('ENAS_GAN_SDN_LFA_Dataset_Encoded.csv')
X = df.drop('Label', axis=1).values
y = df['Label'].values

# Convert to PyTorch tensors
X_tensor = torch.FloatTensor(X)
y_tensor = torch.LongTensor(y)

# Create dataset and loader
dataset = TensorDataset(X_tensor, y_tensor)
train_loader = DataLoader(dataset, batch_size=64, shuffle=True)

# Use with ENAS search
# Your ENAS search code here...
```

### For GAN (Data Augmentation)

```python
# For class imbalance, GAN can generate synthetic samples
import pandas as pd

df = pd.read_csv('ENAS_GAN_SDN_LFA_Dataset_Encoded.csv')

# Separate minority classes
minority_class = df[df['Label'] == 6]  # Quantum-Inspired LFA
X_minority = minority_class.drop('Label', axis=1).values

# Train GAN to generate synthetic samples for minority class
# Your GAN training code here...
```

### For SDN Integration (Real-time Detection)

```python
import pickle
import numpy as np

# Load preprocessing objects
with open('scaler.pkl', 'rb') as f:
    scaler = pickle.load(f)

with open('label_encoder.pkl', 'rb') as f:
    label_encoder = pickle.load(f)

# During real-time detection from SDN controller
def detect_lfa(flow_features):
    """
    flow_features: dict with same keys as training features
    """
    # Convert to array in correct order
    feature_names = list(pd.read_csv('ENAS_GAN_SDN_LFA_Dataset_Encoded.csv', nrows=0).columns[:-1])
    X_new = np.array([[flow_features[f] for f in feature_names]])
    
    # Scale
    X_scaled = scaler.transform(X_new)
    
    # Predict (using trained model)
    prediction_encoded = model.predict(X_scaled)[0]
    
    # Decode
    attack_type = label_encoder.inverse_transform([prediction_encoded])[0]
    
    return attack_type
```

## Troubleshooting

### Issue: "ModuleNotFoundError: No module named 'sklearn'"
**Solution:** Activate venv and install dependencies:
```bash
source venv/bin/activate
pip install pandas numpy scikit-learn
```

### Issue: "FileNotFoundError: attack3_microflow_100ms.csv"
**Solution:** Ensure CSV files are in the same directory as the script.

### Issue: High number of removed rows
**Cause:** Duplicate rows or rows with too many missing values.
**Solution:** This is normal. Check the report for exact counts.

### Issue: Class imbalance (some classes have very few samples)
**Solution:** Use GAN for synthetic sample generation or apply SMOTE during training.

## Class Balance Recommendations

For optimal ENAS+GAN+SDN training:

1. **If class imbalance > 10:1 ratio:**
   - Use GAN to generate synthetic samples for minority classes
   - Apply class weights during training
   - Use stratified sampling

2. **If total samples < 100K per class:**
   - Run longer attack scenarios to collect more data
   - Use data augmentation via GAN
   - Consider ensemble methods

3. **For production deployment:**
   - Retrain periodically with new attack data
   - Monitor for concept drift
   - Update label encoders if new attack types emerge

## Next Steps

After preparing the dataset:

1. **Train/Val/Test Split:**
   ```python
   from sklearn.model_selection import train_test_split
   
   X_train, X_temp, y_train, y_temp = train_test_split(
       X, y, test_size=0.3, stratify=y, random_state=42
   )
   X_val, X_test, y_val, y_test = train_test_split(
       X_temp, y_temp, test_size=0.5, stratify=y_temp, random_state=42
   )
   ```

2. **ENAS Architecture Search:**
   - Use validation set for fitness evaluation
   - Search space: layer counts, neuron counts, activations
   - Target: maximize F1-score on validation set

3. **GAN Training:**
   - Train conditional GAN for each minority class
   - Generate synthetic samples to balance dataset
   - Validate quality using discriminator accuracy

4. **Final Model Training:**
   - Use ENAS-discovered architecture
   - Train on balanced dataset (original + GAN-generated)
   - Evaluate on held-out test set

5. **SDN Integration:**
   - Export model to ONNX or TorchScript
   - Integrate with Ryu controller
   - Deploy for real-time detection

## Contact & Support

For issues or questions, check the main project README or create an issue in the repository.
