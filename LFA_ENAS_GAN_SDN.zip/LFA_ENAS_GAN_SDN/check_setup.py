#!/usr/bin/env python3
"""
Quick verification script to check if dataset files and code are ready.
This can run WITHOUT scikit-learn to verify setup.
"""

import os
import sys

print("="*80)
print("  ENAS+GAN+SDN Dataset Preparation - Pre-flight Check")
print("="*80)

# Check 1: Python version
print("\n[1] Checking Python version...")
if sys.version_info >= (3, 7):
    print(f"    ✓ Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")
else:
    print(f"    ✗ Python {sys.version_info.major}.{sys.version_info.minor} (need >= 3.7)")

# Check 2: Input CSV files
print("\n[2] Checking input CSV files...")
csv_files = ['attack3_microflow_100ms.csv', 'final_merged.csv']
for csv_file in csv_files:
    if os.path.exists(csv_file):
        size_mb = os.path.getsize(csv_file) / (1024 * 1024)
        print(f"    ✓ {csv_file} ({size_mb:.2f} MB)")
    else:
        print(f"    ✗ {csv_file} NOT FOUND")

# Check 3: Main script
print("\n[3] Checking main script...")
if os.path.exists('merge_and_prepare_dataset.py'):
    size_kb = os.path.getsize('merge_and_prepare_dataset.py') / 1024
    print(f"    ✓ merge_and_prepare_dataset.py ({size_kb:.2f} KB)")
else:
    print(f"    ✗ merge_and_prepare_dataset.py NOT FOUND")

# Check 4: Required packages (optional check)
print("\n[4] Checking required packages...")
packages = {
    'pandas': 'Data manipulation',
    'numpy': 'Numerical operations',
    'sklearn': 'Machine learning preprocessing'
}

for package, description in packages.items():
    try:
        __import__(package)
        print(f"    ✓ {package:15s} - {description}")
    except ImportError:
        print(f"    ✗ {package:15s} - {description} (NOT INSTALLED)")

# Check 5: Disk space
print("\n[5] Checking available disk space...")
try:
    import shutil
    total, used, free = shutil.disk_usage(".")
    free_gb = free / (1024**3)
    if free_gb > 5:
        print(f"    ✓ {free_gb:.2f} GB free (sufficient)")
    else:
        print(f"    ⚠ {free_gb:.2f} GB free (may need more space)")
except:
    print(f"    ? Unable to check disk space")

# Check 6: Write permissions
print("\n[6] Checking write permissions...")
try:
    test_file = '.write_test_tmp'
    with open(test_file, 'w') as f:
        f.write('test')
    os.remove(test_file)
    print(f"    ✓ Directory is writable")
except:
    print(f"    ✗ Cannot write to current directory")

# Summary
print("\n" + "="*80)
print("  PRE-FLIGHT CHECK COMPLETE")
print("="*80)

print("\nIf all checks pass, you can run:")
print("  python3 merge_and_prepare_dataset.py")
print("\nIf packages are missing, install them first:")
print("  pip install pandas numpy scikit-learn")
print("="*80)
