#!/usr/bin/env python3
"""
=============================================================================
LFA-ENAS-GAN-SDN: Complete Training & Integration Pipeline
=============================================================================
Integrates ENAS + GAN + SDN for end-to-end LFA detection.

Pipeline:
  Step 1: Build/load dataset (from feature extraction or demo)
  Step 2: Run ENAS to discover optimal discriminator architecture
  Step 3: Train GAN with ENAS-optimized discriminator
  Step 4: Use discriminator as multi-class LFA detector
  Step 5: Evaluate on test set and save final model

Usage:
    # Full pipeline (ENAS search + GAN training):
    python3 models/train_model.py --full-pipeline --dataset ../datasets

    # Skip ENAS, use default architecture:
    python3 models/train_model.py --no-enas --epochs 100

    # Real-time SDN detection (connect to Ryu REST API):
    python3 models/train_model.py --realtime --controller 127.0.0.1
=============================================================================
"""

import os
import sys
import time
import json
import logging
import argparse
import threading
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import (
    classification_report, confusion_matrix,
    f1_score, accuracy_score, precision_score, recall_score
)
import joblib

# Local imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from models.gan_model import (
    Generator, GANTrainer, generate_synthetic_samples,
    NOISE_DIM, NUM_FEATURES, NUM_CLASSES, BATCH_SIZE, load_train_data
)
from models.enas_search import (
    ArchGenome, ENASDiscriminator, EvolutionarySearcher,
    FitnessEvaluator, run_enas
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [TRAIN] %(message)s'
)
LOG = logging.getLogger('Training')

LABEL_NAMES = [
    'Normal', 'Traditional LFA', 'Topology Poisoning',
    'Telemetry Evasion', 'Slice-Aware LFA',
    'Flow Saturation', 'Quantum LFA'
]

NUMERIC_FEATURES_LIST = [
    'flow_duration', 'fwd_packet_count', 'bwd_packet_count',
    'total_packet_count', 'fwd_byte_count', 'bwd_byte_count',
    'fwd_packet_len_mean', 'fwd_packet_len_std', 'bwd_packet_len_mean',
    'fwd_iat_mean', 'fwd_iat_std', 'flow_bytes_per_sec',
    'flow_pkts_per_sec', 'tcp_flag_ratio', 'src_entropy',
    'dst_entropy', 'port_entropy', 'unique_src_count',
    'unique_dst_count', 'bandwidth_utilization'
]


# =============================================================================
# Data Loading
# =============================================================================
def load_split(dataset_dir: str, split: str, device: str = 'cpu') -> DataLoader:
    """Load a train/val/test split CSV into a DataLoader."""
    path = os.path.join(dataset_dir, f'{split}.csv')
    if not os.path.exists(path):
        LOG.warning('%s.csv not found in %s. Using demo data.', split, dataset_dir)
        from feature_extraction.dataset_builder import _generate_demo_dataset, normalize_features
        df   = _generate_demo_dataset(3000)
        df, _= normalize_features(df)
    else:
        df = pd.read_csv(path)

    available = [f for f in NUMERIC_FEATURES_LIST if f in df.columns]
    X = df[available].fillna(0).values.astype(np.float32)
    y = df['label'].values.astype(np.int64)

    # Pad features to NUM_FEATURES
    if X.shape[1] < NUM_FEATURES:
        X = np.pad(X, ((0, 0), (0, NUM_FEATURES - X.shape[1])))

    dataset = TensorDataset(torch.from_numpy(X), torch.from_numpy(y))
    loader  = DataLoader(dataset, batch_size=BATCH_SIZE,
                         shuffle=(split == 'train'), drop_last=True)
    LOG.info('Loaded %s: %d samples', split, len(dataset))
    return loader


# =============================================================================
# GAN-Augmented Dataset Builder
# =============================================================================
def augment_with_gan(generator: nn.Module, train_df: pd.DataFrame,
                     device: str, augment_ratio: float = 0.3) -> pd.DataFrame:
    """
    Augment training set with GAN-generated synthetic samples.
    Particularly boosts under-represented attack classes.
    """
    LOG.info('Augmenting training data with GAN samples (ratio=%.1f)...', augment_ratio)
    new_rows = []

    for label in range(NUM_CLASSES):
        class_count = (train_df['label'] == label).sum()
        n_synthetic = int(class_count * augment_ratio)

        if n_synthetic > 0:
            synth = generate_synthetic_samples(
                generator, label, n_synthetic, device)
            for row in synth:
                d = dict(zip(NUMERIC_FEATURES_LIST[:len(row)], row.tolist()))
                d['label']      = label
                d['label_name'] = LABEL_NAMES[label]
                new_rows.append(d)

    synth_df = pd.DataFrame(new_rows)
    combined = pd.concat([train_df, synth_df], ignore_index=True)
    LOG.info('Augmented: %d → %d rows (+%d synthetic)',
             len(train_df), len(combined), len(synth_df))
    return combined


# =============================================================================
# Final Discriminator Training (classification only)
# =============================================================================
class LFADetectorTrainer:
    """
    Trains the ENAS-optimized discriminator as a pure multi-class classifier.
    After GAN pre-training, fine-tunes on labeled traffic data.
    """

    def __init__(self, model: nn.Module, device: str = 'cpu',
                 lr: float = 1e-3, weight_decay: float = 1e-4):
        self.model       = model.to(device)
        self.device      = device
        self.optimizer   = optim.AdamW(model.parameters(), lr=lr,
                                       weight_decay=weight_decay)
        self.scheduler   = optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer, T_max=100)
        self.criterion   = nn.CrossEntropyLoss()
        self.history     = {
            'train_loss': [], 'val_loss': [],
            'train_acc' : [], 'val_acc' : [],
            'train_f1'  : [], 'val_f1'  : []
        }

    def train_epoch(self, loader: DataLoader) -> dict:
        self.model.train()
        total_loss, all_preds, all_true = 0.0, [], []

        for batch_x, batch_y in loader:
            batch_x = batch_x.float().to(self.device)
            batch_y = batch_y.long().to(self.device)

            self.optimizer.zero_grad()
            _, cls_out = self.model(batch_x, batch_y)
            loss       = self.criterion(cls_out, batch_y)
            loss.backward()

            nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer.step()

            total_loss += loss.item()
            all_preds.extend(cls_out.argmax(1).cpu().numpy().tolist())
            all_true.extend(batch_y.cpu().numpy().tolist())

        avg_loss = total_loss / len(loader)
        f1  = f1_score(all_true, all_preds, average='macro', zero_division=0)
        acc = accuracy_score(all_true, all_preds)
        return {'loss': avg_loss, 'f1': f1, 'acc': acc}

    @torch.no_grad()
    def eval_epoch(self, loader: DataLoader) -> dict:
        self.model.eval()
        total_loss, all_preds, all_true = 0.0, [], []

        for batch_x, batch_y in loader:
            batch_x = batch_x.float().to(self.device)
            batch_y = batch_y.long().to(self.device)
            _, cls_out = self.model(batch_x, batch_y)
            loss       = self.criterion(cls_out, batch_y)

            total_loss += loss.item()
            all_preds.extend(cls_out.argmax(1).cpu().numpy().tolist())
            all_true.extend(batch_y.cpu().numpy().tolist())

        avg_loss = total_loss / len(loader)
        f1  = f1_score(all_true, all_preds, average='macro', zero_division=0)
        acc = accuracy_score(all_true, all_preds)
        return {'loss': avg_loss, 'f1': f1, 'acc': acc,
                'preds': all_preds, 'true': all_true}

    def train(self, train_loader: DataLoader, val_loader: DataLoader,
              num_epochs: int = 100, save_dir: str = 'checkpoints',
              patience: int = 15) -> str:
        """
        Train with early stopping and best model checkpoint.
        Returns path to best model.
        """
        os.makedirs(save_dir, exist_ok=True)
        best_val_f1    = 0.0
        patience_count = 0
        best_path      = os.path.join(save_dir, 'best_detector.pt')

        LOG.info('Training LFA Detector: %d epochs  patience=%d', num_epochs, patience)

        for epoch in range(1, num_epochs + 1):
            train_stats = self.train_epoch(train_loader)
            val_stats   = self.eval_epoch(val_loader)
            self.scheduler.step()

            self.history['train_loss'].append(train_stats['loss'])
            self.history['val_loss'].append(val_stats['loss'])
            self.history['train_acc'].append(train_stats['acc'])
            self.history['val_acc'].append(val_stats['acc'])
            self.history['train_f1'].append(train_stats['f1'])
            self.history['val_f1'].append(val_stats['f1'])

            if val_stats['f1'] > best_val_f1:
                best_val_f1    = val_stats['f1']
                patience_count = 0
                torch.save(self.model.state_dict(), best_path)
            else:
                patience_count += 1

            if epoch % 10 == 0:
                LOG.info('Ep[%03d/%03d] '
                         'train: loss=%.4f f1=%.4f | '
                         'val: loss=%.4f f1=%.4f acc=%.4f',
                         epoch, num_epochs,
                         train_stats['loss'], train_stats['f1'],
                         val_stats['loss'], val_stats['f1'], val_stats['acc'])

            if patience_count >= patience:
                LOG.info('Early stopping at epoch %d (best val F1=%.4f)',
                         epoch, best_val_f1)
                break

        LOG.info('Training complete. Best val F1: %.4f', best_val_f1)
        return best_path


# =============================================================================
# Evaluation
# =============================================================================
def evaluate_model(model: nn.Module, test_loader: DataLoader,
                   device: str) -> dict:
    """Full evaluation on test set."""
    model.eval()
    all_preds, all_true, all_probs = [], [], []
    inference_times = []

    with torch.no_grad():
        for batch_x, batch_y in test_loader:
            batch_x = batch_x.float().to(device)
            batch_y = batch_y.long().to(device)

            t0 = time.time()
            _, cls_out = model(batch_x, batch_y)
            t1 = time.time()

            inference_times.append((t1 - t0) / batch_x.size(0) * 1000)  # ms/sample
            probs = torch.softmax(cls_out, dim=1).cpu().numpy()
            preds = cls_out.argmax(1).cpu().numpy()

            all_preds.extend(preds.tolist())
            all_true.extend(batch_y.cpu().numpy().tolist())
            all_probs.extend(probs.tolist())

    # Compute metrics
    results = {
        'accuracy'      : round(accuracy_score(all_true, all_preds), 4),
        'precision_macro': round(precision_score(all_true, all_preds, average='macro',
                                                 zero_division=0), 4),
        'recall_macro'  : round(recall_score(all_true, all_preds, average='macro',
                                             zero_division=0), 4),
        'f1_macro'      : round(f1_score(all_true, all_preds, average='macro',
                                         zero_division=0), 4),
        'f1_weighted'   : round(f1_score(all_true, all_preds, average='weighted',
                                         zero_division=0), 4),
        'avg_latency_ms': round(np.mean(inference_times), 4),
        'confusion_matrix': confusion_matrix(all_true, all_preds).tolist(),
        'predictions'   : all_preds,
        'true_labels'   : all_true,
        'probabilities' : np.array(all_probs).tolist()
    }

    # Per-class F1
    per_class_f1 = f1_score(all_true, all_preds, average=None, zero_division=0)
    for i, name in enumerate(LABEL_NAMES):
        if i < len(per_class_f1):
            results[f'f1_{name.lower().replace(" ", "_")}'] = round(per_class_f1[i], 4)

    return results


# =============================================================================
# Real-Time SDN Detection
# =============================================================================
class RealtimeDetector:
    """
    Connects to the Ryu controller REST API and performs
    real-time LFA detection using the trained model.
    """

    def __init__(self, model: nn.Module, scaler, controller_ip: str,
                 device: str = 'cpu', poll_interval: float = 2.0):
        self.model         = model
        self.scaler        = scaler
        self.controller_ip = controller_ip
        self.device        = device
        self.poll_interval = poll_interval
        self.running       = False

        try:
            import requests
            self.requests = requests
        except ImportError:
            self.requests = None
            LOG.warning('requests library not found. Install with: pip3 install requests')

    def _fetch_telemetry(self) -> dict:
        """Fetch link stats from Ryu REST API."""
        if self.requests is None:
            # Simulate telemetry
            return {
                'dpid_0000000000000001': {
                    '1': {
                        'rx_bps': np.random.uniform(0, 15e6),
                        'tx_bps': np.random.uniform(0, 15e6),
                        'rx_packets': np.random.randint(0, 10000),
                        'tx_packets': np.random.randint(0, 10000)
                    }
                }
            }
        try:
            resp = self.requests.get(
                f'http://{self.controller_ip}:8080/stats/links',
                timeout=3)
            return resp.json()
        except Exception as e:
            LOG.debug('REST API error: %s', e)
            return {}

    def _telemetry_to_features(self, telemetry: dict) -> np.ndarray:
        """Convert raw telemetry dict to model feature vector."""
        features = np.zeros(NUM_FEATURES, dtype=np.float32)
        # Map available stats to feature positions
        if telemetry:
            for dpid, ports in telemetry.items():
                for port, stats in ports.items():
                    features[11] = float(stats.get('tx_bps', 0))  # bytes/sec
                    features[12] = float(stats.get('tx_packets', 0)) / max(1, 2.0)
                    features[19] = min(1.0, float(stats.get('tx_bps', 0)) / 10e6)
                    break
                break

        # Apply scaler
        if self.scaler is not None:
            try:
                features_2d = features.reshape(1, -1)[:, :self.scaler.n_features_in_]
                features_2d = self.scaler.transform(features_2d)
                features[:self.scaler.n_features_in_] = features_2d.flatten()
            except Exception:
                pass

        return features

    def predict(self, features: np.ndarray) -> tuple:
        """Run inference on a feature vector."""
        self.model.eval()
        with torch.no_grad():
            x = torch.from_numpy(features).unsqueeze(0).to(self.device)
            y = torch.zeros(1, dtype=torch.long).to(self.device)
            _, cls_out = self.model(x, y)
            probs = torch.softmax(cls_out, dim=1).cpu().numpy()[0]
            pred  = np.argmax(probs)
            conf  = probs[pred]
        return int(pred), float(conf), probs

    def run(self):
        """Main detection loop."""
        self.running = True
        LOG.info('Real-time SDN detection started (poll=%.1fs)', self.poll_interval)
        LOG.info('Controller: %s', self.controller_ip)

        alert_count = 0
        while self.running:
            telemetry = self._fetch_telemetry()
            features  = self._telemetry_to_features(telemetry)
            pred, conf, probs = self.predict(features)

            label_name = LABEL_NAMES[pred] if pred < len(LABEL_NAMES) else f'Class-{pred}'

            if pred != 0:   # Non-normal prediction
                alert_count += 1
                LOG.warning('ALERT #%d: %s detected (conf=%.2f%%)',
                            alert_count, label_name, conf * 100)
            else:
                LOG.debug('Normal traffic (conf=%.2f%%)', conf * 100)

            time.sleep(self.poll_interval)

    def stop(self):
        self.running = False


# =============================================================================
# Full Pipeline Orchestrator
# =============================================================================
def run_full_pipeline(dataset_dir: str, save_dir: str, device: str,
                      use_enas: bool = True, enas_generations: int = 20,
                      gan_epochs: int = 100, detector_epochs: int = 100,
                      skip_gan: bool = False):
    """
    End-to-end training pipeline:
    1. Load data
    2. ENAS search (optional)
    3. GAN training with ENAS discriminator
    4. Detector fine-tuning
    5. Evaluation
    """
    os.makedirs(save_dir, exist_ok=True)

    LOG.info('╔══════════════════════════════════════════════════════╗')
    LOG.info('║  ENAS + GAN + SDN = LFA Detection Pipeline          ║')
    LOG.info('╚══════════════════════════════════════════════════════╝')

    # ── Step 1: Load data ────────────────────────────────────────────────
    LOG.info('\n[Step 1] Loading dataset...')
    train_loader = load_split(dataset_dir, 'train', device)
    val_loader   = load_split(dataset_dir, 'val',   device)
    test_loader  = load_split(dataset_dir, 'test',  device)

    # ── Step 2: ENAS architecture search ─────────────────────────────────
    if use_enas:
        LOG.info('\n[Step 2] Running ENAS architecture search...')
        enas_result_path = os.path.join(save_dir, 'enas_results.json')

        if os.path.exists(enas_result_path):
            LOG.info('  Loading cached ENAS result: %s', enas_result_path)
            with open(enas_result_path) as f:
                enas_results = json.load(f)
            bg = enas_results['best_genome']
            best_genome = ArchGenome(
                layers      = bg['layers'],
                activations = bg['activations'],
                dropouts    = bg['dropouts'],
                norm_types  = bg['norm_types'],
                skip_connect= bg['skip_connect'],
                fitness     = bg['fitness'],
                f1_score    = bg['f1_score']
            )
        else:
            evaluator = FitnessEvaluator(train_loader, val_loader,
                                          eval_epochs=5, device=device)
            searcher  = EvolutionarySearcher(population_size=10)
            best_genome = searcher.evolve(
                evaluator, enas_generations,
                save_path=enas_result_path)

        LOG.info('  ENAS best arch: %s', best_genome.summary())
    else:
        LOG.info('\n[Step 2] Using default discriminator architecture...')
        best_genome = ArchGenome(
            layers      = [256, 128, 64],
            activations = ['leakyrelu', 'leakyrelu', 'leakyrelu'],
            dropouts    = [0.3, 0.2, 0.1],
            norm_types  = ['layernorm', 'layernorm', 'none']
        )

    # ── Step 3: Build models ──────────────────────────────────────────────
    LOG.info('\n[Step 3] Building ENAS-optimized GAN...')
    G = Generator(NOISE_DIM, NUM_CLASSES, NUM_FEATURES)
    D = ENASDiscriminator(best_genome, NUM_FEATURES, NUM_CLASSES)

    LOG.info('  Generator    : %d parameters', sum(p.numel() for p in G.parameters()))
    LOG.info('  Discriminator: %d parameters (ENAS-optimized)',
             sum(p.numel() for p in D.parameters()))

    # ── Step 4: GAN training ─────────────────────────────────────────────
    ckpt_dir = os.path.join(save_dir, 'checkpoints')
    if not skip_gan:
        LOG.info('\n[Step 4] Training GAN (%d epochs)...', gan_epochs)
        trainer = GANTrainer(G, D, device=device)
        history = trainer.train(train_loader, gan_epochs, ckpt_dir)
        LOG.info('  GAN training done. D_loss=%.4f  G_loss=%.4f',
                 history['d_loss'][-1], history['g_loss'][-1])
    else:
        LOG.info('\n[Step 4] Skipping GAN training (loading checkpoint)...')
        trainer = GANTrainer(G, D, device=device)
        trainer.load(ckpt_dir)

    # ── Step 5: Fine-tune discriminator as LFA detector ──────────────────
    LOG.info('\n[Step 5] Fine-tuning LFA detector...')
    det_trainer = LFADetectorTrainer(D, device=device, lr=5e-4)
    best_model_path = det_trainer.train(
        train_loader, val_loader,
        num_epochs=detector_epochs,
        save_dir=ckpt_dir
    )

    # Load best model for evaluation
    D.load_state_dict(torch.load(best_model_path, map_location=device))

    # ── Step 6: Final evaluation ──────────────────────────────────────────
    LOG.info('\n[Step 6] Evaluating on test set...')
    results = evaluate_model(D, test_loader, device)

    LOG.info('\n' + '=' * 55)
    LOG.info('FINAL EVALUATION RESULTS')
    LOG.info('=' * 55)
    LOG.info('  Accuracy           : %.4f', results['accuracy'])
    LOG.info('  Precision (macro)  : %.4f', results['precision_macro'])
    LOG.info('  Recall (macro)     : %.4f', results['recall_macro'])
    LOG.info('  F1-score (macro)   : %.4f', results['f1_macro'])
    LOG.info('  F1-score (weighted): %.4f', results['f1_weighted'])
    LOG.info('  Avg latency        : %.4f ms/sample', results['avg_latency_ms'])
    LOG.info('=' * 55)

    # Save results
    results_path = os.path.join(save_dir, 'test_results.json')
    results_save = {k: v for k, v in results.items()
                    if k not in ('predictions', 'true_labels', 'probabilities')}
    with open(results_path, 'w') as f:
        json.dump(results_save, f, indent=2)
    LOG.info('Results saved: %s', results_path)

    # Save training histories
    history_path = os.path.join(save_dir, 'training_history.json')
    with open(history_path, 'w') as f:
        json.dump({
            'detector_history': det_trainer.history
        }, f, indent=2)

    return D, G, results


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='LFA-ENAS-GAN Training Pipeline')
    parser.add_argument('--dataset',       default='../datasets',  help='Dataset directory')
    parser.add_argument('--save-dir',      default='../models',    help='Model save directory')
    parser.add_argument('--device',
                        default='cuda' if torch.cuda.is_available() else 'cpu')
    parser.add_argument('--no-enas',       action='store_true', help='Skip ENAS search')
    parser.add_argument('--skip-gan',      action='store_true', help='Skip GAN pre-training')
    parser.add_argument('--enas-gens',     type=int, default=20,  help='ENAS generations')
    parser.add_argument('--gan-epochs',    type=int, default=100, help='GAN epochs')
    parser.add_argument('--detector-epochs', type=int, default=100, help='Detector epochs')
    parser.add_argument('--realtime',      action='store_true', help='Run realtime detection')
    parser.add_argument('--controller',    default='127.0.0.1', help='Ryu controller IP')
    args = parser.parse_args()

    if args.realtime:
        # Load existing model and run real-time
        genome = ArchGenome(
            layers=[256, 128, 64],
            activations=['leakyrelu', 'leakyrelu', 'leakyrelu'],
            dropouts=[0.3, 0.2, 0.1],
            norm_types=['layernorm', 'layernorm', 'none']
        )
        model = ENASDiscriminator(genome, NUM_FEATURES, NUM_CLASSES)
        model_path = os.path.join(args.save_dir, 'checkpoints', 'best_detector.pt')
        if os.path.exists(model_path):
            model.load_state_dict(torch.load(model_path, map_location=args.device))
            LOG.info('Model loaded from %s', model_path)
        else:
            LOG.warning('No trained model found. Using random weights (demo only).')

        scaler_path = os.path.join(args.dataset, 'scaler.pkl')
        scaler = joblib.load(scaler_path) if os.path.exists(scaler_path) else None

        detector = RealtimeDetector(model, scaler, args.controller, args.device)
        try:
            detector.run()
        except KeyboardInterrupt:
            detector.stop()
    else:
        run_full_pipeline(
            dataset_dir     = args.dataset,
            save_dir        = args.save_dir,
            device          = args.device,
            use_enas        = not args.no_enas,
            enas_generations= args.enas_gens,
            gan_epochs      = args.gan_epochs,
            detector_epochs = args.detector_epochs,
            skip_gan        = args.skip_gan
        )
