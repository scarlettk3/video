#!/usr/bin/env python3
"""
=============================================================================
LFA-ENAS-GAN-SDN: GAN Model (Generator + Discriminator)
=============================================================================
Conditional GAN for:
  1. Synthetic attack traffic generation (data augmentation)
  2. LFA discriminator as the core detection model

Architecture:
  Generator (G):
    - Input: noise vector z (100-dim) + condition label (one-hot 7-class)
    - Hidden: 3 FC layers with BatchNorm + LeakyReLU
    - Output: synthetic feature vector (20-dim)

  Discriminator (D):
    - Input: feature vector (20-dim) + condition label
    - Hidden: determined by ENAS (this is what ENAS optimizes)
    - Output: [real/fake probability] + [class logits]

    The Discriminator has TWO heads:
      a) Adversarial head: is this real or generated? (binary)
      b) Classification head: which attack class is this? (7-class)

    This dual-head design means the ENAS-optimized discriminator
    is simultaneously the GAN discriminator AND the LFA detector.

Usage:
    python3 models/gan_model.py --train --epochs 200 --dataset ../datasets
    python3 models/gan_model.py --generate --samples 1000 --label 2
=============================================================================
"""

import os
import logging
import argparse
import numpy as np
import pandas as pd

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import torch.nn.functional as F

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [GAN] %(message)s'
)
LOG = logging.getLogger('GAN')

# Hyperparameters
NOISE_DIM    = 100
NUM_FEATURES = 20    # from feature extractor
NUM_CLASSES  = 7     # normal + 6 attack types
BATCH_SIZE   = 64
LR_G         = 0.0002
LR_D         = 0.0002
BETA1        = 0.5
BETA2        = 0.999
LAMBDA_CLS   = 1.0   # weight for classification loss


# =============================================================================
# Generator
# =============================================================================
class Generator(nn.Module):
    """
    Conditional GAN Generator.
    Takes noise z + class label → realistic feature vector.

    Architecture:
      [z(100) || label_embedding(32)] → FC(256) → FC(512) → FC(256) → FC(20)
    """

    def __init__(self, noise_dim: int = NOISE_DIM,
                 num_classes: int = NUM_CLASSES,
                 num_features: int = NUM_FEATURES,
                 embed_dim: int = 32):
        super().__init__()
        self.noise_dim    = noise_dim
        self.num_classes  = num_classes
        self.num_features = num_features

        # Label embedding
        self.label_embed = nn.Embedding(num_classes, embed_dim)

        input_dim = noise_dim + embed_dim

        self.model = nn.Sequential(
            # Layer 1
            nn.Linear(input_dim, 256),
            nn.BatchNorm1d(256),
            nn.LeakyReLU(0.2, inplace=True),

            # Layer 2
            nn.Linear(256, 512),
            nn.BatchNorm1d(512),
            nn.LeakyReLU(0.2, inplace=True),

            # Layer 3
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.LeakyReLU(0.2, inplace=True),

            # Output layer
            nn.Linear(256, num_features),
            nn.Sigmoid()   # features are MinMax normalized to [0,1]
        )

    def forward(self, z: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        """
        Args:
            z      : (batch, noise_dim) random noise
            labels : (batch,) integer class labels
        Returns:
            fake   : (batch, num_features) synthetic feature vectors
        """
        label_emb = self.label_embed(labels)          # (batch, embed_dim)
        inp       = torch.cat([z, label_emb], dim=1)  # (batch, noise_dim + embed_dim)
        return self.model(inp)


# =============================================================================
# Discriminator Base (will be replaced by ENAS-optimized version)
# =============================================================================
class DiscriminatorBase(nn.Module):
    """
    Base Discriminator for the cGAN.
    This class serves as the TEMPLATE; ENAS will search for the optimal
    architecture to replace the hidden layers.

    Dual-head:
      - Adversarial head: p(real) ∈ [0,1]
      - Classification head: p(class) ∈ [0,1]^7
    """

    def __init__(self, num_features: int = NUM_FEATURES,
                 num_classes: int = NUM_CLASSES,
                 hidden_config: list = None):
        """
        Args:
            num_features  : Input feature dimension
            num_classes   : Number of attack classes
            hidden_config : List of hidden layer sizes (ENAS searchable)
                           Default: [256, 128] (2 layers)
        """
        super().__init__()
        self.num_features = num_features
        self.num_classes  = num_classes

        if hidden_config is None:
            hidden_config = [256, 128]

        # Label embedding for conditioning
        self.label_embed = nn.Embedding(num_classes, 32)
        input_dim        = num_features + 32

        # Build hidden layers from config
        layers = []
        in_dim = input_dim
        for out_dim in hidden_config:
            layers += [
                nn.Linear(in_dim, out_dim),
                nn.LayerNorm(out_dim),
                nn.LeakyReLU(0.2, inplace=True),
                nn.Dropout(0.3)
            ]
            in_dim = out_dim

        self.shared = nn.Sequential(*layers)

        # Adversarial head: real vs. fake
        self.adv_head = nn.Sequential(
            nn.Linear(in_dim, 64),
            nn.LeakyReLU(0.2),
            nn.Linear(64, 1)   # raw logit (no sigmoid — use BCEWithLogitsLoss)
        )

        # Classification head: attack class prediction
        self.cls_head = nn.Sequential(
            nn.Linear(in_dim, 64),
            nn.LeakyReLU(0.2),
            nn.Linear(64, num_classes)
        )

    def forward(self, x: torch.Tensor, labels: torch.Tensor):
        """
        Args:
            x      : (batch, num_features) feature vector
            labels : (batch,) integer class labels
        Returns:
            adv_out : (batch, 1) adversarial logit
            cls_out : (batch, num_classes) classification logits
        """
        label_emb = self.label_embed(labels)
        inp       = torch.cat([x, label_emb], dim=1)
        shared    = self.shared(inp)
        adv_out   = self.adv_head(shared)
        cls_out   = self.cls_head(shared)
        return adv_out, cls_out


# =============================================================================
# GAN Training
# =============================================================================
class GANTrainer:
    """
    Trains the GAN with both adversarial and classification objectives.
    """

    def __init__(self, generator: nn.Module, discriminator: nn.Module,
                 device: str = 'cpu', lr_g: float = LR_G, lr_d: float = LR_D):
        self.G   = generator.to(device)
        self.D   = discriminator.to(device)
        self.dev = device

        self.opt_G = optim.Adam(self.G.parameters(), lr=lr_g,
                                betas=(BETA1, BETA2))
        self.opt_D = optim.Adam(self.D.parameters(), lr=lr_d,
                                betas=(BETA1, BETA2))

        self.adv_loss = nn.BCEWithLogitsLoss()
        self.cls_loss = nn.CrossEntropyLoss()

        # History for plotting
        self.history = {
            'g_loss': [], 'd_loss': [], 'd_adv_loss': [],
            'd_cls_loss': [], 'g_adv_loss': [], 'g_cls_loss': []
        }

    def train_discriminator(self, real_x: torch.Tensor,
                             real_y: torch.Tensor) -> dict:
        """Train discriminator on one batch."""
        batch_size = real_x.size(0)
        self.opt_D.zero_grad()

        # Real samples
        real_labels = torch.ones(batch_size, 1, device=self.dev)
        adv_real, cls_real = self.D(real_x, real_y)
        d_adv_real  = self.adv_loss(adv_real, real_labels)
        d_cls_real  = self.cls_loss(cls_real, real_y)

        # Fake samples
        z         = torch.randn(batch_size, self.G.noise_dim, device=self.dev)
        fake_y    = torch.randint(0, self.G.num_classes, (batch_size,), device=self.dev)
        fake_x    = self.G(z, fake_y).detach()

        fake_labels = torch.zeros(batch_size, 1, device=self.dev)
        adv_fake, _ = self.D(fake_x, fake_y)
        d_adv_fake  = self.adv_loss(adv_fake, fake_labels)

        # Total discriminator loss
        d_loss = d_adv_real + d_adv_fake + LAMBDA_CLS * d_cls_real
        d_loss.backward()
        self.opt_D.step()

        return {
            'd_loss'    : d_loss.item(),
            'd_adv_loss': (d_adv_real + d_adv_fake).item(),
            'd_cls_loss': d_cls_real.item()
        }

    def train_generator(self, batch_size: int) -> dict:
        """Train generator on one batch."""
        self.opt_G.zero_grad()

        z      = torch.randn(batch_size, self.G.noise_dim, device=self.dev)
        fake_y = torch.randint(0, self.G.num_classes, (batch_size,), device=self.dev)
        fake_x = self.G(z, fake_y)

        # Generator wants discriminator to think fake=real
        real_labels     = torch.ones(batch_size, 1, device=self.dev)
        adv_out, cls_out = self.D(fake_x, fake_y)

        g_adv_loss = self.adv_loss(adv_out, real_labels)
        g_cls_loss = self.cls_loss(cls_out, fake_y)   # fake samples should be classifiable
        g_loss     = g_adv_loss + LAMBDA_CLS * g_cls_loss

        g_loss.backward()
        self.opt_G.step()

        return {
            'g_loss'    : g_loss.item(),
            'g_adv_loss': g_adv_loss.item(),
            'g_cls_loss': g_cls_loss.item()
        }

    def train(self, dataloader: DataLoader, num_epochs: int = 200,
              save_dir: str = 'checkpoints', d_steps: int = 2):
        """
        Full GAN training loop.

        Args:
            dataloader  : DataLoader with (features, labels) batches
            num_epochs  : Training epochs
            save_dir    : Directory for model checkpoints
            d_steps     : Discriminator update steps per generator step
        """
        os.makedirs(save_dir, exist_ok=True)
        LOG.info('Starting GAN training: epochs=%d  device=%s', num_epochs, self.dev)

        for epoch in range(1, num_epochs + 1):
            epoch_stats = {'d_loss': 0, 'g_loss': 0, 'd_cls_loss': 0, 'n': 0}

            for batch_x, batch_y in dataloader:
                batch_x = batch_x.float().to(self.dev)
                batch_y = batch_y.long().to(self.dev)
                bs      = batch_x.size(0)

                # Train D multiple times per G update
                for _ in range(d_steps):
                    d_stats = self.train_discriminator(batch_x, batch_y)

                # Train G once
                g_stats = self.train_generator(bs)

                epoch_stats['d_loss']    += d_stats['d_loss']
                epoch_stats['g_loss']    += g_stats['g_loss']
                epoch_stats['d_cls_loss']+= d_stats['d_cls_loss']
                epoch_stats['n']         += 1

            # Average losses
            n = epoch_stats['n']
            d_avg = epoch_stats['d_loss']    / n
            g_avg = epoch_stats['g_loss']    / n
            c_avg = epoch_stats['d_cls_loss']/ n

            self.history['d_loss'].append(d_avg)
            self.history['g_loss'].append(g_avg)
            self.history['d_cls_loss'].append(c_avg)

            if epoch % 10 == 0:
                LOG.info('Epoch [%03d/%03d]  D_loss=%.4f  G_loss=%.4f  D_cls=%.4f',
                         epoch, num_epochs, d_avg, g_avg, c_avg)

            # Save checkpoint every 50 epochs
            if epoch % 50 == 0:
                self.save(save_dir, epoch)

        LOG.info('GAN training complete.')
        self.save(save_dir, num_epochs, final=True)
        return self.history

    def save(self, save_dir: str, epoch: int, final: bool = False):
        suffix = 'final' if final else f'epoch{epoch}'
        torch.save(self.G.state_dict(),
                   os.path.join(save_dir, f'generator_{suffix}.pt'))
        torch.save(self.D.state_dict(),
                   os.path.join(save_dir, f'discriminator_{suffix}.pt'))
        LOG.info('Saved checkpoint: %s', suffix)

    def load(self, save_dir: str, suffix: str = 'final'):
        g_path = os.path.join(save_dir, f'generator_{suffix}.pt')
        d_path = os.path.join(save_dir, f'discriminator_{suffix}.pt')
        if os.path.exists(g_path):
            self.G.load_state_dict(torch.load(g_path, map_location=self.dev))
        if os.path.exists(d_path):
            self.D.load_state_dict(torch.load(d_path, map_location=self.dev))
        LOG.info('Loaded checkpoint: %s', suffix)


# =============================================================================
# Synthetic Data Generator (for dataset augmentation)
# =============================================================================
def generate_synthetic_samples(generator: nn.Module, label: int,
                                n_samples: int = 1000,
                                device: str = 'cpu') -> np.ndarray:
    """
    Generate synthetic attack traffic features using the trained Generator.

    Args:
        generator : Trained Generator model
        label     : Attack class label (0-6)
        n_samples : Number of synthetic samples to generate
        device    : torch device

    Returns:
        samples   : (n_samples, num_features) numpy array
    """
    generator.eval()
    with torch.no_grad():
        z      = torch.randn(n_samples, generator.noise_dim, device=device)
        labels = torch.full((n_samples,), label, dtype=torch.long, device=device)
        fake   = generator(z, labels)
    return fake.cpu().numpy()


# =============================================================================
# Dataset Loader Helper
# =============================================================================
def load_train_data(dataset_dir: str) -> DataLoader:
    """Load training data from CSV and return DataLoader."""
    NUMERIC_FEATURES = [
        'flow_duration', 'fwd_packet_count', 'bwd_packet_count',
        'total_packet_count', 'fwd_byte_count', 'bwd_byte_count',
        'fwd_packet_len_mean', 'fwd_packet_len_std', 'bwd_packet_len_mean',
        'fwd_iat_mean', 'fwd_iat_std', 'flow_bytes_per_sec',
        'flow_pkts_per_sec', 'tcp_flag_ratio', 'src_entropy',
        'dst_entropy', 'port_entropy', 'unique_src_count',
        'unique_dst_count', 'bandwidth_utilization'
    ]

    train_path = os.path.join(dataset_dir, 'train.csv')
    if not os.path.exists(train_path):
        LOG.warning('train.csv not found. Run dataset_builder.py --demo first.')
        # Create minimal demo data
        df = pd.DataFrame(
            np.random.rand(1000, 20),
            columns=NUMERIC_FEATURES
        )
        df['label'] = np.random.randint(0, NUM_CLASSES, 1000)
    else:
        df = pd.read_csv(train_path)

    # Select only numeric feature columns
    available_feats = [f for f in NUMERIC_FEATURES if f in df.columns]
    X = df[available_feats].fillna(0).values.astype(np.float32)
    y = df['label'].values.astype(np.int64)

    dataset    = TensorDataset(torch.from_numpy(X), torch.from_numpy(y))
    dataloader = DataLoader(dataset, batch_size=BATCH_SIZE,
                            shuffle=True, num_workers=0, drop_last=True)
    LOG.info('Loaded training data: %d samples, %d features', len(dataset), X.shape[1])
    return dataloader


# =============================================================================
# Main
# =============================================================================
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='GAN Training & Generation')
    parser.add_argument('--train',    action='store_true', help='Train the GAN')
    parser.add_argument('--generate', action='store_true', help='Generate samples')
    parser.add_argument('--epochs',   type=int, default=200, help='Training epochs')
    parser.add_argument('--dataset',  default='../datasets',  help='Dataset directory')
    parser.add_argument('--save-dir', default='../models/checkpoints',
                        help='Checkpoint directory')
    parser.add_argument('--label',    type=int, default=1,  help='Class for generation')
    parser.add_argument('--samples',  type=int, default=500, help='Samples to generate')
    parser.add_argument('--device',   default='cuda' if torch.cuda.is_available() else 'cpu')
    args = parser.parse_args()

    device = args.device
    LOG.info('Device: %s', device)

    G = Generator(NOISE_DIM, NUM_CLASSES, NUM_FEATURES)
    D = DiscriminatorBase(NUM_FEATURES, NUM_CLASSES, hidden_config=[256, 128])

    LOG.info('Generator parameters: %d', sum(p.numel() for p in G.parameters()))
    LOG.info('Discriminator parameters: %d', sum(p.numel() for p in D.parameters()))

    trainer = GANTrainer(G, D, device=device)

    if args.train:
        dataloader = load_train_data(args.dataset)
        history    = trainer.train(dataloader,
                                   num_epochs=args.epochs,
                                   save_dir=args.save_dir)
        LOG.info('Final losses — D: %.4f  G: %.4f',
                 history['d_loss'][-1], history['g_loss'][-1])

    if args.generate:
        trainer.load(args.save_dir)
        LOG.info('Generating %d synthetic samples for class %d...', args.samples, args.label)
        samples = generate_synthetic_samples(G, args.label, args.samples, device)
        out_path = os.path.join(args.dataset, f'synthetic_class{args.label}.npy')
        np.save(out_path, samples)
        LOG.info('Saved synthetic samples: %s  shape=%s', out_path, samples.shape)
