#!/usr/bin/env python3
"""
=============================================================================
LFA-ENAS-GAN-SDN: Evolutionary Neural Architecture Search (ENAS)
=============================================================================
ENAS automatically discovers the optimal discriminator architecture for the
GAN-based LFA detector without manual tuning.

Algorithm:
  1. Initialize population of N candidate architectures (random genomes)
  2. Evaluate each: train discriminator, measure fitness (F1-score on LFA)
  3. Selection: tournament selection of top-k individuals
  4. Crossover: combine architecture genes from two parents
  5. Mutation: randomly modify layer sizes, activation functions, depth
  6. Iterate for G generations
  7. Return best architecture → build optimized Discriminator

Search Space:
  - Number of hidden layers: 1..5
  - Layer width per layer: {32, 64, 128, 256, 512}
  - Activation function: {ReLU, LeakyReLU, ELU, SELU, Tanh}
  - Dropout rate: {0.0, 0.1, 0.2, 0.3, 0.5}
  - Use BatchNorm/LayerNorm: {True, False}
  - Skip connections: {True, False}

Usage:
    python3 models/enas_search.py \
        --dataset ../datasets \
        --population 20 \
        --generations 30 \
        --eval-epochs 10
=============================================================================
"""

import os
import copy
import random
import logging
import argparse
import time
import json
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import f1_score, accuracy_score
from sklearn.preprocessing import LabelEncoder

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [ENAS] %(message)s'
)
LOG = logging.getLogger('ENAS')

# ── Architecture search space ───────────────────────────────────────────────
LAYER_WIDTHS    = [32, 64, 128, 256, 512]
ACTIVATIONS     = ['relu', 'leakyrelu', 'elu', 'selu', 'tanh']
DROPOUT_RATES   = [0.0, 0.1, 0.2, 0.3, 0.5]
NORM_TYPES      = ['none', 'batchnorm', 'layernorm']
MIN_LAYERS      = 1
MAX_LAYERS      = 5

# ── Problem constants ────────────────────────────────────────────────────────
NUM_FEATURES    = 20
NUM_CLASSES     = 7
NOISE_DIM       = 100


# =============================================================================
# Architecture Genome
# =============================================================================
@dataclass
class ArchGenome:
    """
    Encodes the architecture of the Discriminator hidden layers as a genome.
    This is the "chromosome" that ENAS evolves.
    """
    layers       : List[int]    # hidden layer widths e.g. [256, 128, 64]
    activations  : List[str]    # per-layer activation functions
    dropouts     : List[float]  # per-layer dropout rates
    norm_types   : List[str]    # per-layer normalization
    skip_connect : bool = False # use residual connections

    # Fitness (set after evaluation)
    fitness      : float = 0.0
    f1_score     : float = 0.0
    accuracy     : float = 0.0
    train_time_s : float = 0.0

    def __post_init__(self):
        n = len(self.layers)
        # Ensure all lists match layer count
        while len(self.activations) < n:
            self.activations.append(random.choice(ACTIVATIONS))
        while len(self.dropouts) < n:
            self.dropouts.append(random.choice(DROPOUT_RATES))
        while len(self.norm_types) < n:
            self.norm_types.append(random.choice(NORM_TYPES))
        self.activations = self.activations[:n]
        self.dropouts    = self.dropouts[:n]
        self.norm_types  = self.norm_types[:n]

    def to_dict(self) -> dict:
        return {
            'layers'      : self.layers,
            'activations' : self.activations,
            'dropouts'    : self.dropouts,
            'norm_types'  : self.norm_types,
            'skip_connect': self.skip_connect,
            'fitness'     : round(self.fitness, 4),
            'f1_score'    : round(self.f1_score, 4),
            'accuracy'    : round(self.accuracy, 4),
            'train_time_s': round(self.train_time_s, 2),
            'num_params'  : self.estimate_params()
        }

    def estimate_params(self) -> int:
        """Estimate total parameter count without building the model."""
        total = 0
        in_dim = NUM_FEATURES + 32   # + label embedding
        for width in self.layers:
            total += in_dim * width + width  # linear weight + bias
            in_dim = width
        total += in_dim * 1 + 1     # adv head (simplified)
        total += in_dim * NUM_CLASSES + NUM_CLASSES   # cls head
        return total

    def summary(self) -> str:
        layers_str = '→'.join(str(w) for w in self.layers)
        return (f'[{layers_str}] '
                f'act={self.activations[0] if self.activations else "?"} '
                f'skip={self.skip_connect} '
                f'fitness={self.fitness:.4f} '
                f'f1={self.f1_score:.4f}')


# =============================================================================
# Genome → PyTorch Model
# =============================================================================
def activation_fn(name: str) -> nn.Module:
    """Return activation module by name."""
    return {
        'relu'     : nn.ReLU(inplace=True),
        'leakyrelu': nn.LeakyReLU(0.2, inplace=True),
        'elu'      : nn.ELU(),
        'selu'     : nn.SELU(),
        'tanh'     : nn.Tanh(),
    }.get(name, nn.LeakyReLU(0.2))


def norm_layer(name: str, num_features: int) -> Optional[nn.Module]:
    """Return normalization module by name."""
    return {
        'batchnorm': nn.BatchNorm1d(num_features),
        'layernorm': nn.LayerNorm(num_features),
        'none'     : None,
    }.get(name, None)


class ENASDiscriminator(nn.Module):
    """
    Discriminator built from an ArchGenome.
    Architecture is fully determined by the genome.
    """

    def __init__(self, genome: ArchGenome,
                 num_features: int = NUM_FEATURES,
                 num_classes: int  = NUM_CLASSES):
        super().__init__()
        self.genome     = genome
        self.num_classes = num_classes

        # Label embedding
        self.label_embed = nn.Embedding(num_classes, 32)
        in_dim = num_features + 32

        # Build hidden blocks
        self.blocks = nn.ModuleList()
        current_dim = in_dim
        self.layer_dims = []

        for i, (width, act_name, drop, norm_name) in enumerate(
                zip(genome.layers, genome.activations,
                    genome.dropouts, genome.norm_types)):

            block = []
            block.append(nn.Linear(current_dim, width))

            nl = norm_layer(norm_name, width)
            if nl is not None:
                block.append(nl)

            block.append(activation_fn(act_name))

            if drop > 0:
                block.append(nn.Dropout(drop))

            self.blocks.append(nn.Sequential(*block))
            self.layer_dims.append((current_dim, width))
            current_dim = width

        # Skip connection projection (if enabled + dims differ)
        self.skip_proj = None
        if genome.skip_connect and len(genome.layers) >= 2:
            # Project input to last hidden dim for residual add
            self.skip_proj = nn.Linear(in_dim, current_dim, bias=False)

        # Output heads
        self.adv_head = nn.Sequential(
            nn.Linear(current_dim, 64),
            nn.LeakyReLU(0.2),
            nn.Linear(64, 1)
        )
        self.cls_head = nn.Sequential(
            nn.Linear(current_dim, 64),
            nn.LeakyReLU(0.2),
            nn.Linear(64, num_classes)
        )

    def forward(self, x: torch.Tensor, labels: torch.Tensor):
        label_emb = self.label_embed(labels)
        h = torch.cat([x, label_emb], dim=1)
        inp = h

        for block in self.blocks:
            h = block(h)

        # Optional skip connection
        if self.skip_proj is not None:
            skip = self.skip_proj(inp)
            h    = h + skip

        adv = self.adv_head(h)
        cls = self.cls_head(h)
        return adv, cls


# =============================================================================
# Fitness Evaluator
# =============================================================================
class FitnessEvaluator:
    """
    Evaluates a genome by training the discriminator for a few epochs
    and measuring its LFA detection F1-score (macro-averaged).
    """

    def __init__(self, train_loader: DataLoader, val_loader: DataLoader,
                 eval_epochs: int = 10, device: str = 'cpu'):
        self.train_loader = train_loader
        self.val_loader   = val_loader
        self.eval_epochs  = eval_epochs
        self.device       = device
        self.adv_loss     = nn.BCEWithLogitsLoss()
        self.cls_loss     = nn.CrossEntropyLoss()

    def evaluate(self, genome: ArchGenome) -> ArchGenome:
        """
        Build model from genome, train briefly, evaluate F1, return updated genome.
        """
        t_start = time.time()
        model   = ENASDiscriminator(genome).to(self.device)
        opt     = optim.Adam(model.parameters(), lr=1e-3)

        # Quick training
        model.train()
        for epoch in range(self.eval_epochs):
            for batch_x, batch_y in self.train_loader:
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.long().to(self.device)
                bs      = batch_x.size(0)

                opt.zero_grad()

                # Real samples → adversarial loss
                real_labels = torch.ones(bs, 1, device=self.device)
                adv_out, cls_out = model(batch_x, batch_y)
                loss = (self.adv_loss(adv_out, real_labels) +
                        self.cls_loss(cls_out, batch_y))
                loss.backward()
                opt.step()

        # Evaluate on validation set
        model.eval()
        all_preds, all_true = [], []
        with torch.no_grad():
            for batch_x, batch_y in self.val_loader:
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.long().to(self.device)
                _, cls_out = model(batch_x, batch_y)
                preds = cls_out.argmax(dim=1).cpu().numpy()
                all_preds.extend(preds.tolist())
                all_true.extend(batch_y.cpu().numpy().tolist())

        f1  = f1_score(all_true, all_preds, average='macro', zero_division=0)
        acc = accuracy_score(all_true, all_preds)

        # Complexity penalty: penalize very large models (5% of fitness)
        param_count = sum(p.numel() for p in model.parameters())
        complexity  = min(1.0, param_count / 1e6)   # normalize to [0,1]

        # Fitness = F1 score with slight complexity penalty
        fitness = f1 * (1.0 - 0.05 * complexity)

        genome.f1_score     = f1
        genome.accuracy     = acc
        genome.fitness      = fitness
        genome.train_time_s = time.time() - t_start

        LOG.debug('Genome evaluated: %s', genome.summary())
        return genome


# =============================================================================
# Evolutionary Operators
# =============================================================================
class EvolutionarySearcher:
    """
    Main ENAS engine implementing:
    - Population initialization
    - Tournament selection
    - Single-point and uniform crossover
    - Gaussian and bit-flip mutation
    """

    def __init__(self, population_size: int = 20,
                 tournament_size: int = 4,
                 mutation_rate: float = 0.3,
                 crossover_rate: float = 0.7,
                 elite_fraction: float = 0.1):
        self.pop_size       = population_size
        self.tournament_size= tournament_size
        self.mutation_rate  = mutation_rate
        self.crossover_rate = crossover_rate
        self.num_elites     = max(1, int(population_size * elite_fraction))

        self.population : List[ArchGenome] = []
        self.best_genome: Optional[ArchGenome] = None
        self.history    : List[dict] = []

    def random_genome(self) -> ArchGenome:
        """Create a random architecture genome."""
        num_layers = random.randint(MIN_LAYERS, MAX_LAYERS)
        return ArchGenome(
            layers      = [random.choice(LAYER_WIDTHS) for _ in range(num_layers)],
            activations = [random.choice(ACTIVATIONS)  for _ in range(num_layers)],
            dropouts    = [random.choice(DROPOUT_RATES) for _ in range(num_layers)],
            norm_types  = [random.choice(NORM_TYPES)   for _ in range(num_layers)],
            skip_connect= random.random() < 0.3
        )

    def initialize_population(self):
        """Initialize a diverse starting population."""
        self.population = [self.random_genome() for _ in range(self.pop_size)]
        LOG.info('Initialized population: %d genomes', self.pop_size)

    def tournament_select(self) -> ArchGenome:
        """Select one genome via tournament selection."""
        tournament = random.sample(self.population,
                                   min(self.tournament_size, len(self.population)))
        return max(tournament, key=lambda g: g.fitness)

    def crossover(self, parent1: ArchGenome, parent2: ArchGenome) -> ArchGenome:
        """
        Single-point crossover on layer list.
        Creates one child combining genes from both parents.
        """
        if random.random() > self.crossover_rate:
            return copy.deepcopy(parent1)

        # Use shorter parent's length as upper bound for cut point
        min_len   = min(len(parent1.layers), len(parent2.layers))
        max_len   = max(len(parent1.layers), len(parent2.layers))
        child_len = random.randint(min_len, min(max_len, MAX_LAYERS))

        # Build child layers by alternating from parents
        child_layers = []
        child_acts   = []
        child_drops  = []
        child_norms  = []

        for i in range(child_len):
            if i < len(parent1.layers) and i < len(parent2.layers):
                # Both parents have this layer: choose one randomly
                p = random.choice([parent1, parent2])
            elif i < len(parent1.layers):
                p = parent1
            else:
                p = parent2

            child_layers.append(p.layers[i])
            child_acts.append(p.activations[i])
            child_drops.append(p.dropouts[i])
            child_norms.append(p.norm_types[i])

        child = ArchGenome(
            layers      = child_layers,
            activations = child_acts,
            dropouts    = child_drops,
            norm_types  = child_norms,
            skip_connect= random.choice([parent1.skip_connect, parent2.skip_connect])
        )
        return child

    def mutate(self, genome: ArchGenome) -> ArchGenome:
        """Apply random mutations to a genome."""
        genome = copy.deepcopy(genome)

        for i in range(len(genome.layers)):
            if random.random() < self.mutation_rate:
                # Mutate layer width
                genome.layers[i] = random.choice(LAYER_WIDTHS)
            if random.random() < self.mutation_rate:
                # Mutate activation
                genome.activations[i] = random.choice(ACTIVATIONS)
            if random.random() < self.mutation_rate:
                # Mutate dropout
                genome.dropouts[i] = random.choice(DROPOUT_RATES)
            if random.random() < self.mutation_rate:
                # Mutate normalization
                genome.norm_types[i] = random.choice(NORM_TYPES)

        # Structural mutations (add/remove layer)
        if random.random() < self.mutation_rate * 0.5:
            if len(genome.layers) < MAX_LAYERS:
                # Insert a random layer
                pos = random.randint(0, len(genome.layers))
                genome.layers.insert(pos, random.choice(LAYER_WIDTHS))
                genome.activations.insert(pos, random.choice(ACTIVATIONS))
                genome.dropouts.insert(pos, random.choice(DROPOUT_RATES))
                genome.norm_types.insert(pos, random.choice(NORM_TYPES))
            elif len(genome.layers) > MIN_LAYERS:
                # Remove a random layer
                pos = random.randint(0, len(genome.layers) - 1)
                genome.layers.pop(pos)
                genome.activations.pop(pos)
                genome.dropouts.pop(pos)
                genome.norm_types.pop(pos)

        # Mutate skip connection
        if random.random() < self.mutation_rate * 0.3:
            genome.skip_connect = not genome.skip_connect

        # Reset fitness (needs re-evaluation)
        genome.fitness = 0.0
        return genome

    def evolve(self, evaluator: FitnessEvaluator,
               num_generations: int = 30,
               save_path: str = 'enas_results.json') -> ArchGenome:
        """
        Main evolutionary search loop.

        Args:
            evaluator      : FitnessEvaluator instance
            num_generations: Number of evolutionary generations
            save_path      : Path to save search results
        Returns:
            best_genome    : Best discovered architecture
        """
        LOG.info('=' * 60)
        LOG.info('ENAS: Starting architecture search')
        LOG.info('  Population size : %d', self.pop_size)
        LOG.info('  Generations     : %d', num_generations)
        LOG.info('  Mutation rate   : %.2f', self.mutation_rate)
        LOG.info('  Crossover rate  : %.2f', self.crossover_rate)
        LOG.info('  Search space    : %d possible architectures (estimated)',
                 len(LAYER_WIDTHS) ** 3 * len(ACTIVATIONS) ** 3)
        LOG.info('=' * 60)

        # Initialize + evaluate initial population
        self.initialize_population()
        LOG.info('Evaluating initial population...')
        for i, genome in enumerate(self.population):
            self.population[i] = evaluator.evaluate(genome)
            LOG.info('  [%02d/%02d] %s', i + 1, self.pop_size,
                     self.population[i].summary())

        # Track best
        self.population.sort(key=lambda g: g.fitness, reverse=True)
        self.best_genome = copy.deepcopy(self.population[0])
        LOG.info('Generation 0 best: %s', self.best_genome.summary())

        # Evolution loop
        for gen in range(1, num_generations + 1):
            gen_start = time.time()
            LOG.info('\n--- Generation %d/%d ---', gen, num_generations)

            # Elitism: preserve top genomes
            new_population = [copy.deepcopy(g) for g in self.population[:self.num_elites]]

            # Fill rest with crossover + mutation offspring
            while len(new_population) < self.pop_size:
                parent1 = self.tournament_select()
                parent2 = self.tournament_select()
                child   = self.crossover(parent1, parent2)
                child   = self.mutate(child)
                child   = evaluator.evaluate(child)
                new_population.append(child)

            # Sort and update population
            new_population.sort(key=lambda g: g.fitness, reverse=True)
            self.population = new_population[:self.pop_size]

            # Update best
            if self.population[0].fitness > self.best_genome.fitness:
                self.best_genome = copy.deepcopy(self.population[0])
                LOG.info('New best found: %s', self.best_genome.summary())

            gen_time = time.time() - gen_start
            avg_fit  = np.mean([g.fitness for g in self.population])

            gen_record = {
                'generation'  : gen,
                'best_fitness': round(self.best_genome.fitness, 4),
                'best_f1'     : round(self.best_genome.f1_score, 4),
                'avg_fitness' : round(avg_fit, 4),
                'gen_time_s'  : round(gen_time, 1),
                'best_arch'   : self.best_genome.layers
            }
            self.history.append(gen_record)

            LOG.info('  Best fitness=%.4f  f1=%.4f  avg=%.4f  time=%.1fs',
                     self.best_genome.fitness, self.best_genome.f1_score,
                     avg_fit, gen_time)

        # Save results
        results = {
            'best_genome': self.best_genome.to_dict(),
            'history'    : self.history,
            'final_population': [g.to_dict() for g in self.population[:5]]
        }
        os.makedirs(os.path.dirname(save_path) or '.', exist_ok=True)
        with open(save_path, 'w') as f:
            json.dump(results, f, indent=2)
        LOG.info('\nSearch complete. Results saved: %s', save_path)
        LOG.info('Best architecture: %s', self.best_genome.summary())

        return self.best_genome


# =============================================================================
# Full ENAS Pipeline
# =============================================================================
def run_enas(dataset_dir: str, output_dir: str,
             population: int = 20, generations: int = 30,
             eval_epochs: int = 10, device: str = 'cpu') -> ArchGenome:
    """
    Complete ENAS pipeline:
    1. Load data
    2. Initialize search
    3. Evolve
    4. Return best genome
    """
    from feature_extraction.dataset_builder import (
        NUMERIC_FEATURES, _generate_demo_dataset, normalize_features
    )

    # Load data
    NUMERIC_FEATURES_LIST = [
        'flow_duration', 'fwd_packet_count', 'bwd_packet_count',
        'total_packet_count', 'fwd_byte_count', 'bwd_byte_count',
        'fwd_packet_len_mean', 'fwd_packet_len_std', 'bwd_packet_len_mean',
        'fwd_iat_mean', 'fwd_iat_std', 'flow_bytes_per_sec',
        'flow_pkts_per_sec', 'tcp_flag_ratio', 'src_entropy',
        'dst_entropy', 'port_entropy', 'unique_src_count',
        'unique_dst_count', 'bandwidth_utilization'
    ]

    train_path = os.path.join(dataset_dir, 'train.csv')
    val_path   = os.path.join(dataset_dir, 'val.csv')

    if os.path.exists(train_path):
        train_df = pd.read_csv(train_path)
        val_df   = pd.read_csv(val_path) if os.path.exists(val_path) else train_df.sample(frac=0.2)
    else:
        LOG.warning('No dataset found. Using demo data.')
        full_df  = _generate_demo_dataset(5000)
        full_df, _ = normalize_features(full_df)
        split    = int(len(full_df) * 0.8)
        train_df = full_df.iloc[:split]
        val_df   = full_df.iloc[split:]

    def df_to_loader(df, batch_size=64, shuffle=True):
        available = [f for f in NUMERIC_FEATURES_LIST if f in df.columns]
        X = df[available].fillna(0).values.astype(np.float32)
        y = df['label'].values.astype(np.int64)
        # Pad to NUM_FEATURES if needed
        if X.shape[1] < NUM_FEATURES:
            X = np.pad(X, ((0,0),(0, NUM_FEATURES - X.shape[1])))
        ds = TensorDataset(torch.from_numpy(X), torch.from_numpy(y))
        return DataLoader(ds, batch_size=batch_size, shuffle=shuffle, drop_last=True)

    train_loader = df_to_loader(train_df)
    val_loader   = df_to_loader(val_df, shuffle=False)

    # Setup evaluator + searcher
    evaluator = FitnessEvaluator(train_loader, val_loader, eval_epochs, device)
    searcher  = EvolutionarySearcher(
        population_size=population,
        tournament_size=max(2, population // 5),
        mutation_rate=0.3,
        crossover_rate=0.7
    )

    save_path = os.path.join(output_dir, 'enas_results.json')
    best      = searcher.evolve(evaluator, generations, save_path)

    return best


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='ENAS Architecture Search')
    parser.add_argument('--dataset',     default='../datasets',
                        help='Dataset directory containing train.csv and val.csv')
    parser.add_argument('--output',      default='../models',
                        help='Output directory for search results')
    parser.add_argument('--population',  type=int, default=20,
                        help='Population size (default: 20)')
    parser.add_argument('--generations', type=int, default=30,
                        help='Number of generations (default: 30)')
    parser.add_argument('--eval-epochs', type=int, default=10,
                        help='Epochs to evaluate each architecture (default: 10)')
    parser.add_argument('--device',
                        default='cuda' if torch.cuda.is_available() else 'cpu')
    args = parser.parse_args()

    best_genome = run_enas(
        dataset_dir = args.dataset,
        output_dir  = args.output,
        population  = args.population,
        generations = args.generations,
        eval_epochs = args.eval_epochs,
        device      = args.device
    )

    print('\n' + '=' * 60)
    print('ENAS SEARCH COMPLETE')
    print('=' * 60)
    print(f'Best architecture:')
    print(f'  Layers      : {best_genome.layers}')
    print(f'  Activations : {best_genome.activations}')
    print(f'  Dropouts    : {best_genome.dropouts}')
    print(f'  Norm types  : {best_genome.norm_types}')
    print(f'  Skip conn   : {best_genome.skip_connect}')
    print(f'  F1 score    : {best_genome.f1_score:.4f}')
    print(f'  Accuracy    : {best_genome.accuracy:.4f}')
    print(f'  Parameters  : ~{best_genome.estimate_params():,}')
    print()
    print('Next step: python3 models/train_model.py --use-enas')
